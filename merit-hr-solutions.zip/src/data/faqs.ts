import { FAQ } from '@/types';

export const faqs: FAQ[] = [
  {
    question: 'What HR services do you provide?',
    answer: 'We provide comprehensive HR solutions including Talent Acquisition, Staffing, HR Consulting, Employee Training & Development, Performance Management, and HR Policy & Compliance support.',
  },
  {
    question: 'How can my company request recruitment support?',
    answer: 'You can easily request talent by visiting our "Employers" page and filling out the Request Talent form, or by contacting our team directly via phone, email, or WhatsApp.',
  },
  {
    question: 'How do I apply for a job?',
    answer: 'Visit our "Careers" page to browse current openings. Click on a job you are interested in and fill out the application form, attaching your updated CV.',
  },
  {
    question: 'Can I submit my CV without applying for a specific job?',
    answer: 'Yes! You can register your details and upload your CV through our Candidate Registration section. We will contact you when a suitable role becomes available.',
  },
  {
    question: 'Do you provide employee training?',
    answer: 'Absolutely. We offer customized corporate training programs covering leadership, soft skills, and professional development designed to elevate your workforce.',
  },
  {
    question: 'How long does recruitment take?',
    answer: 'The timeline varies depending on the role\'s complexity and requirements. Typically, we present a shortlist of qualified candidates within 1-3 weeks of understanding your needs.',
  },
];
