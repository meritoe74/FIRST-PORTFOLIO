import { Testimonial } from '@/types';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    position: 'Operations Director',
    company: 'Nexus Logistics',
    content: 'Merit HR completely transformed our hiring process. They took the time to understand our culture and provided candidates who were not just qualified, but the perfect fit for our team.',
  },
  {
    id: '2',
    name: 'David Adeyemi',
    position: 'CEO',
    company: 'FinTrust Innovations',
    content: 'The level of professionalism and dedication from the Merit team is unmatched. Their HR consulting services helped us restructure during a critical growth phase, saving us both time and money.',
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    position: 'VP of Human Resources',
    company: 'Global Retail Corp',
    content: 'We\'ve partnered with Merit for our executive search needs for over three years. Their thorough vetting process and industry insights make them our most trusted recruitment partner.',
  },
];
