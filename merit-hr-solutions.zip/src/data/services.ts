import { Service } from '@/types';

export const services: Service[] = [
  {
    id: '1',
    title: 'Talent Acquisition & Recruitment',
    description: 'End-to-end recruitment services connecting you with top-tier professionals who align with your company culture and goals.',
    icon: 'Users',
  },
  {
    id: '2',
    title: 'Staffing Solutions',
    description: 'Flexible staffing solutions including temporary, contract, and permanent placements to meet your dynamic workforce needs.',
    icon: 'Briefcase',
  },
  {
    id: '3',
    title: 'HR Consulting',
    description: 'Strategic HR advice on organizational design, change management, and building high-performance cultures.',
    icon: 'LineChart',
  },
  {
    id: '4',
    title: 'Training & Development',
    description: 'Custom corporate training programs focused on leadership development, soft skills, and employee upskilling.',
    icon: 'GraduationCap',
  },
  {
    id: '5',
    title: 'Performance Management',
    description: 'Implementation of robust performance appraisal systems that drive employee engagement and productivity.',
    icon: 'Target',
  },
  {
    id: '6',
    title: 'HR Policy & Compliance',
    description: 'Ensuring your business stays compliant with local labor laws through comprehensive policy development and audits.',
    icon: 'ShieldCheck',
  },
];
