import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Mail, MapPin, Phone, Briefcase } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-300" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">
        Footer
      </h2>
      <div className="mx-auto max-w-7xl px-6 pb-8 pt-16 sm:pt-24 lg:px-8 lg:pt-32">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8">
            <Link to="/" className="flex items-center gap-2 text-white">
               <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white">
                  <Briefcase className="h-6 w-6" />
                </div>
              <span className="text-2xl font-bold">Merit HR</span>
            </Link>
            <p className="text-sm leading-6">
              Connecting top talent with forward-thinking organizations. We build the workforce of tomorrow with trust, expertise, and personalized solutions.
            </p>
            <div className="flex space-x-6">
              <a href="https://www.instagram.com/merit_wedding_events_limited/" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-white transition-colors">
                <span className="sr-only">Instagram</span>
                <Instagram className="h-6 w-6" aria-hidden="true" />
              </a>
              <a href="mailto:meritoe@gmail.com" className="text-slate-400 hover:text-white transition-colors">
                <span className="sr-only">Email</span>
                <Mail className="h-6 w-6" aria-hidden="true" />
              </a>
            </div>
          </div>
          <div className="mt-16 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold leading-6 text-white">Quick Links</h3>
                <ul role="list" className="mt-6 space-y-4">
                  <li><Link to="/about" className="text-sm leading-6 hover:text-white transition-colors">About Us</Link></li>
                  <li><Link to="/services" className="text-sm leading-6 hover:text-white transition-colors">Services</Link></li>
                  <li><Link to="/employers" className="text-sm leading-6 hover:text-white transition-colors">For Employers</Link></li>
                  <li><Link to="/careers" className="text-sm leading-6 hover:text-white transition-colors">Careers</Link></li>
                  <li><Link to="/training" className="text-sm leading-6 hover:text-white transition-colors">Training</Link></li>
                </ul>
              </div>
              <div className="mt-10 md:mt-0">
                <h3 className="text-sm font-semibold leading-6 text-white">Services</h3>
                <ul role="list" className="mt-6 space-y-4">
                  <li><Link to="/services" className="text-sm leading-6 hover:text-white transition-colors">Talent Acquisition</Link></li>
                  <li><Link to="/services" className="text-sm leading-6 hover:text-white transition-colors">Staffing Solutions</Link></li>
                  <li><Link to="/services" className="text-sm leading-6 hover:text-white transition-colors">HR Consulting</Link></li>
                  <li><Link to="/training" className="text-sm leading-6 hover:text-white transition-colors">Employee Training</Link></li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-1 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold leading-6 text-white">Contact</h3>
                <ul role="list" className="mt-6 space-y-4">
                  <li className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 flex-shrink-0 text-slate-400" />
                    <span className="text-sm leading-6">123 Business Avenue, Suite 400<br />Lagos, Nigeria</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Phone className="h-5 w-5 flex-shrink-0 text-slate-400" />
                    <span className="text-sm leading-6">+234 811 177 7805</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Mail className="h-5 w-5 flex-shrink-0 text-slate-400" />
                    <a href="mailto:meritoe@gmail.com" className="text-sm leading-6 hover:text-white transition-colors">meritoe@gmail.com</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-16 border-t border-slate-800 pt-8 sm:mt-20 lg:mt-24">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs leading-5 text-slate-400">
              &copy; {currentYear} Merit HR Solutions. All rights reserved.
            </p>
            <div className="flex gap-6">
              <Link to="/" className="text-xs leading-5 text-slate-400 hover:text-white transition-colors">Privacy Policy</Link>
              <Link to="/" className="text-xs leading-5 text-slate-400 hover:text-white transition-colors">Terms & Conditions</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
