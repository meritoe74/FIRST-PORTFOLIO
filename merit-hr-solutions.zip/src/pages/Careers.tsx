import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { jobs } from '@/data/jobs';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { MapPin, Briefcase, Clock, Search } from 'lucide-react';
import { motion } from 'motion/react';

export default function Careers() {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            job.company.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = typeFilter ? job.type === typeFilter : true;
      return matchesSearch && matchesType;
    });
  }, [searchTerm, typeFilter]);

  return (
    <div className="bg-slate-50 min-h-screen">
      <section className="bg-slate-900 py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
            Explore Opportunities
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-300 max-w-2xl mx-auto">
            Discover your next career move with top organizations. Browse our current openings or register your CV for future opportunities.
          </p>
          <div className="mt-10">
             <Button asChild variant="primary" size="lg">
                <Link to="/register-cv">Submit Your CV</Link>
             </Button>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          
          {/* Filters */}
          <div className="mb-10 rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200 flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
               <Input 
                 placeholder="Search by job title or company..." 
                 value={searchTerm}
                 onChange={(e) => setSearchTerm(e.target.value)}
                 className="pl-10"
               />
            </div>
            <select
              className="flex h-11 w-full md:w-64 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
            >
              <option value="">All Employment Types</option>
              <option value="Full-time">Full-time</option>
              <option value="Part-time">Part-time</option>
              <option value="Contract">Contract</option>
            </select>
          </div>

          {/* Job Listings */}
          <div className="space-y-6">
            {filteredJobs.length > 0 ? (
              filteredJobs.map((job, index) => (
                <motion.div 
                  key={job.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 hover:shadow-md transition-shadow sm:p-8"
                >
                  <div className="flex flex-col sm:flex-row justify-between gap-6">
                    <div className="flex-grow">
                      <div className="flex flex-wrap items-center gap-3 mb-2">
                         <h3 className="text-xl font-bold text-slate-900">{job.title}</h3>
                         <span className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-medium text-blue-700">
                           {job.level}
                         </span>
                      </div>
                      <p className="text-slate-900 font-medium mb-4">{job.company}</p>
                      
                      <div className="flex flex-wrap gap-y-2 gap-x-6 text-sm text-slate-500 mb-6">
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" /> {job.location}
                        </div>
                        <div className="flex items-center gap-1">
                          <Briefcase className="h-4 w-4" /> {job.type}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" /> Deadline: {new Date(job.deadline).toLocaleDateString()}
                        </div>
                      </div>
                      
                      <p className="text-slate-600">{job.description}</p>
                    </div>
                    
                    <div className="flex sm:flex-col items-center justify-end gap-4 shrink-0">
                      <Button asChild variant="primary">
                        <Link to={`/register-cv?job=${job.id}`}>Apply Now</Link>
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-20 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
                <Briefcase className="mx-auto h-12 w-12 text-slate-300 mb-4" />
                <h3 className="text-lg font-medium text-slate-900">No jobs found</h3>
                <p className="text-slate-500 mt-1">Try adjusting your search or filters.</p>
                <Button variant="outline" className="mt-6" onClick={() => { setSearchTerm(''); setTypeFilter(''); }}>Clear Filters</Button>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
