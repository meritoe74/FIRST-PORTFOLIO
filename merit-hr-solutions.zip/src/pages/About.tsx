import React from 'react';
import { CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  const values = [
    { name: 'Integrity', description: 'We uphold the highest standards of professionalism, ethics, and transparency in every interaction.' },
    { name: 'Excellence', description: 'We strive for exceptional quality in our placements, consulting, and client service.' },
    { name: 'Partnership', description: 'We believe in building long-term, mutually beneficial relationships with clients and candidates.' },
    { name: 'Innovation', description: 'We continuously adapt our strategies to meet the evolving demands of the modern workplace.' },
  ];

  return (
    <div className="bg-white">
      {/* Header */}
      <section className="bg-slate-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl"
          >
            About Merit HR Solutions
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-6 text-lg leading-8 text-slate-600 max-w-3xl mx-auto"
          >
            We are a premier human resources consulting and recruitment firm dedicated to connecting exceptional talent with industry-leading organizations. Our goal is to empower businesses through strategic workforce solutions.
          </motion.p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-y-16 lg:grid-cols-2 lg:gap-x-16">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-slate-900">Our Mission</h2>
              <p className="mt-6 text-lg leading-8 text-slate-600">
                To bridge the gap between outstanding professionals and innovative companies by providing tailored, ethical, and efficient human resource solutions that foster mutual growth and success.
              </p>
            </div>
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-slate-900">Our Vision</h2>
              <p className="mt-6 text-lg leading-8 text-slate-600">
                To be the most trusted and preferred HR partner globally, recognized for transforming workplaces and elevating careers through unparalleled service and expertise.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-slate-900 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl lg:text-center">
            <h2 className="text-base font-semibold leading-7 text-blue-400">Our Philosophy</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">Core Values</p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
            <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-4">
              {values.map((value, index) => (
                <motion.div
                  key={value.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex flex-col"
                >
                  <dt className="flex items-center gap-x-3 text-xl font-semibold leading-7 text-white">
                    <CheckCircle className="h-5 w-5 flex-none text-blue-400" aria-hidden="true" />
                    {value.name}
                  </dt>
                  <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-slate-300">
                    <p className="flex-auto">{value.description}</p>
                  </dd>
                </motion.div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* Team placeholder */}
      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
           <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Leadership Team</h2>
           <p className="mt-6 text-lg leading-8 text-slate-600 max-w-2xl mx-auto">
             Our team brings decades of combined experience in HR strategy, executive search, and talent management.
           </p>
           <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
             {/* Placeholder team members */}
             {[1, 2, 3].map((i) => (
                <div key={i} className="flex flex-col items-center">
                  <div className="h-48 w-48 rounded-full bg-slate-200 mb-4 flex items-center justify-center">
                     <span className="text-slate-500 font-medium text-sm">Photo Placeholder</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">Executive Name</h3>
                  <p className="text-sm text-blue-600 font-medium">Partner / Director</p>
                </div>
             ))}
           </div>
        </div>
      </section>
    </div>
  );
}
