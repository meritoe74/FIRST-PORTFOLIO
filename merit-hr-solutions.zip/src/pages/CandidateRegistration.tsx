import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/Button';
import { Input, Textarea } from '@/components/ui/Input';
import { CheckCircle2, UploadCloud } from 'lucide-react';
import { jobs } from '@/data/jobs';
import { motion } from 'motion/react';

type CandidateForm = {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  expertise: string;
  experience: string;
  role: string;
  additionalInfo: string;
};

export default function CandidateRegistration() {
  const [searchParams] = useSearchParams();
  const jobId = searchParams.get('job');
  const job = jobId ? jobs.find(j => j.id === jobId) : null;
  
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [fileName, setFileName] = useState('');
  
  const { register, handleSubmit, setValue, formState: { errors, isSubmitting } } = useForm<CandidateForm>({
    defaultValues: {
      role: job ? job.title : ''
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileName(e.target.files[0].name);
    }
  };

  const onSubmit = async (data: CandidateForm) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log('Candidate registration:', data, fileName);
    setIsSubmitted(true);
  };

  return (
    <div className="bg-slate-50 py-24 sm:py-32 min-h-screen">
      <div className="mx-auto max-w-3xl px-6 lg:px-8">
        <div className="mb-10 text-center">
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            {job ? `Apply for ${job.title}` : 'Submit Your CV'}
          </h1>
          <p className="mt-4 text-lg text-slate-600">
            {job ? `Join ${job.company} by filling out the application form below.` : 'Register with our talent network to be considered for future opportunities.'}
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl ring-1 ring-slate-200 p-8 sm:p-10">
          {isSubmitted ? (
             <motion.div
               initial={{ opacity: 0, scale: 0.9 }}
               animate={{ opacity: 1, scale: 1 }}
               className="text-center py-10"
             >
               <CheckCircle2 className="mx-auto h-16 w-16 text-green-500 mb-6" />
               <h2 className="text-2xl font-bold text-slate-900 mb-4">Application Submitted!</h2>
               <p className="text-slate-600 text-lg">Thank you for submitting your profile. Our recruitment team will review your details and contact you if there's a suitable match.</p>
             </motion.div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium leading-6 text-slate-900">Full Name</label>
                  <Input {...register('fullName', { required: true })} className="mt-2" />
                  {errors.fullName && <span className="text-sm text-red-500">Required</span>}
                </div>
                <div>
                  <label className="block text-sm font-medium leading-6 text-slate-900">Email Address</label>
                  <Input type="email" {...register('email', { required: true })} className="mt-2" />
                  {errors.email && <span className="text-sm text-red-500">Required</span>}
                </div>
                <div>
                  <label className="block text-sm font-medium leading-6 text-slate-900">Phone Number</label>
                  <Input type="tel" {...register('phone', { required: true })} className="mt-2" />
                  {errors.phone && <span className="text-sm text-red-500">Required</span>}
                </div>
                <div>
                  <label className="block text-sm font-medium leading-6 text-slate-900">Location</label>
                  <Input {...register('location', { required: true })} className="mt-2" />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                 <div>
                  <label className="block text-sm font-medium leading-6 text-slate-900">Area of Expertise</label>
                  <select
                    {...register('expertise', { required: true })}
                    className="mt-2 flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
                  >
                    <option value="">Select Industry...</option>
                    <option value="IT/Technology">IT & Technology</option>
                    <option value="Finance">Finance & Banking</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Engineering">Engineering</option>
                    <option value="Sales">Sales & Marketing</option>
                    <option value="HR">Human Resources</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium leading-6 text-slate-900">Years of Experience</label>
                  <select
                    {...register('experience', { required: true })}
                    className="mt-2 flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
                  >
                     <option value="0-2">0-2 years (Entry)</option>
                     <option value="3-5">3-5 years (Mid)</option>
                     <option value="5-10">5-10 years (Senior)</option>
                     <option value="10+">10+ years (Executive)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium leading-6 text-slate-900">Preferred Role / Position Applied For</label>
                <Input {...register('role', { required: true })} className="mt-2" readOnly={!!job} />
              </div>

              <div>
                 <label className="block text-sm font-medium leading-6 text-slate-900 mb-2">Upload CV</label>
                 <div className="mt-2 flex justify-center rounded-lg border border-dashed border-slate-300 px-6 py-10 hover:bg-slate-50 transition-colors">
                    <div className="text-center">
                      <UploadCloud className="mx-auto h-12 w-12 text-slate-300" aria-hidden="true" />
                      <div className="mt-4 flex text-sm leading-6 text-slate-600 justify-center">
                        <label
                          htmlFor="cv-upload"
                          className="relative cursor-pointer rounded-md bg-white font-semibold text-blue-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-600 focus-within:ring-offset-2 hover:text-blue-500"
                        >
                          <span>Upload a file</span>
                          <input id="cv-upload" name="cv-upload" type="file" className="sr-only" accept=".pdf,.doc,.docx" onChange={handleFileChange} required />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs leading-5 text-slate-500 mt-1">PDF, DOC, DOCX up to 5MB</p>
                      {fileName && <p className="text-sm font-medium text-blue-600 mt-3 flex items-center justify-center gap-2"><CheckCircle2 className="h-4 w-4"/> {fileName}</p>}
                    </div>
                  </div>
              </div>

              <div>
                <label className="block text-sm font-medium leading-6 text-slate-900">Cover Letter / Additional Information</label>
                <Textarea {...register('additionalInfo')} className="mt-2" rows={4} />
              </div>

              <Button type="submit" variant="primary" className="w-full" size="lg" isLoading={isSubmitting}>
                Submit Application
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
