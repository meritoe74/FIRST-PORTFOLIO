import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/Button';
import { GraduationCap, TrendingUp, Users, Presentation } from 'lucide-react';
import { motion } from 'motion/react';

export default function Training() {
  const programs = [
    {
      title: 'Leadership Development',
      description: 'Equip your managers with the skills to lead effectively, inspire teams, and drive organizational success.',
      icon: TrendingUp
    },
    {
      title: 'Corporate Soft Skills',
      description: 'Enhance communication, emotional intelligence, and conflict resolution across your workforce.',
      icon: Users
    },
    {
      title: 'Technical & Professional Upskilling',
      description: 'Industry-specific training designed to keep your team ahead of technological and methodological advancements.',
      icon: GraduationCap
    },
    {
      title: 'Onboarding & Cultural Integration',
      description: 'Structured programs to ensure new hires rapidly integrate and align with your company values.',
      icon: Presentation
    }
  ];

  return (
    <div className="bg-white">
      <section className="bg-slate-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            Training & Development
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-600 max-w-2xl mx-auto">
            Invest in your most valuable asset. Our customized corporate training programs empower your employees to reach their full potential.
          </p>
        </div>
      </section>

      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            {programs.map((program, index) => {
              const Icon = program.icon;
              return (
                <motion.div
                  key={program.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white p-8 rounded-2xl shadow-sm ring-1 ring-slate-200"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-50 text-blue-600 mb-6">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">{program.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{program.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-blue-600 py-24 sm:py-32">
         <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
           <h2 className="text-3xl font-bold tracking-tight text-white">Elevate Your Team's Performance</h2>
           <p className="mt-6 text-lg leading-8 text-blue-100 max-w-2xl mx-auto">
             Contact us to design a bespoke training program tailored to your company's unique challenges and goals.
           </p>
           <div className="mt-10 flex justify-center gap-4">
             <Button asChild size="lg" variant="default" className="bg-white text-blue-600 hover:bg-slate-100">
               <Link to="/contact">Book a Training</Link>
             </Button>
           </div>
         </div>
      </section>
    </div>
  );
}
