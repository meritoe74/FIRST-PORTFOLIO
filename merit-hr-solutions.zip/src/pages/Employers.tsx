import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/Button';
import { Input, Textarea } from '@/components/ui/Input';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

type EmployerForm = {
  fullName: string;
  companyName: string;
  email: string;
  phone: string;
  jobPosition: string;
  employeeCount: string;
  location: string;
  additionalInfo: string;
};

export default function Employers() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<EmployerForm>();

  const onSubmit = async (data: EmployerForm) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log('Employer request:', data);
    setIsSubmitted(true);
  };

  const processSteps = [
    { id: '01', title: 'Understand Your Needs', description: 'We consult with you to understand the role, company culture, and exact requirements.' },
    { id: '02', title: 'Source Candidates', description: 'We leverage our extensive network and databases to identify top-tier talent.' },
    { id: '03', title: 'Screen & Assess', description: 'Rigorous vetting, interviewing, and skills assessment of all shortlisted candidates.' },
    { id: '04', title: 'Placement', description: 'We manage the offer process and assist with onboarding to ensure a smooth transition.' },
  ];

  return (
    <div className="bg-white">
      <section className="bg-slate-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
              Find Exceptional Talent
            </h1>
            <p className="mt-6 text-lg leading-8 text-slate-600">
              Partner with Merit HR Solutions to build high-performing teams. We handle the heavy lifting of recruitment so you can focus on growing your business.
            </p>
          </div>
        </div>
      </section>

      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Process */}
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-slate-900 mb-8">Our Recruitment Process</h2>
              <div className="space-y-8">
                {processSteps.map((step) => (
                  <div key={step.id} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-600 font-bold">
                        {step.id}
                      </div>
                      <div className="h-full w-px bg-slate-200 mt-4"></div>
                    </div>
                    <div className="pt-3 pb-8">
                      <h3 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h3>
                      <p className="text-slate-600">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Request Form */}
            <div id="request-talent" className="bg-white rounded-2xl shadow-xl ring-1 ring-slate-200 p-8 sm:p-10">
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Request Talent</h3>
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-green-50 p-6 rounded-lg text-center"
                >
                  <CheckCircle2 className="mx-auto h-12 w-12 text-green-500 mb-4" />
                  <h4 className="text-lg font-bold text-green-900 mb-2">Request Received Successfully</h4>
                  <p className="text-green-700">Thank you for reaching out. One of our recruitment specialists will contact you shortly to discuss your needs.</p>
                  <Button onClick={() => setIsSubmitted(false)} variant="outline" className="mt-6">Submit Another Request</Button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-medium leading-6 text-slate-900">Full Name</label>
                      <Input id="fullName" {...register('fullName', { required: true })} className="mt-2" />
                      {errors.fullName && <span className="text-sm text-red-500 mt-1">Required</span>}
                    </div>
                    <div>
                      <label htmlFor="companyName" className="block text-sm font-medium leading-6 text-slate-900">Company Name</label>
                      <Input id="companyName" {...register('companyName', { required: true })} className="mt-2" />
                      {errors.companyName && <span className="text-sm text-red-500 mt-1">Required</span>}
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium leading-6 text-slate-900">Email Address</label>
                      <Input id="email" type="email" {...register('email', { required: true })} className="mt-2" />
                      {errors.email && <span className="text-sm text-red-500 mt-1">Required</span>}
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium leading-6 text-slate-900">Phone Number</label>
                      <Input id="phone" type="tel" {...register('phone', { required: true })} className="mt-2" />
                      {errors.phone && <span className="text-sm text-red-500 mt-1">Required</span>}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="jobPosition" className="block text-sm font-medium leading-6 text-slate-900">Job Position Required</label>
                    <Input id="jobPosition" {...register('jobPosition', { required: true })} className="mt-2" />
                  </div>

                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                      <label htmlFor="employeeCount" className="block text-sm font-medium leading-6 text-slate-900">Number of Employees Needed</label>
                      <select
                        id="employeeCount"
                        {...register('employeeCount')}
                        className="mt-2 flex h-11 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
                      >
                        <option value="1">1</option>
                        <option value="2-5">2 - 5</option>
                        <option value="6-10">6 - 10</option>
                        <option value="10+">10+</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="location" className="block text-sm font-medium leading-6 text-slate-900">Preferred Location</label>
                      <Input id="location" {...register('location')} className="mt-2" />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="additionalInfo" className="block text-sm font-medium leading-6 text-slate-900">Additional Information</label>
                    <Textarea id="additionalInfo" {...register('additionalInfo')} className="mt-2" rows={4} placeholder="Tell us more about the role, culture, and requirements..." />
                  </div>

                  <Button type="submit" variant="primary" className="w-full" isLoading={isSubmitting}>
                    Submit Request
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
