import React from 'react';
import { services } from '@/data/services';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/Button';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Services() {
  return (
    <div className="bg-white">
      <section className="bg-slate-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            Our Services
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-600 max-w-2xl mx-auto">
            Comprehensive HR and recruitment solutions designed to help your business scale, manage, and retain top talent efficiently.
          </p>
        </div>
      </section>

      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex flex-col sm:flex-row gap-6 p-8 rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 hover:shadow-md transition-shadow"
              >
                <div className="flex-none">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <CheckCircle2 className="h-6 w-6" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{service.title}</h3>
                  <p className="text-slate-600 leading-relaxed mb-6">{service.description}</p>
                  <Button asChild variant="outline" size="sm">
                    <Link to="/contact">Enquire Now</Link>
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-900 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Need a customized HR solution?</h2>
          <p className="mt-6 text-lg leading-8 text-slate-300 max-w-2xl mx-auto">
            Every business is unique. Contact us to discuss how we can tailor our services to meet your specific organizational challenges.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <Button asChild size="lg" variant="primary">
              <Link to="/contact">Speak with an Expert</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
