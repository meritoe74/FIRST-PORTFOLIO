import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/Button';
import { Input, Textarea } from '@/components/ui/Input';
import { MapPin, Phone, Mail, Clock, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { faqs } from '@/data/faqs';

type ContactForm = {
  fullName: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
};

function FAQAccordion() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="space-y-4">
      {faqs.map((faq, index) => (
        <div key={index} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <button
            className="flex w-full items-center justify-between px-6 py-4 text-left focus:outline-none"
            onClick={() => setOpenIndex(openIndex === index ? null : index)}
          >
            <span className="font-semibold text-slate-900">{faq.question}</span>
            {openIndex === index ? (
              <ChevronUp className="h-5 w-5 text-slate-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-slate-500" />
            )}
          </button>
          <AnimatePresence>
            {openIndex === index && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <div className="px-6 pb-4 text-slate-600 border-t border-slate-100 pt-4">
                  {faq.answer}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}

export default function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<ContactForm>();

  const onSubmit = async (data: ContactForm) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log('Contact form:', data);
    setIsSubmitted(true);
    reset();
  };

  return (
    <div className="bg-white">
      <section className="bg-slate-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            Get in Touch
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-600 max-w-2xl mx-auto">
            Whether you're looking for top talent or your next career move, we're here to help. Reach out to us today.
          </p>
        </div>
      </section>

      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Contact Info & Map Placeholder */}
            <div>
              <h2 className="text-2xl font-bold text-slate-900 mb-8">Contact Information</h2>
              <div className="space-y-8 text-slate-600 text-lg">
                <div className="flex items-start gap-4">
                  <MapPin className="h-6 w-6 text-blue-600 shrink-0 mt-1" />
                  <div>
                    <strong className="block text-slate-900">Head Office</strong>
                    123 Business Avenue, Suite 400<br />Lagos, Nigeria
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone className="h-6 w-6 text-blue-600 shrink-0 mt-1" />
                  <div>
                    <strong className="block text-slate-900">Phone & WhatsApp</strong>
                    <a href="tel:+2348111777805" className="hover:text-blue-600">+234 811 177 7805</a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="h-6 w-6 text-blue-600 shrink-0 mt-1" />
                  <div>
                    <strong className="block text-slate-900">Email</strong>
                    <a href="mailto:meritoe@gmail.com" className="hover:text-blue-600">meritoe@gmail.com</a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Clock className="h-6 w-6 text-blue-600 shrink-0 mt-1" />
                  <div>
                    <strong className="block text-slate-900">Business Hours</strong>
                    Mon - Fri: 8:00 AM - 5:00 PM<br />Sat - Sun: Closed
                  </div>
                </div>
              </div>

              {/* Map Placeholder */}
              <div className="mt-10 rounded-2xl bg-slate-200 aspect-[16/9] flex items-center justify-center relative overflow-hidden">
                <span className="text-slate-500 font-medium">Google Maps Integration Placeholder</span>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-2xl shadow-xl ring-1 ring-slate-200 p-8 sm:p-10 h-fit">
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Send us a Message</h3>
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-green-50 p-6 rounded-lg text-center"
                >
                  <CheckCircle2 className="mx-auto h-12 w-12 text-green-500 mb-4" />
                  <h4 className="text-lg font-bold text-green-900 mb-2">Message Sent!</h4>
                  <p className="text-green-700">Thank you for contacting Merit HR Solutions. We will get back to you shortly.</p>
                  <Button onClick={() => setIsSubmitted(false)} variant="outline" className="mt-6">Send Another Message</Button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium leading-6 text-slate-900">Full Name</label>
                    <Input {...register('fullName', { required: true })} className="mt-2" />
                    {errors.fullName && <span className="text-sm text-red-500">Required</span>}
                  </div>
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium leading-6 text-slate-900">Email Address</label>
                      <Input type="email" {...register('email', { required: true })} className="mt-2" />
                      {errors.email && <span className="text-sm text-red-500">Required</span>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium leading-6 text-slate-900">Phone Number</label>
                      <Input type="tel" {...register('phone')} className="mt-2" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium leading-6 text-slate-900">Subject</label>
                    <Input {...register('subject', { required: true })} className="mt-2" />
                    {errors.subject && <span className="text-sm text-red-500">Required</span>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium leading-6 text-slate-900">Message</label>
                    <Textarea {...register('message', { required: true })} className="mt-2" rows={5} />
                    {errors.message && <span className="text-sm text-red-500">Required</span>}
                  </div>
                  <Button type="submit" variant="primary" className="w-full" size="lg" isLoading={isSubmitting}>
                    Send Message
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-slate-50 py-24 sm:py-32">
         <div className="mx-auto max-w-3xl px-6 lg:px-8">
            <div className="text-center mb-12">
               <h2 className="text-3xl font-bold tracking-tight text-slate-900">Frequently Asked Questions</h2>
            </div>
            <FAQAccordion />
         </div>
      </section>
    </div>
  );
}
