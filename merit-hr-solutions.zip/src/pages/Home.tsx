import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, ChevronRight, Users, Briefcase, LineChart } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { services } from '@/data/services';
import { testimonials } from '@/data/testimonials';

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-50 pt-16 md:pt-24 lg:pt-32 pb-16 lg:pb-32">
        <div className="absolute inset-0 z-0 opacity-10">
           <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
             <path d="M0,100 C20,0 50,0 100,100 Z" fill="currentColor" className="text-blue-600" />
           </svg>
        </div>
        <div className="mx-auto max-w-7xl px-6 lg:px-8 relative z-10">
          <div className="mx-auto max-w-2xl text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl font-bold tracking-tight text-slate-900 sm:text-6xl"
            >
              Building the Workforce of <span className="text-blue-600">Tomorrow</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mt-6 text-lg leading-8 text-slate-600"
            >
              Merit HR Solutions connects exceptional talent with forward-thinking organizations. We provide premium recruitment, staffing, and corporate HR consulting tailored to your business needs.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-10 flex items-center justify-center gap-x-6"
            >
              <Button asChild size="lg" variant="primary">
                <Link to="/employers">Find Talent</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="group">
                <Link to="/careers">
                  Find Opportunities
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-slate-900 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <dl className="grid grid-cols-1 gap-x-8 gap-y-16 text-center lg:grid-cols-4">
            <div className="mx-auto flex max-w-xs flex-col gap-y-4">
              <dt className="text-base leading-7 text-slate-400">Placements Made</dt>
              <dd className="order-first text-3xl font-semibold tracking-tight text-white sm:text-5xl">5,000+</dd>
            </div>
            <div className="mx-auto flex max-w-xs flex-col gap-y-4">
              <dt className="text-base leading-7 text-slate-400">Corporate Clients</dt>
              <dd className="order-first text-3xl font-semibold tracking-tight text-white sm:text-5xl">300+</dd>
            </div>
            <div className="mx-auto flex max-w-xs flex-col gap-y-4">
              <dt className="text-base leading-7 text-slate-400">Years Experience</dt>
              <dd className="order-first text-3xl font-semibold tracking-tight text-white sm:text-5xl">15+</dd>
            </div>
            <div className="mx-auto flex max-w-xs flex-col gap-y-4">
              <dt className="text-base leading-7 text-slate-400">Retention Rate</dt>
              <dd className="order-first text-3xl font-semibold tracking-tight text-white sm:text-5xl">96%</dd>
            </div>
          </dl>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 sm:py-32 bg-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-base font-semibold leading-7 text-blue-600">Expertise</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Comprehensive HR Solutions
            </p>
            <p className="mt-6 text-lg leading-8 text-slate-600">
              We offer end-to-end human resources services designed to optimize your workforce and drive business growth.
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
            <div className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
              {services.slice(0, 3).map((service, index) => (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex flex-col rounded-2xl bg-slate-50 p-8 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md"
                >
                  <dt className="flex items-center gap-x-3 text-lg font-semibold leading-7 text-slate-900">
                     <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
                       {index === 0 ? <Users className="h-6 w-6 text-blue-600" /> : index === 1 ? <Briefcase className="h-6 w-6 text-blue-600" /> : <LineChart className="h-6 w-6 text-blue-600" />}
                     </div>
                  </dt>
                  <dd className="mt-6 flex flex-auto flex-col text-base leading-7 text-slate-600">
                    <h3 className="font-semibold text-slate-900 text-xl mb-2">{service.title}</h3>
                    <p className="flex-auto">{service.description}</p>
                    <p className="mt-6">
                      <Link to="/services" className="text-sm font-semibold leading-6 text-blue-600 hover:text-blue-500">
                        Learn more <span aria-hidden="true">→</span>
                      </Link>
                    </p>
                  </dd>
                </motion.div>
              ))}
            </div>
            <div className="mt-12 text-center">
               <Button asChild variant="outline">
                 <Link to="/services">View All Services</Link>
               </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-slate-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
                Why Partner With Merit HR?
              </h2>
              <p className="mt-6 text-lg leading-8 text-slate-600">
                We go beyond matching resumes to job descriptions. We build lasting partnerships focused on aligning talent with your strategic vision.
              </p>
              <dl className="mt-10 max-w-xl space-y-8 text-base leading-7 text-slate-600 lg:max-w-none">
                {[
                  'Industry-specific recruitment experts',
                  'Rigorous vetting and screening processes',
                  'Tailored staffing solutions for any scale',
                  'Commitment to diversity and inclusion',
                ].map((feature) => (
                  <div key={feature} className="relative pl-9">
                    <dt className="inline font-semibold text-slate-900">
                      <CheckCircle2 className="absolute left-1 top-1 h-5 w-5 text-blue-600" aria-hidden="true" />
                    </dt>
                    <dd className="inline">{feature}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-10">
                <Button asChild variant="primary">
                  <Link to="/about">More About Us</Link>
                </Button>
              </div>
            </div>
            <div className="rounded-2xl bg-slate-200 aspect-[4/3] relative overflow-hidden">
                {/* Placeholder for an image */}
                <div className="absolute inset-0 bg-slate-300 flex items-center justify-center">
                  <span className="text-slate-500 font-medium">Corporate Team Meeting Image</span>
                </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 sm:py-32 bg-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-xl text-center mb-16">
            <h2 className="text-lg font-semibold leading-8 tracking-tight text-blue-600">Testimonials</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900">Trusted by Industry Leaders</p>
          </div>
          <div className="mx-auto grid max-w-2xl grid-cols-1 gap-8 lg:max-w-none lg:grid-cols-3">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="flex flex-col justify-between rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
                <p className="text-slate-600 italic">"{testimonial.content}"</p>
                <div className="mt-6 flex items-center gap-x-4">
                  <div className="h-10 w-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900">{testimonial.name}</div>
                    <div className="text-sm leading-6 text-slate-500">{testimonial.position}, {testimonial.company}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-blue-600 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Ready to elevate your workforce?
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-blue-100">
              Get in touch with our experts today to discuss your recruitment and HR needs.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <Button asChild size="lg" variant="default" className="bg-white text-blue-600 hover:bg-slate-100">
                <Link to="/contact">Contact Us Today</Link>
              </Button>
              <Link to="/employers" className="text-sm font-semibold leading-6 text-white group flex items-center gap-1">
                View Employer Solutions <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
