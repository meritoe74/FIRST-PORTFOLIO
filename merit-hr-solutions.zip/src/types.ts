export type JobType = 'Full-time' | 'Part-time' | 'Contract' | 'Freelance';
export type JobLevel = 'Entry Level' | 'Mid Level' | 'Senior Level' | 'Executive';

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: JobType;
  level: JobLevel;
  description: string;
  deadline: string;
  postedAt: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface Testimonial {
  id: string;
  name: string;
  position: string;
  company: string;
  content: string;
  avatar?: string;
}

export interface FAQ {
  question: string;
  answer: string;
}
