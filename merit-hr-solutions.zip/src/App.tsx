/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import Home from '@/pages/Home';
import About from '@/pages/About';
import Services from '@/pages/Services';
import Employers from '@/pages/Employers';
import Careers from '@/pages/Careers';
import CandidateRegistration from '@/pages/CandidateRegistration';
import Training from '@/pages/Training';
import Contact from '@/pages/Contact';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="services" element={<Services />} />
          <Route path="employers" element={<Employers />} />
          <Route path="careers" element={<Careers />} />
          <Route path="register-cv" element={<CandidateRegistration />} />
          <Route path="training" element={<Training />} />
          <Route path="contact" element={<Contact />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
