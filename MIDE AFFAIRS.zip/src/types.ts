export interface Texture {
  id: string;
  name: string;
  image: string;
  galleryImages?: string[];
}

export interface Product {
  id: string;
  name: string;
  description: string;
  categoryId: string;
  texture?: string;
  price: number;
  images: string[];
  sizes: string[];
  colors: string[];
  stock: number;
  createdAt: number;
  updatedAt: number;
  isFeatured?: boolean;
}

export interface Category {
  id: string;
  name: string;
  image: string;
}

export interface Order {
  id: string;
  userId: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: {
    productId: string;
    quantity: number;
    price: number;
    size?: string;
    color?: string;
  }[];
  total: number;
  shippingAddress: {
    fullName: string;
    address: string;
    city: string;
    postalCode: string;
    phone: string;
  };
  createdAt: number;
}

export interface Settings {
  businessName: string;
  email: string;
  phone: string;
  whatsapp: string;
  instagram: string;
  tiktok: string;
  facebook: string;
  youtube: string;
  xLink: string;
  storeAddress: string;
  heroBanners: { id: string; title: string; subtitle: string; image: string; link: string }[];
  aboutSettings?: {
    ceoName: string;
    ceoTitle: string;
    biography: string;
    profileImage: string;
  };
}
