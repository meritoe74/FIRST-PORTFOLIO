import { useSettingsStore } from '../stores/useSettingsStore';

export default function About() {
  const settings = useSettingsStore((state) => state.settings);
  const about = settings?.aboutSettings;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24 items-center">
        
        {/* Profile Image Section */}
        <div className="relative">
          <div className="aspect-[4/5] bg-gray-100 rounded-2xl overflow-hidden shadow-xl">
            <img 
              src={about?.profileImage || "https://images.unsplash.com/photo-1531123414708-f47ecfd2f04e?w=800&h=1000&fit=crop"} 
              alt={about?.ceoName || "Adeyemi Ayomide Grace"} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl hidden md:block border border-gray-100">
            <h3 className="font-serif text-xl font-bold text-gray-900">{about?.ceoName || "Adeyemi Ayomide Grace"}</h3>
            <p className="text-gray-500 font-medium text-sm mt-1">{about?.ceoTitle || "Founder & CEO"}</p>
          </div>
        </div>

        {/* Biography Section */}
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-gray-900 font-serif mb-6">
            Meet Our CEO
          </h1>
          <div className="md:hidden mb-6">
             <h3 className="font-serif text-2xl font-bold text-gray-900">{about?.ceoName || "Adeyemi Ayomide Grace"}</h3>
             <p className="text-gray-500 font-medium text-sm mt-1">{about?.ceoTitle || "Founder & CEO"}</p>
          </div>
          
          <div className="space-y-6 text-gray-600 leading-relaxed text-lg font-light whitespace-pre-wrap">
            {about?.biography || `Welcome to **${settings?.businessName || "Mide's Affairs"}**. Founded by Adeyemi Ayomide Grace, our brand was built on the fundamental belief that every woman deserves access to premium quality hair that empowers her confidence and elevates her style.\n\nUnder Ayomide's leadership, Mide's Affairs has grown from a boutique vision into a trusted source for exquisite, long-lasting luxury hair and flawless wigs. Her dedication to sourcing authentic, high-quality bundles ensures that our clients receive nothing but the best.\n\n"My mission has always been to provide women with hair collections that not only look naturally beautiful but stand the test of time. Hair is a crown, and we ensure yours shines."`}
          </div>

          <div className="mt-10">
            <a 
              href="/shop" 
              className="inline-block border-b-2 border-black pb-1 text-black font-medium hover:text-gray-600 hover:border-gray-600 transition-colors"
            >
              Discover Our Collection
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
