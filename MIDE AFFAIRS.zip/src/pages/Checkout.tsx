import { useState } from 'react';
import { useCartStore } from '../stores/useCartStore';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

export default function Checkout() {
  const { items, total, clearCart } = useCartStore();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: ''
  });

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const orderData = {
        userId: formData.email, // using email as guest identifier for simplicity
        status: 'pending',
        items: items.map(item => ({
          productId: item.productId,
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          size: item.size || null,
          color: item.color || null
        })),
        total: total(),
        shippingAddress: formData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, 'orders'), orderData);
      clearCart();
      navigate('/checkout-success', { state: { orderId: docRef.id } });
    } catch (error) {
      console.error("Error placing order", error);
      alert("There was an error placing your order. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold tracking-tight text-gray-900 mb-10">Checkout</h1>
      
      <div className="lg:grid lg:grid-cols-12 lg:gap-x-12 lg:items-start">
        <div className="lg:col-span-7">
          <form onSubmit={handlePlaceOrder}>
            <h2 className="text-lg font-medium text-gray-900 mb-4">Contact Information</h2>
            <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4 mb-8">
              <div className="sm:col-span-2">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email address</label>
                <div className="mt-1">
                  <input required type="email" id="email" name="email" value={formData.email} onChange={handleChange} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-black focus:border-black sm:text-sm border p-2" />
                </div>
              </div>
            </div>

            <h2 className="text-lg font-medium text-gray-900 mb-4">Shipping Information</h2>
             <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
              <div className="sm:col-span-2">
                <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                <div className="mt-1">
                  <input required type="text" id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-black focus:border-black sm:text-sm border p-2" />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
                <div className="mt-1">
                  <input required type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-black focus:border-black sm:text-sm border p-2" />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                <div className="mt-1">
                  <input required type="text" id="address" name="address" value={formData.address} onChange={handleChange} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-black focus:border-black sm:text-sm border p-2" />
                </div>
              </div>
              <div>
                <label htmlFor="city" className="block text-sm font-medium text-gray-700">City</label>
                <div className="mt-1">
                  <input required type="text" id="city" name="city" value={formData.city} onChange={handleChange} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-black focus:border-black sm:text-sm border p-2" />
                </div>
              </div>
               <div>
                <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700">Postal Code</label>
                <div className="mt-1">
                  <input required type="text" id="postalCode" name="postalCode" value={formData.postalCode} onChange={handleChange} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-black focus:border-black sm:text-sm border p-2" />
                </div>
              </div>
            </div>

            <div className="mt-10">
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-black border border-transparent rounded-full shadow-sm py-3 px-4 text-base font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 disabled:opacity-50"
              >
                {loading ? 'Processing...' : 'Place Order'}
              </button>
            </div>
          </form>
        </div>

        <div className="mt-16 lg:mt-0 lg:col-span-5">
           <div className="bg-gray-50 rounded-lg px-4 py-6 sm:p-6 lg:p-8">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Order summary</h2>
              <ul className="divide-y divide-gray-200 text-sm mb-6">
                {items.map(item => (
                  <li key={item.cartItemId} className="py-4 flex items-center justify-between">
                     <div className="flex items-center">
                        <img src={item.image} alt="" className="w-12 h-12 rounded object-cover mr-4" />
                        <div>
                           <p className="font-medium text-gray-900">{item.name}</p>
                           <p className="text-gray-500 text-xs">Qty: {item.quantity} {item.size ? `| Size: ${item.size}` : ''} {item.color ? `| Color: ${item.color}` : ''}</p>
                        </div>
                     </div>
                     <p className="font-medium text-gray-900">₦{(item.price * item.quantity).toLocaleString()}</p>
                  </li>
                ))}
              </ul>
              <div className="border-t border-gray-200 pt-4 flex items-center justify-between text-base font-medium text-gray-900">
                <dt>Total</dt>
                <dd>₦{total().toLocaleString()}</dd>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
