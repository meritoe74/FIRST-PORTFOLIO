import { Link } from 'react-router-dom';
import { useCartStore } from '../stores/useCartStore';
import { Trash2, Plus, Minus } from 'lucide-react';

export default function Cart() {
  const { items, removeItem, updateQuantity, total } = useCartStore();

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h2 className="text-2xl font-bold tracking-tight text-gray-900 mb-4">Your cart is empty</h2>
        <p className="text-gray-500 mb-8">Looks like you haven't added anything to your cart yet.</p>
        <Link to="/shop" className="inline-block bg-black text-white px-8 py-3 rounded-full font-medium hover:bg-gray-900 transition-colors">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold tracking-tight text-gray-900 mb-10">Shopping Cart</h1>
      
      <div className="lg:grid lg:grid-cols-12 lg:gap-x-12 lg:items-start">
        <div className="lg:col-span-8">
          <ul role="list" className="border-t border-b border-gray-200 divide-y divide-gray-200">
            {items.map((item) => (
              <li key={item.cartItemId} className="flex py-6 sm:py-10">
                <div className="shrink-0">
                  <img
                    src={item.image || 'https://via.placeholder.com/150'}
                    alt={item.name}
                    className="w-24 h-24 rounded-md object-cover object-center sm:w-32 sm:h-32"
                  />
                </div>

                <div className="ml-4 flex-1 flex flex-col justify-between sm:ml-6">
                  <div className="relative pr-9 sm:grid sm:grid-cols-2 sm:gap-x-6 sm:pr-0">
                    <div>
                      <div className="flex justify-between">
                        <h3 className="text-sm">
                          <Link to={`/product/${item.productId}`} className="font-medium text-gray-700 hover:text-gray-800">
                            {item.name}
                          </Link>
                        </h3>
                      </div>
                      <div className="mt-1 flex text-sm">
                        {item.color && (
                          <p className="text-gray-500 border-r border-gray-200 pr-2 mr-2">{item.color}</p>
                        )}
                        {item.size && (
                          <p className="text-gray-500">{item.size}</p>
                        )}
                      </div>
                      <p className="mt-1 text-sm font-medium text-gray-900">₦{item.price.toLocaleString()}</p>
                    </div>

                    <div className="mt-4 sm:mt-0 sm:pr-9 flex items-center justify-between sm:justify-end">
                       <div className="flex items-center border border-gray-300 rounded-md">
                          <button 
                             onClick={() => updateQuantity(item.cartItemId, Math.max(1, item.quantity - 1))}
                             className="px-2 py-1 text-gray-600 hover:text-gray-900"
                          >
                             <Minus className="h-4 w-4" />
                          </button>
                          <span className="px-4 py-1 text-sm font-medium border-x border-gray-300">{item.quantity}</span>
                          <button 
                             onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                             className="px-2 py-1 text-gray-600 hover:text-gray-900"
                          >
                             <Plus className="h-4 w-4" />
                          </button>
                       </div>

                      <div className="absolute top-0 right-0 sm:top-0 sm:right-0">
                        <button 
                          onClick={() => removeItem(item.cartItemId)}
                          type="button" 
                          className="-m-2 p-2 inline-flex text-gray-400 hover:text-gray-500"
                        >
                          <span className="sr-only">Remove</span>
                          <Trash2 className="h-5 w-5" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <section aria-labelledby="summary-heading" className="mt-16 bg-gray-50 rounded-lg px-4 py-6 sm:p-6 lg:p-8 lg:mt-0 lg:col-span-4">
          <h2 id="summary-heading" className="text-lg font-medium text-gray-900">Order summary</h2>

          <dl className="mt-6 space-y-4 text-sm text-gray-600">
            <div className="flex items-center justify-between">
              <dt>Subtotal</dt>
              <dd className="font-medium text-gray-900">₦{total().toLocaleString()}</dd>
            </div>
            <div className="flex items-center justify-between border-t border-gray-200 pt-4">
              <dt className="text-base font-medium text-gray-900">Order total</dt>
              <dd className="text-base font-medium text-gray-900">₦{total().toLocaleString()}</dd>
            </div>
          </dl>

          <div className="mt-6">
            <Link
              to="/checkout"
              className="w-full bg-black border border-transparent rounded-full shadow-sm py-3 px-4 text-base font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 block text-center"
            >
              Checkout
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
