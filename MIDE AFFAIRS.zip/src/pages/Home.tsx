import { Link } from 'react-router-dom';
import { useSettingsStore } from '../stores/useSettingsStore';
import { useEffect, useState } from 'react';
import { collection, getDocs, query, limit, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Category } from '../types';
import HairMarquee from '../components/HairMarquee';

export default function Home() {
  const settings = useSettingsStore((state) => state.settings);
  const loadingSettings = useSettingsStore((state) => state.loading);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const pQuery = query(collection(db, 'products'), orderBy('createdAt', 'desc'), limit(8));
        const pSnap = await getDocs(pQuery);
        
        setFeaturedProducts(pSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoadingProducts(false);
      }
    }
    fetchData();
  }, []);

  if (loadingSettings) return <div className="h-screen flex items-center justify-center">Loading...</div>;

  const heroBanner = settings?.heroBanners?.[0] || {
    title: 'New Collection',
    subtitle: 'Discover the latest trends',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=1200&h=800&fit=crop',
    link: '/shop',
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={heroBanner.image} alt={heroBanner.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/40" />
        </div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold font-serif tracking-tight text-white mb-6">
            {heroBanner.title}
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl mx-auto font-light">
            {heroBanner.subtitle}
          </p>
          <Link
            to={heroBanner.link || '/shop'}
            className="inline-block bg-white text-black px-8 py-4 rounded-full font-medium tracking-wide hover:bg-gray-100 transition-colors"
          >
            Shop Now
          </Link>
        </div>
      </section>

      {/* Morphism Marquee Section */}
      <HairMarquee />

      {/* Featured Products */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold font-serif text-gray-900 mb-4">Latest Arrivals</h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            Explore our newest premium hair and wigs, carefully curated for you.
          </p>
        </div>

        {loadingProducts ? (
          <div className="flex justify-center p-12">Loading products...</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.length === 0 ? (
              <div className="col-span-1 sm:col-span-2 lg:col-span-4 text-center py-12 text-gray-500">
                Products coming soon.
              </div>
            ) : (
              featuredProducts.map((product) => (
                <Link key={product.id} to={`/product/${product.id}`} className="group block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-[#faf9f8] mb-4 rounded-xl border border-gray-100/50 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)]">
                    <img
                      src={product.images[0] || 'https://via.placeholder.com/400x500'}
                      alt={product.name}
                      className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-700"
                    />
                    {product.isFeatured && (
                       <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md text-black text-[10px] uppercase tracking-wider font-bold px-3 py-1.5 rounded-full shadow-sm">
                         Featured
                       </div>
                    )}
                  </div>
                  <h3 className="text-sm font-medium text-gray-900 group-hover:underline underline-offset-4 font-serif">
                    {product.name}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">
                    ₦{product.price.toLocaleString()}
                  </p>
                </Link>
              ))
            )}
          </div>
        )}
        
        <div className="mt-16 text-center">
          <Link to="/shop" className="inline-block border border-gray-300 text-gray-900 px-8 py-3 rounded-full font-medium hover:bg-gray-50 transition-colors">
            View All Products
          </Link>
        </div>
      </section>
    </div>
  );
}
