import { useState, useEffect } from 'react';
import React from 'react';
import { collection, doc, getDoc, setDoc, addDoc, serverTimestamp, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { useNavigate, useParams } from 'react-router-dom';
import { Category, Texture } from '../../types';
import { compressImage } from '../../utils/imageUpload';

export default function AdminProductForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [textures, setTextures] = useState<Texture[]>([]);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    categoryId: '',
    texture: '',
    price: '',
    images: [] as string[],
    sizes: '',
    colors: '',
    stock: '',
    isFeatured: false
  });

  useEffect(() => {
    async function fetchData() {
      const catSnap = await getDocs(collection(db, 'categories'));
      setCategories(catSnap.docs.map(d => ({ id: d.id, ...d.data() } as Category)));

      const texSnap = await getDocs(collection(db, 'textures'));
      setTextures(texSnap.docs.map(d => ({ id: d.id, ...d.data() } as Texture)));

      if (id) {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setFormData({
            name: data.name || '',
            description: data.description || '',
            categoryId: data.categoryId || '',
            texture: data.texture || '',
            price: data.price?.toString() || '',
            images: data.images || [],
            sizes: (data.sizes || []).join(', '),
            colors: (data.colors || []).join(', '),
            stock: data.stock?.toString() || '',
            isFeatured: data.isFeatured || false
          });
        }
      }
    }
    fetchData();
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;
    setFormData({ ...formData, [e.target.name]: value });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      try {
        setLoading(true);
        const newImages = [];
        for (let i = 0; i < e.target.files.length; i++) {
          const file = e.target.files[i];
          const compressedBase64 = await compressImage(file);
          newImages.push(compressedBase64);
        }
        setFormData((prev) => ({ ...prev, images: [...prev.images, ...newImages] }));
      } catch (err: any) {
        console.error("Error uploading image:", err);
        alert(err.message || "Error loading or compressing image. It might be too large.");
      } finally {
        setLoading(false);
      }
    }
  };

  const removeImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const productData = {
        name: formData.name,
        description: formData.description,
        categoryId: formData.categoryId,
        texture: formData.texture,
        price: Number(formData.price),
        images: formData.images,
        sizes: formData.sizes.split(',').map(s => s.trim()).filter(Boolean),
        colors: formData.colors.split(',').map(s => s.trim()).filter(Boolean),
        stock: Number(formData.stock),
        isFeatured: formData.isFeatured,
        updatedAt: serverTimestamp()
      };

      if (id) {
        await setDoc(doc(db, 'products', id), productData, { merge: true });
      } else {
        await addDoc(collection(db, 'products'), {
          ...productData,
          createdAt: serverTimestamp()
        });
      }
      navigate('/admin/products');
    } catch (error) {
       console.error(error);
       alert("Error saving product");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl pb-20">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">{id ? 'Edit Product' : 'Add New Product'}</h1>
      </div>

      <form onSubmit={handleSave} className="space-y-8 bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700">Product Name</label>
            <input required type="text" name="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
          </div>
          
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea required rows={4} name="description" value={formData.description} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
          </div>

           <div>
            <label className="block text-sm font-medium text-gray-700">Category</label>
            <select required name="categoryId" value={formData.categoryId} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2">
              <option value="">Select category...</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

           <div>
            <label className="block text-sm font-medium text-gray-700">Signature Texture (Optional)</label>
            <select name="texture" value={formData.texture} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2">
              <option value="">None / Not specific</option>
              {textures.map(t => <option key={t.id} value={t.name}>{t.name}</option>)}
            </select>
          </div>

           <div>
            <label className="block text-sm font-medium text-gray-700">Price (₦)</label>
            <input required type="number" min="0" name="price" value={formData.price} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
          </div>

          <div className="sm:col-span-2">
             <label className="block text-sm font-medium text-gray-700 mb-2">Product Images</label>
             <div className="flex flex-wrap gap-4 mb-4">
               {formData.images.map((img, i) => (
                 <div key={i} className="relative w-24 h-24 border rounded overflow-hidden">
                   <img src={img} alt="Product" className="w-full h-full object-cover" />
                   <button type="button" onClick={() => removeImage(i)} className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">x</button>
                 </div>
               ))}
               <label className="w-24 h-24 border-2 border-dashed border-gray-300 rounded flex items-center justify-center cursor-pointer hover:bg-gray-50">
                 <span className="text-gray-500 text-2xl">+</span>
                 <input type="file" multiple accept="image/*" onChange={handleImageUpload} className="hidden" />
               </label>
             </div>
          </div>

           <div>
             <label className="block text-sm font-medium text-gray-700">Sizes (comma separated, e.g. S, M, L)</label>
             <input type="text" name="sizes" value={formData.sizes} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
          </div>

           <div>
             <label className="block text-sm font-medium text-gray-700">Colors (comma separated, e.g. Red, Blue)</label>
             <input type="text" name="colors" value={formData.colors} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
          </div>

           <div>
            <label className="block text-sm font-medium text-gray-700">Stock Quantity</label>
            <input required type="number" min="0" name="stock" value={formData.stock} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
          </div>

           <div className="flex items-center mt-6">
            <input type="checkbox" id="isFeatured" name="isFeatured" checked={formData.isFeatured} onChange={handleChange} className="h-4 w-4 text-black focus:ring-black border-gray-300 rounded" />
            <label htmlFor="isFeatured" className="ml-2 block text-sm text-gray-900">Feature on Homepage</label>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-gray-200 gap-4">
          <button type="button" onClick={() => navigate('/admin/products')} className="bg-white border border-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={loading} className="bg-black text-white px-6 py-2 rounded-md hover:bg-gray-900 disabled:opacity-50">
            {loading ? 'Saving...' : 'Save Product'}
          </button>
        </div>
      </form>
    </div>
  );
}
