import { useState, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { Settings } from '../../types';
import { Image as ImageIcon } from 'lucide-react';
import { compressImage } from '../../utils/imageUpload';

export default function AdminSettings() {
  const [settings, setSettings] = useState<Settings>({
    businessName: '',
    email: '',
    phone: '',
    whatsapp: '',
    instagram: '',
    tiktok: '',
    facebook: '',
    youtube: '',
    xLink: '',
    storeAddress: '',
    heroBanners: [{ id: '1', title: '', subtitle: '', image: '', link: '' }],
    aboutSettings: { ceoName: '', ceoTitle: '', biography: '', profileImage: '' }
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState(false);
  const [uploadingAbout, setUploadingAbout] = useState(false);
  const [uploadingHero, setUploadingHero] = useState(false);

  useEffect(() => {
    async function fetchSettings() {
      try {
        const docRef = doc(db, 'settings', 'global');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data() as Settings;
          if (!data.heroBanners || data.heroBanners.length === 0) {
             data.heroBanners = [{ id: '1', title: '', subtitle: '', image: '', link: '' }];
          }
          if (!data.aboutSettings) {
             data.aboutSettings = { ceoName: '', ceoTitle: '', biography: '', profileImage: '' };
          }
          setSettings(data);
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }
    fetchSettings();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setSettings({ ...settings, [e.target.name]: e.target.value });
  };

  const handleHeroChange = (field: string, value: string) => {
     const newBanners = [...settings.heroBanners];
     newBanners[0] = { ...newBanners[0], [field]: value };
     setSettings({ ...settings, heroBanners: newBanners });
  };

  const handleAboutChange = (field: string, value: string) => {
     setSettings({ ...settings, aboutSettings: { ...settings.aboutSettings!, [field]: value } });
  };

  const handleHeroImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      try {
        setUploadingHero(true);
        const compressedBase64 = await compressImage(e.target.files[0]);
        handleHeroChange('image', compressedBase64);
      } catch (err: any) {
        alert(err.message || "Error uploading image format or size.");
      } finally {
        setUploadingHero(false);
      }
    }
  };

  const handleAboutImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      try {
        setUploadingAbout(true);
        const compressedBase64 = await compressImage(e.target.files[0]);
        handleAboutChange('profileImage', compressedBase64);
      } catch (err: any) {
        alert(err.message || "Error uploading image format or size.");
      } finally {
        setUploadingAbout(false);
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await setDoc(doc(db, 'settings', 'global'), settings, { merge: true });
      alert("Settings saved successfully.");
    } catch (error) {
      console.error(error);
      alert("Error saving settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleSeedData = async () => {
    setSeeding(true);
    try {
      const { autoSeedProducts, autoSeedCategories, autoSeedTextures } = await import('../../utils/seedData');
      await autoSeedProducts();
      await autoSeedCategories();
      await autoSeedTextures();
      setSeedSuccess(true);
      setTimeout(() => setSeedSuccess(false), 3000);
    } catch (err) {
      console.error("Error seeding data", err);
    } finally {
      setSeeding(false);
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl pb-20">
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold tracking-tight">Website Settings</h1>
        <button type="button" onClick={handleSeedData} disabled={seeding} className="bg-gray-100 text-gray-700 border border-gray-300 px-4 py-2 rounded-md hover:bg-gray-200 disabled:opacity-50 text-sm font-medium">
          {seedSuccess ? 'Import Successful!' : seeding ? 'Importing...' : 'Force Import Demo Data'}
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        
        {/* Profile / About Page Settings */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
           <h3 className="text-lg font-medium text-gray-900 mb-4">About Page & Profile Picture</h3>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                 <label className="block text-sm font-medium text-gray-700 mb-2">Profile Picture (CEO / About)</label>
                 {settings.aboutSettings?.profileImage ? (
                    <div className="relative w-32 h-32 mb-2 border rounded overflow-hidden">
                      <img src={settings.aboutSettings.profileImage} alt="Profile" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => handleAboutChange('profileImage', '')} className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">x</button>
                    </div>
                  ) : (
                    <label className="w-32 h-32 border-2 border-dashed border-gray-300 rounded flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 mb-2 text-gray-500">
                      <ImageIcon className="w-6 h-6 mb-1" />
                      <span className="text-xs">Upload Image</span>
                      <input type="file" accept="image/*" onChange={handleAboutImageUpload} className="hidden" disabled={uploadingAbout} />
                    </label>
                  )}
                  {uploadingAbout && <p className="text-xs text-gray-500">Processing image...</p>}
              </div>

              <div className="space-y-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Name (e.g. Adeyemi Ayomide Grace)</label>
                    <input type="text" value={settings.aboutSettings?.ceoName || ''} onChange={(e) => handleAboutChange('ceoName', e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
                 </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Title (e.g. Founder & CEO)</label>
                    <input type="text" value={settings.aboutSettings?.ceoTitle || ''} onChange={(e) => handleAboutChange('ceoTitle', e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
                 </div>
              </div>
           </div>
           <div className="mt-4">
               <label className="block text-sm font-medium text-gray-700">Biography / About Details</label>
               <textarea value={settings.aboutSettings?.biography || ''} onChange={(e) => handleAboutChange('biography', e.target.value)} rows={6} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2"></textarea>
               <p className="text-xs text-gray-500 mt-1">This text appears on the About page.</p>
           </div>
        </div>

        {/* Hero Section Banner */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
           <h3 className="text-lg font-medium text-gray-900 mb-4">Hero Banner (Front Page)</h3>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                 <label className="block text-sm font-medium text-gray-700 mb-2">Hero Background Image</label>
                 {settings.heroBanners?.[0]?.image ? (
                    <div className="relative w-full h-40 mb-2 border rounded overflow-hidden">
                      <img src={settings.heroBanners[0].image} alt="Hero" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => handleHeroChange('image', '')} className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm shadow">x</button>
                    </div>
                  ) : (
                    <label className="w-full h-40 border-2 border-dashed border-gray-300 rounded flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 mb-2 text-gray-500 bg-gray-50">
                      <ImageIcon className="w-8 h-8 mb-2" />
                      <span className="text-sm">Upload Hero Image</span>
                      <input type="file" accept="image/*" onChange={handleHeroImageUpload} className="hidden" disabled={uploadingHero} />
                    </label>
                  )}
                  {uploadingHero && <p className="text-xs text-gray-500">Processing image...</p>}
              </div>

              <div className="space-y-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Big Headline</label>
                    <input type="text" value={settings.heroBanners?.[0]?.title || ''} onChange={(e) => handleHeroChange('title', e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" placeholder="e.g. Luxury Hair Made For You" />
                 </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Subtitle (Optional)</label>
                    <input type="text" value={settings.heroBanners?.[0]?.subtitle || ''} onChange={(e) => handleHeroChange('subtitle', e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
                 </div>
              </div>
           </div>
        </div>

        {/* General Details */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-4">General Information</h3>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">Business Name</label>
              <input type="text" name="businessName" value={settings.businessName} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700">Email Address</label>
              <input type="email" name="email" value={settings.email} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700">Phone Number</label>
              <input type="text" name="phone" value={settings.phone} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700">Store Address</label>
              <input type="text" name="storeAddress" value={settings.storeAddress} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Social Media & Social Links</h3>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
             <div>
              <label className="block text-sm font-medium text-gray-700">WhatsApp Number</label>
              <input type="text" name="whatsapp" value={settings.whatsapp} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Instagram Username</label>
              <input type="text" name="instagram" value={settings.instagram} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700">TikTok Username</label>
              <input type="text" name="tiktok" value={settings.tiktok} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700">Facebook URL</label>
              <input type="text" name="facebook" value={settings.facebook} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
            </div>
          </div>
        </div>

        <div className="flex justify-start pt-4">
          <button type="submit" disabled={saving} className="bg-black text-white px-8 py-3 rounded-md hover:bg-gray-900 disabled:opacity-50 text-base font-bold shadow-md">
            {saving ? 'Saving Changes...' : 'Save Settings'}
          </button>
        </div>
      </form>
    </div>
  );
}
