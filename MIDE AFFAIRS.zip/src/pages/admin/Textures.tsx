import { useState, useEffect } from 'react';
import { collection, query, getDocs, deleteDoc, doc, addDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { Texture } from '../../types';
import { Trash2, Edit2, X, Check, Image as ImageIcon, Plus } from 'lucide-react';
import { compressImage } from '../../utils/imageUpload';

export default function AdminTextures() {
  const [textures, setTextures] = useState<Texture[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTexture, setNewTexture] = useState({ name: '', image: '' });
  
  // For editing the main texture details (name, banner)
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTexture, setEditTexture] = useState<{name: string, image: string}>({ name: '', image: '' });
  
  const [uploading, setUploading] = useState(false);
  const [galleryUploadingId, setGalleryUploadingId] = useState<string | null>(null);

  const fetchTextures = async () => {
    try {
      const snap = await getDocs(query(collection(db, 'textures')));
      setTextures(snap.docs.map(d => ({ id: d.id, ...d.data() } as Texture)));
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTextures();
  }, []);

  useEffect(() => {
    if (!loading && textures.length === 0) {
      import('../../utils/seedData').then(async ({ autoSeedTextures }) => {
        setLoading(true);
        await autoSeedTextures();
        await fetchTextures();
      });
    }
  }, [loading, textures.length]);

  const handleDelete = async (id: string) => {
    if(!window.confirm("Are you sure you want to delete this texture?")) return;
    await deleteDoc(doc(db, 'textures', id));
    fetchTextures();
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, isEdit: boolean) => {
    if (e.target.files && e.target.files[0]) {
      try {
        setUploading(true);
        const compressedBase64 = await compressImage(e.target.files[0]);
        if (isEdit) {
          setEditTexture({ ...editTexture, image: compressedBase64 });
        } else {
          setNewTexture({ ...newTexture, image: compressedBase64 });
        }
      } catch (err: any) {
        console.error("Error uploading image:", err);
        alert(err.message || "Error uploading image. Try a smaller file.");
      } finally {
        setUploading(false);
      }
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTexture.name || !newTexture.image) return;
    try {
      setUploading(true);
      await addDoc(collection(db, 'textures'), { ...newTexture, galleryImages: [], createdAt: serverTimestamp() });
      setNewTexture({ name: '', image: '' });
      fetchTextures();
    } catch (err: any) {
      console.error("error adding texture", err);
      alert(err.message || "Error adding texture. The image might be too large.");
    } finally {
      setUploading(false);
    }
  };

  const startEdit = (tex: Texture) => {
    setEditingId(tex.id);
    setEditTexture({ name: tex.name, image: tex.image || '' });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditTexture({ name: '', image: '' });
  };

  const saveEdit = async (id: string) => {
    if (!editTexture.name || !editTexture.image) return;
    try {
      await updateDoc(doc(db, 'textures', id), { name: editTexture.name, image: editTexture.image });
      setEditingId(null);
      fetchTextures();
    } catch (err) {
      console.error("error updating texture", err);
    }
  };

  const uploadGalleryImage = async (e: React.ChangeEvent<HTMLInputElement>, texture: Texture) => {
    if (e.target.files && e.target.files[0]) {
      try {
        setGalleryUploadingId(texture.id);
        const compressedBase64 = await compressImage(e.target.files[0]);
        const currentGallery = texture.galleryImages || [];
        const newGallery = [...currentGallery, compressedBase64];
        await updateDoc(doc(db, 'textures', texture.id), { galleryImages: newGallery });
        fetchTextures();
      } catch (err: any) {
        console.error("Error uploading gallery image:", err);
        alert(err.message || "Error uploading image. Try a smaller file.");
      } finally {
         // Clear input
         e.target.value = '';
         setGalleryUploadingId(null);
      }
    }
  };

  const removeGalleryImage = async (texture: Texture, index: number) => {
    if(!window.confirm("Remove this image from the gallery?")) return;
    try {
       const currentGallery = texture.galleryImages || [];
       const newGallery = currentGallery.filter((_, i) => i !== index);
       await updateDoc(doc(db, 'textures', texture.id), { galleryImages: newGallery });
       fetchTextures();
    } catch (err) {
       console.error("Error removing gallery image:", err);
       alert("Error removing image.");
    }
  };

  return (
    <div className="pb-20">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Our Signature Textures</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <form onSubmit={handleCreate} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 sticky top-6">
             <h3 className="text-lg font-medium text-gray-900 mb-4">Add Texture</h3>
             <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Name (e.g. Bone Straight)</label>
                  <input required type="text" value={newTexture.name} onChange={e => setNewTexture({...newTexture, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
                </div>
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Main Banner Image</label>
                  {newTexture.image ? (
                    <div className="relative w-full h-32 mb-2 border rounded overflow-hidden">
                      <img src={newTexture.image} alt="Preview" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => setNewTexture({...newTexture, image: ''})} className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">x</button>
                    </div>
                  ) : (
                    <label className="w-full h-32 border-2 border-dashed border-gray-300 rounded flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 mb-2 text-gray-500">
                      <ImageIcon className="w-6 h-6 mb-1" />
                      <span className="text-sm">Upload Image</span>
                      <input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, false)} className="hidden" disabled={uploading} />
                    </label>
                  )}
                  {uploading && !galleryUploadingId && <p className="text-xs text-gray-500">Processing image...</p>}
                </div>
                <button type="submit" disabled={uploading || !newTexture.image} className="w-full bg-black text-white px-4 py-2 rounded-md hover:bg-gray-900 font-medium text-sm disabled:opacity-50">
                  Add Texture
                </button>
             </div>
          </form>
        </div>

        <div className="lg:col-span-2">
          {loading ? (
            <div>Loading Textures...</div>
          ) : textures.length === 0 ? (
            <div className="bg-white p-8 text-center rounded-lg shadow-sm border border-gray-200">
               <p className="text-gray-500">No signature textures found. Please create one.</p>
            </div>
          ) : (
             <div className="space-y-6">
                {textures.map((tex) => (
                   <div key={tex.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                      {/* Header part */}
                      <div className="p-4 border-b border-gray-100 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                         {editingId === tex.id ? (
                            <div className="flex-1 w-full flex flex-col sm:flex-row gap-4 items-center">
                               <div className="relative w-20 h-20 shrink-0 border rounded">
                                  {editTexture.image ? (
                                    <>
                                     <img src={editTexture.image} alt={editTexture.name} className="w-full h-full object-cover" />
                                     <button type="button" onClick={() => setEditTexture({...editTexture, image: ''})} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px] z-10">x</button>
                                    </>
                                  ) : (
                                    <label className="w-full h-full bg-gray-100 flex items-center justify-center cursor-pointer hover:bg-gray-200">
                                       <ImageIcon className="w-5 h-5 text-gray-400" />
                                       <input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, true)} className="hidden" />
                                    </label>
                                  )}
                               </div>
                               <input type="text" value={editTexture.name} onChange={e => setEditTexture({...editTexture, name: e.target.value})} className="border-gray-300 rounded focus:ring-black focus:border-black border p-2 flex-1 w-full" placeholder="Texture Name" />
                               
                               <div className="flex gap-2 w-full sm:w-auto">
                                  <button onClick={() => saveEdit(tex.id)} disabled={!editTexture.image || !editTexture.name} className="bg-green-600 text-white px-3 py-2 rounded text-sm font-medium hover:bg-green-700 disabled:opacity-50">Save</button>
                                  <button onClick={cancelEdit} className="bg-gray-200 text-gray-700 px-3 py-2 rounded text-sm font-medium hover:bg-gray-300">Cancel</button>
                               </div>
                            </div>
                         ) : (
                           <>
                             <div className="w-20 h-20 shrink-0 rounded overflow-hidden">
                                <img src={tex.image} alt={tex.name} className="w-full h-full object-cover" />
                             </div>
                             <div className="flex-1">
                                <h3 className="text-lg font-bold text-gray-900">{tex.name}</h3>
                                <p className="text-xs text-gray-500 mt-1">Main Banner Image</p>
                             </div>
                             <div className="flex gap-2">
                                <button onClick={() => startEdit(tex)} className="p-2 text-blue-600 hover:bg-blue-50 rounded transition-colors bg-blue-50/50">
                                  <Edit2 className="w-4 h-4" />
                                </button>
                                <button onClick={() => handleDelete(tex.id)} className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors bg-red-50/50">
                                  <Trash2 className="w-4 h-4" />
                                </button>
                             </div>
                           </>
                         )}
                      </div>

                      {/* Gallery Editor Part */}
                      <div className="p-4 bg-gray-50/50">
                         <div className="flex justify-between items-center mb-3">
                            <h4 className="font-semibold text-gray-800 text-sm">Gallery Images ({tex.galleryImages?.length || 0})</h4>
                         </div>
                         <div className="flex flex-wrap gap-3">
                            {(tex.galleryImages || []).map((gImg, idx) => (
                               <div key={idx} className="relative w-24 h-24 border border-gray-200 rounded-lg overflow-hidden group shadow-sm bg-white">
                                  <img src={gImg} alt={`${tex.name} gallery ${idx}`} className="w-full h-full object-cover" />
                                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                     <button onClick={() => removeGalleryImage(tex, idx)} className="text-white p-2 hover:text-red-400">
                                        <Trash2 className="w-5 h-5" />
                                     </button>
                                  </div>
                               </div>
                            ))}
                            
                            <label className="w-24 h-24 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-white hover:border-gray-400 transition-colors bg-gray-50">
                              {galleryUploadingId === tex.id ? (
                                <span className="text-xs text-gray-500">Wait...</span>
                              ) : (
                                <>
                                  <Plus className="w-6 h-6 text-gray-400 mb-1" />
                                  <span className="text-[10px] text-gray-500 font-medium">Add Image</span>
                                  <input type="file" accept="image/*" onChange={(e) => uploadGalleryImage(e, tex)} className="hidden" disabled={galleryUploadingId === tex.id} />
                                </>
                              )}
                            </label>
                         </div>
                      </div>
                   </div>
                ))}
             </div>
          )}
        </div>
      </div>
    </div>
  );
}
