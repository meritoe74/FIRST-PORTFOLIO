import { useState, useEffect } from 'react';
import { collection, query, getDocs, deleteDoc, doc, addDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { Category } from '../../types';
import { Trash2, Edit2, X, Check, Image as ImageIcon } from 'lucide-react';
import { compressImage } from '../../utils/imageUpload';

export default function AdminCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCat, setNewCat] = useState({ name: '', image: '' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editCat, setEditCat] = useState({ name: '', image: '' });
  const [uploading, setUploading] = useState(false);

  const fetchCategories = async () => {
    try {
      const snap = await getDocs(query(collection(db, 'categories')));
      setCategories(snap.docs.map(d => ({ id: d.id, ...d.data() } as Category)));
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (!loading && categories.length === 0) {
      import('../../utils/seedData').then(async ({ autoSeedCategories }) => {
        setLoading(true);
        await autoSeedCategories();
        await fetchCategories();
      });
    }
  }, [loading, categories.length]);

  const handleDelete = async (id: string) => {
    await deleteDoc(doc(db, 'categories', id));
    fetchCategories();
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, isEdit: boolean) => {
    if (e.target.files && e.target.files[0]) {
      try {
        setUploading(true);
        const compressedBase64 = await compressImage(e.target.files[0]);
        if (isEdit) {
          setEditCat({ ...editCat, image: compressedBase64 });
        } else {
          setNewCat({ ...newCat, image: compressedBase64 });
        }
      } catch (err: any) {
        console.error("Error uploading image:", err);
        alert(err.message || "Error uploading image. Try a smaller file.");
      } finally {
        setUploading(false);
      }
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCat.name) return;
    try {
      await addDoc(collection(db, 'categories'), { ...newCat, createdAt: serverTimestamp() });
      setNewCat({ name: '', image: '' });
      fetchCategories();
    } catch (err) {
      console.error("error adding category", err);
    }
  };

  const startEdit = (cat: Category) => {
    setEditingId(cat.id);
    setEditCat({ name: cat.name, image: cat.image || '' });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditCat({ name: '', image: '' });
  };

  const saveEdit = async (id: string) => {
    if (!editCat.name) return;
    try {
      await updateDoc(doc(db, 'categories', id), { name: editCat.name, image: editCat.image });
      setEditingId(null);
      fetchCategories();
    } catch (err) {
      console.error("error updating category", err);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Categories</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <form onSubmit={handleCreate} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
             <h3 className="text-lg font-medium text-gray-900 mb-4">Add Category</h3>
             <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Name</label>
                  <input required type="text" value={newCat.name} onChange={e => setNewCat({...newCat, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-black focus:ring-black sm:text-sm border p-2" />
                </div>
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Image</label>
                  {newCat.image ? (
                    <div className="relative w-full h-32 mb-2 border rounded overflow-hidden">
                      <img src={newCat.image} alt="Preview" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => setNewCat({...newCat, image: ''})} className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">x</button>
                    </div>
                  ) : (
                    <label className="w-full h-32 border-2 border-dashed border-gray-300 rounded flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 mb-2 text-gray-500">
                      <ImageIcon className="w-6 h-6 mb-1" />
                      <span className="text-sm">Upload Image</span>
                      <input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, false)} className="hidden" disabled={uploading} />
                    </label>
                  )}
                  {uploading && <p className="text-xs text-gray-500">Processing image...</p>}
                </div>
                <button type="submit" disabled={uploading} className="w-full bg-black text-white px-4 py-2 rounded-md hover:bg-gray-900 font-medium text-sm disabled:opacity-50">
                  Add Category
                </button>
             </div>
          </form>
        </div>

        <div className="md:col-span-2">
          {loading ? (
            <div>Loading...</div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">Image</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {categories.map((cat) => (
                    <tr key={cat.id}>
                      {editingId === cat.id ? (
                        <>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {editCat.image ? (
                              <div className="relative h-10 w-10">
                                <img src={editCat.image} alt={editCat.name} className="h-10 w-10 rounded-md object-cover" />
                                <button type="button" onClick={() => setEditCat({...editCat, image: ''})} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]">x</button>
                              </div>
                            ) : (
                              <label className="h-10 w-10 bg-gray-100 rounded-md flex items-center justify-center text-gray-400 cursor-pointer hover:bg-gray-200">
                                <ImageIcon className="w-4 h-4" />
                                <input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, true)} className="hidden" disabled={uploading} />
                              </label>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <input type="text" value={editCat.name} onChange={e => setEditCat({...editCat, name: e.target.value})} className="text-sm border-gray-300 rounded focus:ring-black focus:border-black border p-1 w-full" />
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onClick={() => saveEdit(cat.id)} className="text-green-600 hover:text-green-900 mr-3">
                              <Check className="h-4 w-4" />
                            </button>
                            <button onClick={cancelEdit} className="text-gray-600 hover:text-gray-900">
                              <X className="h-4 w-4" />
                            </button>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {cat.image ? <img src={cat.image} alt={cat.name} className="h-10 w-10 rounded-md object-cover" /> : <div className="h-10 w-10 bg-gray-100 rounded-md flex items-center justify-center text-gray-400 text-xs text-center">No Img</div>}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {cat.name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onClick={() => startEdit(cat)} className="text-indigo-600 hover:text-indigo-900 mr-3">
                              <Edit2 className="h-4 w-4" />
                            </button>
                            <button onClick={() => handleDelete(cat.id)} className="text-red-600 hover:text-red-900">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                  {categories.length === 0 && (
                    <tr>
                      <td colSpan={3} className="px-6 py-8 text-center text-gray-500">No categories found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
