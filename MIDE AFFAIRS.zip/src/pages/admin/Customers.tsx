import { useState, useEffect } from 'react';
import { collection, query, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';

export default function AdminCustomers() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchCustomers() {
       // Since the prompt doesn't explicitly mention user auth outside admin, customers are derived from orders for now.
       // For a robust system, we would query the `users` collection.
       try {
        const q = query(collection(db, 'orders'));
        const snap = await getDocs(q);
        const userMap = new Map();
        snap.docs.forEach(doc => {
            const data = doc.data();
            if (data.userId && data.shippingAddress) {
               if (!userMap.has(data.userId)) {
                  userMap.set(data.userId, {
                      email: data.userId,
                      name: data.shippingAddress.fullName,
                      phone: data.shippingAddress.phone,
                      orderCount: 1,
                      totalSpent: data.total,
                      lastReview: "Excellent hair quality!" // Mock review data
                  });
               } else {
                  const existing = userMap.get(data.userId);
                  existing.orderCount += 1;
                  existing.totalSpent += data.total;
                  existing.lastReview = "Highly recommended, very soft."; // Update mock
               }
            }
        });
        setCustomers(Array.from(userMap.values()));
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }
    fetchCustomers();
  }, []);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Customers</h1>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Orders</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Spent</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Recent Review</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {customers.map((cust, i) => (
                <tr key={i}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {cust.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {cust.email}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {cust.orderCount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ₦{cust.totalSpent.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-[150px]">
                    "{cust.lastReview}"
                  </td>
                </tr>
              ))}
               {customers.length === 0 && (
                <tr>
                   <td colSpan={4} className="px-6 py-8 text-center text-gray-500">No customers found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
