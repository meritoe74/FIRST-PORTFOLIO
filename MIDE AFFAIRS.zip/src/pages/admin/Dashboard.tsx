import { useState, useEffect } from 'react';
import { collection, query, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { ShoppingBag, Users, DollarSign, Edit, Image as ImageIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useSettingsStore } from '../../stores/useSettingsStore';
import { Category, Product, Texture } from '../../types';
import HairMarquee from '../../components/HairMarquee';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ products: 0, orders: 0, revenue: 0 });
  const settings = useSettingsStore((state) => state.settings);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);

  useEffect(() => {
    async function fetchStats() {
      try {
        const prodSnap = await getDocs(query(collection(db, 'products')));
        const ordersSnap = await getDocs(query(collection(db, 'orders')));
        
        let revenue = 0;
        ordersSnap.docs.forEach(doc => {
            const data = doc.data();
            if (data.total) revenue += data.total;
        });

        setStats({
          products: prodSnap.size,
          orders: ordersSnap.size,
          revenue
        });

        // For visual preview
        setFeaturedProducts(prodSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)).slice(0, 4));

      } catch (error) {
         console.error("Error fetching stats");
      }
    }
    fetchStats();
  }, []);

  const heroBanner = settings?.heroBanners?.[0] || {
    title: 'New Collection',
    subtitle: 'Discover the latest trends',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=1200&h=800&fit=crop',
    link: '/shop',
  };

  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight mb-8">Dashboard Overview</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
           <div className="flex items-center justify-between">
              <div>
                 <p className="text-sm font-medium text-gray-500">Total Revenue</p>
                 <p className="text-3xl font-bold text-gray-900 mt-2">₦{stats.revenue.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center">
                 <DollarSign className="w-6 h-6" />
              </div>
           </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
           <div className="flex items-center justify-between">
              <div>
                 <p className="text-sm font-medium text-gray-500">Total Orders</p>
                 <p className="text-3xl font-bold text-gray-900 mt-2">{stats.orders}</p>
              </div>
              <div className="w-12 h-12 bg-gray-100 text-black rounded-full flex items-center justify-center">
                 <ShoppingBag className="w-6 h-6" />
              </div>
           </div>
        </div>

         <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
           <div className="flex items-center justify-between">
              <div>
                 <p className="text-sm font-medium text-gray-500">Total Products</p>
                 <p className="text-3xl font-bold text-gray-900 mt-2">{stats.products}</p>
              </div>
              <div className="w-12 h-12 bg-gray-100 text-black rounded-full flex items-center justify-center">
                 <Users className="w-6 h-6" />
              </div>
           </div>
        </div>
      </div>

      {/* Visual Editor Section */}
      <h2 className="text-2xl font-bold tracking-tight mb-6">Visual Frontpage Editor</h2>
      <div className="bg-gray-100 border border-gray-200 rounded-xl overflow-hidden mb-12 flex flex-col pointer-events-none relative">
         <div className="absolute inset-0 z-50 pointer-events-auto flex flex-col justify-between">
            {/* Overlay Clickable Regions mapping to admin pages */}
            <Link to="/admin/settings" className="h-[60vh] w-full flex items-center justify-center hover:bg-black/20 transition-all group relative border-b-2 border-dashed border-transparent hover:border-black/50 cursor-pointer text-transparent hover:text-white">
                <div className="bg-black/80 px-6 py-3 rounded-full flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity font-medium tracking-wide shadow-lg">
                    <Edit className="w-4 h-4" /> Edit Hero Section
                </div>
            </Link>
            
            <Link to="/admin/textures" className="h-[400px] w-full flex items-center justify-center hover:bg-black/10 transition-all group relative border-b-2 border-dashed border-transparent hover:border-black/50 cursor-pointer text-transparent hover:text-white">
                <div className="bg-black/80 px-6 py-3 rounded-full flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity font-medium tracking-wide shadow-lg">
                    <Edit className="w-4 h-4" /> Edit Signature Textures
                </div>
            </Link>

            <Link to="/admin/products" className="h-[600px] w-full flex items-center justify-center hover:bg-black/10 transition-all group relative cursor-pointer text-transparent hover:text-white">
                <div className="bg-black/80 px-6 py-3 rounded-full flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity font-medium tracking-wide shadow-lg">
                    <Edit className="w-4 h-4" /> Edit Products
                </div>
            </Link>
         </div>

         {/* Visual Preview scale-down visually similar to Home page */}
         <div className="w-full relative bg-white">
             {/* Hero Preview */}
             <div className="relative h-[60vh] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 z-0">
                  <img src={heroBanner.image} alt={heroBanner.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40" />
                </div>
                <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
                  <h1 className="text-5xl md:text-7xl font-bold font-serif tracking-tight text-white mb-6">
                    {heroBanner.title}
                  </h1>
                </div>
             </div>

             {/* Textures Preview */}
             <div className="h-[400px]">
                <HairMarquee />
             </div>

             {/* Products Preview */}
             <div className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full flex-grow h-[600px]">
                <div className="text-center mb-16">
                  <h2 className="text-3xl font-bold font-serif text-gray-900 mb-4">Latest Arrivals</h2>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
                  {featuredProducts.slice(0, 4).map((product) => (
                     <div key={product.id} className="block">
                        <div className="relative aspect-[3/4] overflow-hidden bg-[#faf9f8] mb-4 rounded-xl border border-gray-100/50">
                          <img src={product.images[0]} alt={product.name} className="object-cover w-full h-full" />
                        </div>
                        <h3 className="text-sm font-medium text-gray-900 font-serif">{product.name}</h3>
                     </div>
                  ))}
                </div>
             </div>
         </div>
      </div>
    </div>
  );
}
