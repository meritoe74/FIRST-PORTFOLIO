import { useState, useEffect } from 'react';
import { collection, query, getDocs, orderBy, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Category } from '../types';
import { Link, useSearchParams } from 'react-router-dom';

export default function Shop() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategory = searchParams.get('category') || 'all';
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        const catSnap = await getDocs(collection(db, 'categories'));
        setCategories(catSnap.docs.map(d => ({ id: d.id, ...d.data() } as Category)));

        let q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
        if (selectedCategory !== 'all') {
             q = query(collection(db, 'products'), where('categoryId', '==', selectedCategory));
        }
        const prodSnap = await getDocs(q);
        const prods = prodSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        setProducts(prods);
      } catch (error) {
        console.error("Error fetching shop data:", error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [selectedCategory]);

  const filteredProducts = products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900">Shop Collection</h1>
        <div className="flex space-x-2">
          <input 
            type="text" 
            placeholder="Search products..." 
            className="border border-gray-300 rounded-md px-4 py-2 text-sm focus:outline-none focus:border-black"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-48 xl:w-64 shrink-0">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-gray-900 mb-4">Categories</h2>
          <ul className="space-y-3 text-sm">
            <li>
              <button 
                onClick={() => setSearchParams(new URLSearchParams({ category: 'all' }))}
                className={`text-left w-full ${selectedCategory === 'all' ? 'font-medium text-black' : 'text-gray-500 hover:text-black'}`}
              >
                All Products
              </button>
            </li>
            {categories.map(cat => (
              <li key={cat.id}>
                <button 
                  onClick={() => setSearchParams(new URLSearchParams({ category: cat.id }))}
                  className={`text-left w-full ${selectedCategory === cat.id ? 'font-medium text-black' : 'text-gray-500 hover:text-black'}`}
                >
                  {cat.name}
                </button>
              </li>
            ))}
          </ul>
        </aside>

        <main className="flex-1">
          {loading ? (
            <div className="flex justify-center p-12">Loading...</div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProducts.map((product) => (
                <Link key={product.id} to={`/product/${product.id}`} className="group block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-[#faf9f8] mb-4 rounded-xl border border-gray-100/50 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)]">
                    <img
                      src={product.images[0] || 'https://via.placeholder.com/400x500'}
                      alt={product.name}
                      className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                  <h3 className="text-sm font-medium text-gray-900 group-hover:underline underline-offset-4 line-clamp-1 font-serif">
                    {product.name}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">
                    ₦{product.price.toLocaleString()}
                  </p>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-500 py-24">
              <p>No products found for your criteria.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
