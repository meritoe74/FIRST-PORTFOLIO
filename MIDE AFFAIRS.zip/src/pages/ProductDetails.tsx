import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Product } from '../types';
import { useCartStore } from '../stores/useCartStore';

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [size, setSize] = useState<string>('');
  const [color, setColor] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore(state => state.addItem);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchProduct() {
      if (!id) return;
      try {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setProduct({ id: docSnap.id, ...docSnap.data() } as Product);
        }
      } catch (error) {
        console.error("Error fetching product", error);
      } finally {
        setLoading(false);
      }
    }
    fetchProduct();
  }, [id]);

  if (loading) return <div className="h-screen flex items-center justify-center">Loading...</div>;
  if (!product) return <div className="h-screen flex items-center justify-center">Product not found.</div>;

  const handleAddToCart = () => {
    if (product.sizes?.length > 0 && !size) return alert('Please select a size');
    if (product.colors?.length > 0 && !color) return alert('Please select a color');

    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0] || '',
      quantity,
      size,
      color
    });
    navigate('/cart');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="lg:grid lg:grid-cols-2 lg:gap-x-12 xl:gap-x-16">
        <div className="flex flex-col-reverse lg:flex-row gap-4 mb-10 lg:mb-0">
          <div className="flex lg:flex-col gap-4 overflow-x-auto lg:overflow-visible lg:w-24 shrink-0">
            {product.images.map((img, idx) => (
              <button 
                key={idx} 
                onClick={() => setSelectedImage(idx)}
                className={`relative aspect-[3/4] w-20 lg:w-full overflow-hidden rounded-md ${selectedImage === idx ? 'ring-2 ring-black' : 'ring-1 ring-gray-200'}`}
              >
                <img src={img} alt="" className="object-cover w-full h-full" />
              </button>
            ))}
          </div>
          <div className="w-full aspect-[3/4] bg-[#faf9f8] rounded-xl border border-gray-100/50 shadow-sm overflow-hidden">
             <img src={product.images[selectedImage]} alt={product.name} className="w-full h-full object-cover" />
          </div>
        </div>

        <div className="mt-10 px-4 sm:px-0 lg:mt-0">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">{product.name}</h1>
          <div className="mt-3">
            <p className="text-2xl tracking-tight text-gray-900">₦{product.price.toLocaleString()}</p>
          </div>
          
          <div className="mt-6">
            <h3 className="sr-only">Description</h3>
            <div className="text-base text-gray-700 space-y-6 whitespace-pre-wrap">
               {product.description}
            </div>
          </div>

          <div className="mt-8 border-t border-gray-200 pt-8">
            {product.sizes?.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Size</h3>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={`border rounded-md py-2 px-4 text-sm font-medium focus:outline-none ${size === s ? 'border-transparent bg-black text-white' : 'border-gray-200 text-gray-900 hover:bg-gray-50'}`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {product.colors?.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Color</h3>
                <div className="flex flex-wrap gap-3">
                  {product.colors.map((c) => (
                    <button
                      key={c}
                      onClick={() => setColor(c)}
                      className={`border rounded-md py-2 px-4 text-sm font-medium focus:outline-none  ${color === c ? 'border-transparent bg-black text-white' : 'border-gray-200 text-gray-900 hover:bg-gray-50'}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-8 flex gap-4">
               <button
                  type="button"
                  onClick={handleAddToCart}
                  className="flex-1 bg-black border border-transparent rounded-full py-4 px-8 flex items-center justify-center text-base font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900"
                >
                  Add to Cart
                </button>
            </div>
            
            {product.stock <= 5 && product.stock > 0 && (
               <p className="mt-4 text-sm text-red-600">Only {product.stock} left in stock - order soon.</p>
            )}
             {product.stock === 0 && (
               <p className="mt-4 text-sm text-red-600">Out of stock.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
