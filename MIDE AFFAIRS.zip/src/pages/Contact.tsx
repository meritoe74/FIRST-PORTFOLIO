import { useSettingsStore } from '../stores/useSettingsStore';
import { Mail, Phone, MapPin, Instagram, Youtube, Send, MessageCircle } from 'lucide-react';
import React, { useState } from 'react';

export default function Contact() {
  const settings = useSettingsStore((state) => state.settings);
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    // Simulate sending email
    setTimeout(() => setStatus('success'), 1500);
  };

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-black min-h-[40vh] flex items-center justify-center">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1595425970377-c9703bc48b2d?q=80&w=2670&auto=format&fit=crop')] bg-cover bg-center opacity-30" />
        <div className="relative z-10 text-center px-4 max-w-2xl mx-auto mt-20">
          <h1 className="text-4xl md:text-5xl font-serif text-white font-bold mb-4 tracking-tight">Contact Us</h1>
          <p className="text-gray-300 text-lg font-light leading-relaxed">
            Whether you have a question about our collections, need styling advice, or assistance with an order, our team is here to help.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          
          {/* Contact Information */}
          <div className="space-y-12">
            <div>
              <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Get In Touch</h2>
              <p className="text-gray-600 font-light leading-relaxed mb-8">
                Experience premium customer service tailored to your needs. Reach out to us through any of the channels below and we will get back to you as soon as possible.
              </p>
            </div>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center shrink-0">
                   <Phone className="w-5 h-5 text-black" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 text-lg">WhatsApp & Calls</h3>
                  <p className="text-gray-500 mt-1">{settings?.phone || "+234 816 391 0487"}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center shrink-0">
                   <Mail className="w-5 h-5 text-black" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 text-lg">Email Address</h3>
                  <p className="text-gray-500 mt-1">{settings?.email || "Mideshairng@gmail.com"}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center shrink-0">
                   <MapPin className="w-5 h-5 text-black" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 text-lg">Store Address</h3>
                  <p className="text-gray-500 mt-1 leading-relaxed">
                    {settings?.storeAddress || "Lagos, Nigeria"}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-8 border-t border-gray-100">
               <h3 className="font-medium text-gray-900 text-lg mb-6">Connect With Us</h3>
               <div className="flex gap-4">
                 {settings?.instagram && (
                   <a href={settings.instagram} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors text-gray-600">
                      <Instagram className="w-5 h-5" />
                   </a>
                 )}
                 {settings?.youtube && (
                   <a href={settings.youtube} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors text-gray-600">
                      <Youtube className="w-5 h-5" />
                   </a>
                 )}
                 {settings?.phone && (
                   <a href={`https://wa.me/${settings.phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-green-50 text-green-600 border border-green-200 rounded-full flex items-center justify-center hover:bg-green-600 hover:text-white transition-colors shadow-sm">
                      <MessageCircle className="w-5 h-5" />
                   </a>
                 )}
               </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-gray-50 p-8 md:p-12 rounded-2xl border border-gray-100">
            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-8">Send a Message</h3>
            
            {status === 'success' ? (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-4">
                  <Send className="w-8 h-8 ml-1" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Message Sent!</h4>
                <p className="text-gray-500">Thank you for reaching out. We will get back to you shortly.</p>
                <button onClick={() => setStatus('idle')} className="mt-8 text-sm font-medium text-black underline underline-offset-4">Send another message</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input type="text" id="name" required className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition-all" placeholder="Jane Doe" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input type="email" id="email" required className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition-all" placeholder="jane@example.com" />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                  <input type="text" id="subject" required className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition-all" placeholder="Order Inquiry" />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea id="message" required rows={5} className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition-all reshape-none" placeholder="How can we help you?"></textarea>
                </div>
                <button type="submit" disabled={status === 'sending'} className="w-full bg-black text-white px-8 py-4 rounded-lg font-medium hover:bg-gray-900 transition-colors flex items-center justify-center gap-2 group disabled:opacity-70">
                  {status === 'sending' ? 'Sending...' : 'Send Message'}
                  {status !== 'sending' && <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
