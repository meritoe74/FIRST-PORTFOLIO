import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { collection, getDocs, query, orderBy, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Texture } from '../types';
import { ArrowLeft } from 'lucide-react';

export default function TextureGallery() {
  const { textureName } = useParams<{ textureName: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [textureData, setTextureData] = useState<Texture | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProductsAndTexture() {
      try {
        // Fetch texture meta to get the image
        if (textureName) {
           const tQuery = query(collection(db, 'textures'), where('name', '==', textureName));
           const tSnap = await getDocs(tQuery);
           if (!tSnap.empty) {
             setTextureData({ id: tSnap.docs[0].id, ...tSnap.docs[0].data() } as Texture);
           } else {
             // Fallback to fetch all textures and do case insensitive match locally if case is slightly off
             const allTSnap = await getDocs(collection(db, 'textures'));
             const tf = allTSnap.docs.find(d => d.data().name.toLowerCase() === textureName.toLowerCase());
             if (tf) setTextureData({ id: tf.id, ...tf.data() } as Texture);
           }
        }

        const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
        const snap = await getDocs(q);
        const allProducts = snap.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        // Filter locally finding any mention of textureName
        const matching = allProducts.filter(p => 
           p.name.toLowerCase().includes(textureName?.toLowerCase() || '') || 
           p.description.toLowerCase().includes(textureName?.toLowerCase() || '')
        );
        setProducts(matching);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    if (textureName) fetchProductsAndTexture();
  }, [textureName]);

  return (
    <div className="min-h-screen bg-white">
      {/* Texture Header Banner Section */}
      <div className="relative bg-gray-900 py-24 px-4 overflow-hidden border-b border-gray-100 min-h-[300px] flex items-end">
        {textureData?.image && (
          <div className="absolute inset-0 z-0">
             <img src={textureData.image} alt={textureName} className="w-full h-full object-cover" />
             <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10" />
          </div>
        )}
        <div className="max-w-7xl mx-auto flex flex-col gap-4 relative z-10 w-full mb-4">
          <div className="flex items-center gap-4">
            <Link to="/" className="text-white hover:text-white/80 transition-colors bg-white/10 p-2 rounded-full border border-white/20 backdrop-blur-sm">
              <ArrowLeft className="w-5 h-5" />
            </Link>
          </div>
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-white tracking-tight drop-shadow-lg">
            {textureName}
          </h1>
          <p className="text-white/80 max-w-xl font-light text-lg">
            Explore our curated selection of verified original {textureName?.toLowerCase()} hair collections.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
             {[1, 2, 3, 4].map(i => (
                <div key={i} className="animate-pulse flex flex-col gap-4">
                   <div className="bg-gray-100 aspect-[3/4] rounded-xl w-full"></div>
                   <div className="h-4 bg-gray-100 w-2/3 rounded"></div>
                   <div className="h-4 bg-gray-100 w-1/3 rounded"></div>
                </div>
             ))}
          </div>
        ) : (
          <>
            {/* Gallery Section */}
            {((textureData?.galleryImages && textureData.galleryImages.length > 0) || true) && (
              <div className="mb-20">
                <div className="flex items-center gap-4 mb-8">
                  <h2 className="text-2xl md:text-3xl font-serif font-bold text-gray-900">Style Gallery</h2>
                  <div className="flex-1 h-px bg-gray-200"></div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                  {(textureData?.galleryImages && textureData.galleryImages.length > 0 ? textureData.galleryImages : [
                    'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?w=800&q=80',
                    'https://images.unsplash.com/photo-1605980776566-0486c3ac7617?w=800&q=80',
                    'https://images.unsplash.com/photo-1595425970377-c9703bc48b2d?w=800&q=80',
                    'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=800&q=80'
                  ]).slice(0, 4).map((img, i) => (
                    <div key={i} className={`rounded-xl overflow-hidden shadow-sm relative group bg-gray-100 ${i % 3 === 0 ? 'aspect-square md:col-span-2 md:row-span-2' : 'aspect-[4/5]'}`}>
                      <img src={img} alt={`${textureName} style ${i}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                      <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Products Section */}
            {products.length > 0 ? (
              <div>
                <div className="flex items-center gap-4 mb-8">
                  <h2 className="text-2xl md:text-3xl font-serif font-bold text-gray-900">Shop This Texture</h2>
                  <div className="flex-1 h-px bg-gray-200"></div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {products.map((product) => (
                    <Link key={product.id} to={`/product/${product.id}`} className="group block">
                      <div className="relative aspect-[3/4] overflow-hidden bg-[#faf9f8] mb-4 rounded-xl border border-gray-100/50 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)]">
                        <img
                          src={product.images[0] || 'https://via.placeholder.com/400x500'}
                          alt={product.name}
                          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-700"
                        />
                        {product.isFeatured && (
                           <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md text-black text-[10px] uppercase tracking-wider font-bold px-3 py-1.5 rounded-full shadow-sm">
                             Featured
                           </div>
                        )}
                      </div>
                      <h3 className="text-sm font-medium text-gray-900 group-hover:underline underline-offset-4 font-serif">
                        {product.name}
                      </h3>
                      <p className="mt-1 text-sm text-gray-500">
                        ₦{product.price.toLocaleString()}
                      </p>
                    </Link>
                  ))}
                </div>
              </div>
            ) : (
               <div className="text-center py-20 px-4 max-w-xl mx-auto bg-gray-50 rounded-2xl border border-gray-100">
                 <h2 className="text-2xl font-serif text-gray-900 mb-4">No products found</h2>
                 <p className="text-gray-500 mb-8 font-light">We currently don't have any products specifically mapped to the "{textureName}" texture in our store yet. Please check back later.</p>
                 <Link to="/shop" className="inline-block bg-black text-white px-8 py-3 rounded-full hover:bg-gray-900 transition-colors font-medium text-sm">
                   Explore All Details
                 </Link>
               </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
