import { create } from 'zustand';
import { Settings } from '../types';
import { db } from '../firebase';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';

interface SettingsState {
  settings: Settings | null;
  loading: boolean;
  fetchSettings: () => void;
}

const defaultSettings: Settings = {
  businessName: "Mide's Affairs",
  email: 'Mideshairng@gmail.com',
  phone: '+2348163910487',
  whatsapp: '+2348163910487',
  instagram: 'mides_affairs',
  tiktok: 'Mides Affairs',
  facebook: '',
  youtube: '',
  xLink: '',
  storeAddress: 'Lagos, Nigeria',
  heroBanners: [
    {
      id: '1',
      title: 'Premium Luxury Hair',
      subtitle: 'Discover the finest human hair, wigs, and extensions.',
      image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=1200&h=800&fit=crop',
      link: '/shop',
    }
  ],
  aboutSettings: {
    ceoName: 'Adeyemi Ayomide Grace',
    ceoTitle: 'Founder & CEO',
    biography: `Welcome to **Mide's Affairs**. Founded by Adeyemi Ayomide Grace, our brand was built on the fundamental belief that every woman deserves access to premium quality hair that empowers her confidence and elevates her style.\n\nUnder Ayomide's leadership, Mide's Affairs has grown from a boutique vision into a trusted source for exquisite, long-lasting luxury hair and flawless wigs. Her dedication to sourcing authentic, high-quality bundles ensures that our clients receive nothing but the best.\n\n"My mission has always been to provide women with hair collections that not only look naturally beautiful but stand the test of time. Hair is a crown, and we ensure yours shines."`,
    profileImage: 'https://images.unsplash.com/photo-1531123414708-f47ecfd2f04e?w=800&h=1000&fit=crop',
  }
};

export const useSettingsStore = create<SettingsState>((set) => ({
  settings: defaultSettings,
  loading: true,
  fetchSettings: () => {
    const unsub = onSnapshot(doc(db, 'settings', 'global'), (docSnap) => {
      if (docSnap.exists()) {
        let data = docSnap.data() as Settings;
        
        // Force replace the clothes image with the hair image if it's saved in the database
        if (data.heroBanners && data.heroBanners[0] && data.heroBanners[0].image === 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&h=800&fit=crop') {
           data.heroBanners[0].image = 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=1200&h=800&fit=crop';
        }

        // Enforce fallback image if image is empty or missing
        if (!data.heroBanners || data.heroBanners.length === 0 || !data.heroBanners[0].image) {
           data.heroBanners = [{
             id: '1',
             title: data.heroBanners?.[0]?.title || 'Premium Luxury Hair',
             subtitle: data.heroBanners?.[0]?.subtitle || 'Discover the finest human hair, wigs, and extensions.',
             image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=1200&h=800&fit=crop',
             link: data.heroBanners?.[0]?.link || '/shop',
           }];
        }

        set({ settings: { ...defaultSettings, ...data }, loading: false });
      } else {
        set({ settings: defaultSettings, loading: false });
      }
    });
    return unsub;
  },
}));
