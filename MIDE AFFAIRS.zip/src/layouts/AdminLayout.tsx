import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, ShoppingBag, List, Users, ShoppingCart, Settings as SettingsIcon, LogOut, Layers } from 'lucide-react';
import { useEffect, useState } from 'react';
import { auth } from '../firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';

const NAV_ITEMS = [
  { name: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
  { name: 'Products', icon: ShoppingBag, path: '/admin/products' },
  { name: 'Categories', icon: List, path: '/admin/categories' },
  { name: 'Textures', icon: Layers, path: '/admin/textures' },
  { name: 'Orders', icon: ShoppingCart, path: '/admin/orders' },
  { name: 'Customers', icon: Users, path: '/admin/customers' },
  { name: 'Settings', icon: SettingsIcon, path: '/admin/settings' },
];

export default function AdminLayout() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (!u) {
        navigate('/admin/login');
      } else {
        setUser(u);
      }
      setLoading(false);
    });
    return () => unsub();
  }, [navigate]);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/admin/login');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-50">Loading...</div>;

  return (
    <div className="flex min-h-screen bg-gray-50 font-sans">
      <aside className="w-64 bg-white border-r border-gray-200 hidden md:flex flex-col">
        <div className="h-20 flex items-center px-6 border-b border-gray-100 justify-between">
          <span className="text-xl font-bold">Admin Panel</span>
        </div>
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-3">
            {NAV_ITEMS.map((item) => {
              const active = location.pathname === item.path || (item.path !== '/admin' && location.pathname.startsWith(item.path));
              return (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={`flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                      active ? 'bg-black text-white' : 'text-gray-600 hover:bg-gray-100 hover:text-black'
                    }`}
                  >
                    <item.icon className="h-4 w-4 mr-3" />
                    {item.name}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        <div className="p-4 border-t border-gray-200">
          <Link to="/" className="w-full bg-black text-white rounded-md py-2 flex items-center justify-center text-sm font-medium mb-4 hover:bg-gray-900 transition-colors">
            View Live Site
          </Link>
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500 truncate pr-2">{user?.email}</span>
            <button onClick={handleLogout} className="text-gray-500 hover:text-black" title="Log out">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
      
      <main className="flex-1 max-w-full overflow-hidden flex flex-col">
        <div className="md:hidden h-16 bg-white border-b border-gray-200 flex items-center px-4">
           <span className="font-bold">Admin Panel</span>
        </div>
        <div className="flex-1 overflow-y-auto p-6 lg:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
