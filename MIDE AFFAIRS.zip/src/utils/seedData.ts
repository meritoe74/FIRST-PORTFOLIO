import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

export const MOCK_HAIRS = [
  { id: 'm-new-1', name: 'SDD Vietnam Bone Straight', description: 'Super Double drawn Vietnam Bone straight \n5by5 Closure \n10” \n200grams', categoryId: '', price: 180000, images: ['https://i.ibb.co/fYmHFB3z/IMG-20260618-WA0004.jpg'], sizes: ['10"'], colors: ['Natural'], stock: 5, createdAt: 0, updatedAt: 0, isFeatured: true },
  { id: 'm-new-2', name: '5x5 Sassy Curls', description: '5by5 Sassy Curls\nWine color\nAvailable in 12” - 110k, 14” - 120k', categoryId: '', price: 110000, images: ['https://i.ibb.co/ym1nXwch/IMG-20260618-WA0001.jpg'], sizes: ['12"', '14"'], colors: ['Wine'], stock: 8, createdAt: 0, updatedAt: 0, isFeatured: true },
  { id: 'm-new-3', name: 'Premium Elegant Wave', description: 'Experience the finest texture with our Elegant Wave collection. Perfectly crafted for a flawless modern look.', categoryId: '', price: 145000, images: ['https://i.ibb.co/p6TqL1XL/IMG-20260618-WA0002.jpg'], sizes: ['16"', '18"'], colors: ['Natural'], stock: 12, createdAt: 0, updatedAt: 0, isFeatured: true },
  { id: 'm1', name: 'Luxury Bone Straight 24"', description: 'Premium 24 inch bone straight hair, double drawn, silky and smooth texture.', categoryId: '', price: 125000, images: ['https://images.unsplash.com/photo-1595475207225-428b62bda831?w=400&h=500&fit=crop'], sizes: ['24"', '26"', '28"'], colors: ['Natural', '1B'], stock: 10, createdAt: 0, updatedAt: 0, isFeatured: true },
  { id: 'm2', name: 'Bouncy Body Wave Wig', description: 'Voluminous body wave wig, ready to wear.', categoryId: '', price: 98000, images: ['https://images.unsplash.com/photo-1563260840-058b73a5a40b?w=400&h=500&fit=crop'], sizes: ['18"', '20"'], colors: ['Natural'], stock: 10, createdAt: 0, updatedAt: 0, isFeatured: false },
  { id: 'm3', name: 'HD Lace Frontal 13x4', description: 'Ultra-thin HD lace frontal for a seamless melt.', categoryId: '', price: 65000, images: ['https://images.unsplash.com/photo-1522337660859-02fbefca4702?w=400&h=500&fit=crop'], sizes: ['14"', '16"'], colors: ['Natural'], stock: 10, createdAt: 0, updatedAt: 0, isFeatured: true },
  { id: 'm4', name: 'Burgundy Highlight Bob', description: 'Flawless highlight bob, precut and styled.', categoryId: '', price: 85000, images: ['https://images.unsplash.com/photo-1580924408719-79ad2ae02061?w=400&h=500&fit=crop'], sizes: ['10"', '12"'], colors: ['Burgundy'], stock: 10, createdAt: 0, updatedAt: 0, isFeatured: false },
  { id: 'm5', name: 'Raw Donor Hair Bundles 28"', description: 'Authentic raw donor hair bundles.', categoryId: '', price: 185000, images: ['https://images.unsplash.com/photo-1580924408719-79ad2ae02061?w=400&h=500&fit=crop'], sizes: ['28"', '30"'], colors: ['Natural'], stock: 5, createdAt: 0, updatedAt: 0, isFeatured: false },
  { id: 'm6', name: 'Water Wave Curly Wig', description: 'Deep water wave curls, full density.', categoryId: '', price: 110000, images: ['https://images.unsplash.com/photo-1633511082697-7e61e6acfd00?w=400&h=500&fit=crop'], sizes: ['22"', '24"'], colors: ['Natural'], stock: 8, createdAt: 0, updatedAt: 0, isFeatured: false },
];

export const MOCK_CATEGORIES = [
  { name: 'Bone Straight', image: 'https://i.ibb.co/fYmHFB3z/IMG-20260618-WA0004.jpg' },
  { name: 'Sassy Curls', image: 'https://i.ibb.co/ym1nXwch/IMG-20260618-WA0001.jpg' },
  { name: 'Elegant Wave', image: 'https://i.ibb.co/p6TqL1XL/IMG-20260618-WA0002.jpg' }
];

export const MOCK_TEXTURES = [
  { name: "Bone Straight", image: "https://images.unsplash.com/photo-1595475207225-428b62bda831?w=400&h=400&fit=crop" },
  { name: "Body Wave", image: "https://images.unsplash.com/photo-1563260840-058b73a5a40b?w=400&h=400&fit=crop" },
  { name: "Deep Curl", image: "https://images.unsplash.com/photo-1633511082697-7e61e6acfd00?w=400&h=400&fit=crop" },
  { name: "Frontals & Closures", image: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?w=400&h=400&fit=crop" },
  { name: "Blonde Blends", image: "https://images.unsplash.com/photo-1600124803920-5626cc984f85?w=400&h=400&fit=crop" },
  { name: "Bob Wigs", image: "https://images.unsplash.com/photo-1580924408719-79ad2ae02061?w=400&h=400&fit=crop" }
];

export const autoSeedProducts = async () => {
  try {
    for (const prod of MOCK_HAIRS) {
      const { id, ...data } = prod;
      await addDoc(collection(db, 'products'), {
        ...data,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
  } catch (err) {
    console.error("Error auto-seeding products", err);
  }
};

export const autoSeedCategories = async () => {
    try {
      for (const cat of MOCK_CATEGORIES) {
        await addDoc(collection(db, 'categories'), {
          ...cat,
          createdAt: serverTimestamp(),
        });
      }
    } catch (err) {
      console.error("Error auto-seeding categories", err);
    }
  };

export const autoSeedTextures = async () => {
    try {
      for (const tex of MOCK_TEXTURES) {
        await addDoc(collection(db, 'textures'), {
          ...tex,
          createdAt: serverTimestamp(),
        });
      }
    } catch (err) {
      console.error("Error auto-seeding textures", err);
    }
  };
