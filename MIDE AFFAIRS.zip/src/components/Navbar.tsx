import { Link } from 'react-router-dom';
import { ShoppingCart, Menu, X, User } from 'lucide-react';
import { useState } from 'react';
import { useCartStore } from '../stores/useCartStore';
import { useSettingsStore } from '../stores/useSettingsStore';
import SearchBar from './SearchBar';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const cartItems = useCartStore((state) => state.items);
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const settings = useSettingsStore((state) => state.settings);

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold tracking-tight text-gray-900">
              {settings?.businessName || "Mide's Affairs"}
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-600 hover:text-black transition-colors text-sm font-medium">Home</Link>
            <Link to="/shop" className="text-gray-600 hover:text-black transition-colors text-sm font-medium">Shop</Link>
            <Link to="/about" className="text-gray-600 hover:text-black transition-colors text-sm font-medium">About</Link>
            <Link to="/contact" className="text-gray-600 hover:text-black transition-colors text-sm font-medium">Contact</Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <SearchBar />
            <div className="w-px h-6 bg-gray-200 mx-1"></div>
            <Link to="/admin" className="text-gray-600 hover:text-black p-2 rounded-full hover:bg-gray-100 transition-colors">
              <User className="h-5 w-5" />
            </Link>
            <Link to="/cart" className="relative text-gray-600 hover:text-black p-2 rounded-full hover:bg-gray-100 transition-colors">
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 bg-black text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
          
          <div className="md:hidden flex items-center space-x-2 w-full justify-end">
            <SearchBar />
            <Link to="/cart" className="relative text-gray-600 p-2">
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 bg-black text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600 p-2">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white border-b border-gray-100 px-4 pt-2 pb-6 space-y-4">
          <Link to="/" onClick={() => setIsOpen(false)} className="block text-gray-600 font-medium">Home</Link>
          <Link to="/shop" onClick={() => setIsOpen(false)} className="block text-gray-600 font-medium">Shop</Link>
          <Link to="/about" onClick={() => setIsOpen(false)} className="block text-gray-600 font-medium">About</Link>
          <Link to="/contact" onClick={() => setIsOpen(false)} className="block text-gray-600 font-medium">Contact</Link>
          <Link to="/admin" onClick={() => setIsOpen(false)} className="block text-gray-600 font-medium">Admin</Link>
        </div>
      )}
    </nav>
  );
}
