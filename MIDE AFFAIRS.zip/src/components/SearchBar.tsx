import { useState, useEffect, useRef } from 'react';
import { Search } from 'lucide-react';
import { collection, getDocs, query, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { Product } from '../types';
import { Link, useNavigate } from 'react-router-dom';

export default function SearchBar() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const [topProducts, setTopProducts] = useState<Product[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Load some featured/bestselling stuff on load to show initially
  useEffect(() => {
    async function loadTop() {
      try {
         const q = query(collection(db, 'products'), limit(5));
         const snap = await getDocs(q);
         setTopProducts(snap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
      } catch (e) {
         console.error(e);
      }
    }
    loadTop();
  }, []);

  // Filter local for fast suggestion (could ideally be debounced backend search)
  useEffect(() => {
    if (searchTerm.trim() === '') {
       setSuggestions(topProducts);
    } else {
       const lower = searchTerm.toLowerCase();
       setSuggestions(topProducts.filter(p => p.name.toLowerCase().includes(lower) || p.description.toLowerCase().includes(lower)));
    }
  }, [searchTerm, topProducts]);

  // Handle clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsExpanded(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
     e.preventDefault();
     if (searchTerm.trim()) {
        setIsExpanded(false);
        // We can just redirect to shop and let shop handle text filtering or simply go to shop
        // Since shop doesn't have text filter currently, we can just go to shop
        navigate('/shop');
        setSearchTerm('');
     }
  };

  return (
    <div ref={searchRef} className="relative z-50">
      <form onSubmit={handleSubmit} className={`flex items-center transition-all bg-gray-50 rounded-full border border-gray-200 focus-within:border-gray-800 ${isExpanded ? 'w-full md:w-64 px-4 py-2' : 'w-10 h-10 justify-center cursor-pointer hover:bg-gray-100'} overflow-visible`}>
         {!isExpanded ? (
            <button type="button" onClick={() => setIsExpanded(true)} className="flex items-center justify-center w-full h-full">
               <Search className="h-5 w-5 text-gray-600" />
            </button>
         ) : (
            <>
               <Search className="h-4 w-4 text-gray-400 mr-2 shrink-0" />
               <input 
                  autoFocus
                  type="text"
                  placeholder="Search products..."
                  className="bg-transparent border-none outline-none w-full text-sm font-medium focus:ring-0 text-gray-800"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
               />
            </>
         )}
      </form>

      {/* Dropdown Suggestions */}
      {isExpanded && (
        <div className="absolute top-full lg:right-0 left-0 lg:left-auto mt-2 w-full md:w-80 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden text-left origin-top">
           <div className="p-3 bg-gray-50 border-b border-gray-100">
              <span className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                 {searchTerm.trim() ? 'Top Results' : 'Suggested for you'}
              </span>
           </div>
           {suggestions.length > 0 ? (
              <div className="max-h-64 overflow-y-auto">
                 {suggestions.map(p => (
                    <Link key={p.id} to={`/product/${p.id}`} onClick={() => { setIsExpanded(false); setSearchTerm(''); }} className="flex items-center gap-3 p-3 hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0 group">
                       <img src={p.images[0]} alt="" className="w-10 h-10 rounded-md object-cover border border-gray-100 group-hover:border-gray-300" />
                       <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate font-serif">{p.name}</p>
                          <p className="text-xs text-gray-500 truncate">₦{p.price.toLocaleString()}</p>
                       </div>
                    </Link>
                 ))}
              </div>
           ) : (
              <div className="p-6 text-center text-gray-500 text-sm">
                 We couldn't find anything matching "{searchTerm}".
              </div>
           )}
           <div className="p-2 border-t border-gray-100 bg-gray-50 text-center">
              <Link to="/shop" onClick={() => setIsExpanded(false)} className="text-xs font-medium text-indigo-600 hover:text-indigo-800">
                 View all products &rarr;
              </Link>
           </div>
        </div>
      )}
    </div>
  )
}
