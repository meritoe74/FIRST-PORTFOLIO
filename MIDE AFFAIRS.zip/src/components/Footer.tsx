import { Link } from 'react-router-dom';
import { useSettingsStore } from '../stores/useSettingsStore';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import { SiTiktok } from '@icons-pack/react-simple-icons'; // We might need to add simple-icons, or just use a custom SVG for Tiktok

export default function Footer() {
  const settings = useSettingsStore((state) => state.settings);

  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          <div className="col-span-1 md:col-span-2 lg:col-span-2">
            <Link to="/" className="text-2xl font-bold tracking-tight text-gray-900 mb-6 block font-serif">
              {settings?.businessName || "Mide's Affairs"}
            </Link>
            <p className="text-gray-500 text-base max-w-md mb-8 leading-relaxed">
              Discover luxurious hair collections and flawless wigs curated for modern style.
            </p>
            <div className="flex flex-col space-y-4">
              {settings?.instagram && (
                <a href={`https://instagram.com/${settings.instagram.replace('@', '')}`} target="_blank" rel="noreferrer" className="flex items-center text-gray-500 hover:text-black transition-colors group">
                  <span className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-gray-100 group-hover:border-gray-300 mr-3">
                    <Instagram className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-medium">@{settings.instagram}</span>
                </a>
              )}
              {settings?.tiktok && (
                <a href={`https://tiktok.com/@${settings.tiktok.replace('@', '')}`} target="_blank" rel="noreferrer" className="flex items-center text-gray-500 hover:text-black transition-colors group">
                  <span className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-gray-100 group-hover:border-gray-300 mr-3">
                    {/* Tiktok Icon SVG */}
                    <svg viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5">
                      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 15.68 6.34 6.34 0 0011.33 22 6.34 6.34 0 0017.67 15.68V8.16A8.4 8.4 0 0022 9.38V5.88a4.84 4.84 0 01-2.41-1.19z" />
                    </svg>
                  </span>
                  <span className="text-sm font-medium">@{settings.tiktok}</span>
                </a>
              )}
              {settings?.facebook && (
                <a href={settings.facebook} target="_blank" rel="noreferrer" className="flex items-center text-gray-500 hover:text-black transition-colors group">
                  <span className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-gray-100 group-hover:border-gray-300 mr-3">
                    <Facebook className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-medium">Facebook</span>
                </a>
              )}
            </div>
          </div>
          <div>
            <h3 className="font-bold text-gray-900 mb-6 text-sm uppercase tracking-wider">Quick Links</h3>
            <ul className="space-y-4 flex flex-col text-base text-gray-500">
              <Link to="/shop" className="hover:text-black transition-colors">Shop All</Link>
              <Link to="/about" className="hover:text-black transition-colors">About Us</Link>
              <Link to="/contact" className="hover:text-black transition-colors">Contact</Link>
              <Link to="/faq" className="hover:text-black transition-colors">FAQs</Link>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-gray-900 mb-6 text-sm uppercase tracking-wider">Contact</h3>
            <ul className="space-y-4 text-base text-gray-500">
              {settings?.email && (
                <li>
                  <a href={`mailto:${settings.email}`} className="flex items-start hover:text-black transition-colors">
                    <Mail className="h-5 w-5 mr-3 shrink-0 mt-0.5" />
                    <span>{settings.email}</span>
                  </a>
                </li>
              )}
              {settings?.phone && (
                <li>
                  <a href={`tel:${settings.phone.replace(/[^0-9+]/g, '')}`} className="flex items-start hover:text-black transition-colors">
                    <Phone className="h-5 w-5 mr-3 shrink-0 mt-0.5" />
                    <span>{settings.phone}</span>
                  </a>
                </li>
              )}
              {settings?.storeAddress && (
                <li className="flex items-start">
                  <MapPin className="h-5 w-5 mr-3 shrink-0 mt-0.5" />
                  <span>{settings.storeAddress}</span>
                </li>
              )}
            </ul>
          </div>
        </div>
        <div className="mt-16 pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
          <p className="mb-4 md:mb-0">&copy; {new Date().getFullYear()} {settings?.businessName}. All rights reserved.</p>
          <div className="flex space-x-6">
             <Link to="#" className="hover:text-gray-600">Privacy Policy</Link>
             <Link to="#" className="hover:text-gray-600">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
