import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { collection, getDocs, query } from 'firebase/firestore';
import { db } from '../firebase';
import { Texture } from '../types';

import { Link } from 'react-router-dom';

export const MOCK_TEXTURES = [
  { name: "Bodywave", image: "https://images.unsplash.com/photo-1563260840-058b73a5a40b?w=400&h=400&fit=crop" },
  { name: "Bone straight", image: "https://images.unsplash.com/photo-1595475207225-428b62bda831?w=400&h=400&fit=crop" },
  { name: "Silky straight unit", image: "https://images.unsplash.com/photo-1600124803920-5626cc984f85?w=400&h=400&fit=crop" },
  { name: "Deepwave", image: "https://images.unsplash.com/photo-1633511082697-7e61e6acfd00?w=400&h=400&fit=crop" },
  { name: "Vietnamese bounce", image: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?w=400&h=400&fit=crop" },
  { name: "Chinese bounce", image: "https://images.unsplash.com/photo-1580924408719-79ad2ae02061?w=400&h=400&fit=crop" },
  { name: "Hairblends", image: "https://images.unsplash.com/photo-1595475207225-428b62bda831?w=400&h=400&fit=crop" },
  { name: "Jerry curls / Water curls", image: "https://images.unsplash.com/photo-1633511082697-7e61e6acfd00?w=400&h=400&fit=crop" },
  { name: "Bob wigs", image: "https://images.unsplash.com/photo-1580924408719-79ad2ae02061?w=400&h=400&fit=crop" },
  { name: "Pixie curls", image: "https://images.unsplash.com/photo-1563260840-058b73a5a40b?w=400&h=400&fit=crop" },
  { name: "Yaki straight", image: "https://images.unsplash.com/photo-1600124803920-5626cc984f85?w=400&h=400&fit=crop" },
  { name: "Burmese curls", image: "https://images.unsplash.com/photo-1633511082697-7e61e6acfd00?w=400&h=400&fit=crop" },
  { name: "Skull caps", image: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?w=400&h=400&fit=crop" }
] as Texture[];

function MarqueeRow({ items, direction = 1 }: { items: Texture[], direction?: number }) {
  if (items.length === 0) return null;
  // We duplicate the items a few times to create a seamless loop
  const duplicatedItems = [...items, ...items, ...items, ...items];
  
  return (
    <div className="flex w-full overflow-hidden whitespace-nowrap py-2">
      <motion.div
        className="flex gap-4 sm:gap-6 min-w-max px-2 sm:px-3"
        animate={{ x: direction === 1 ? [0, -1000] : [-1000, 0] }}
        transition={{ repeat: Infinity, duration: 25, ease: "linear" }}
      >
        {duplicatedItems.map((hair, i) => (
          <Link key={i} to={`/texture/${encodeURIComponent(hair.name)}`} className="relative w-56 sm:w-64 h-72 sm:h-80 rounded-2xl overflow-hidden shadow-xl border border-white/20 group block">
            <img src={hair.image} alt={hair.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
            {/* Glassmorphism Morphism effect on the label */}
            <div className="absolute bottom-4 left-4 right-4 bg-white/20 backdrop-blur-md border border-white/30 rounded-xl p-3 text-center transition-all duration-300 group-hover:bg-white/30 group-hover:backdrop-blur-lg">
              <h3 className="text-white font-serif tracking-wide text-sm font-medium drop-shadow-sm">{hair.name}</h3>
            </div>
          </Link>
        ))}
      </motion.div>
    </div>
  );
}

export default function HairMarquee() {
  const [textures, setTextures] = useState<Texture[]>(MOCK_TEXTURES);

  useEffect(() => {
    async function fetchTextures() {
      try {
        const snap = await getDocs(query(collection(db, 'textures')));
        if (!snap.empty) {
          setTextures(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Texture)));
        }
      } catch (err) {
        console.error("Error fetching textures:", err);
      }
    }
    fetchTextures();
  }, []);

  if (!textures || textures.length === 0) return null;

  const half = Math.ceil(textures.length / 2);
  const topRow = textures.slice(0, half);
  const bottomRow = textures.slice(half);

  return (
    <section className="py-16 bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      <div className="text-center mb-10 px-4">
        <h2 className="text-3xl font-bold text-gray-900 mb-4 font-serif">Our Signature Textures</h2>
        <p className="text-gray-500 max-w-xl mx-auto">
          Explore a variety of premium textures, perfectly matched for every style and occasion.
        </p>
      </div>
      <div className="flex flex-col gap-2 sm:gap-4 rotate-[-2deg] scale-[1.05]">
        <MarqueeRow items={topRow} direction={1} />
        {bottomRow.length > 0 && <MarqueeRow items={bottomRow} direction={-1} />}
      </div>
    </section>
  );
}
