import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { Star, Quote } from 'lucide-react';
import { useAutoScroll } from '../hooks/useAutoScroll';

const testimonialsRow1 = [
  {
    id: 1,
    name: "Director / CEO",
    role: "Merit Wedding and Events LTD",
    content: "Partnering with Peculiar Lifestyle Limited for our event cleanups has been a game-changer. They handle the post-event chaos with incredible efficiency and professionalism, ensuring venues are always impeccable. True partners in excellence.",
    rating: 5,
    avatar: "https://i.ibb.co/1YwyF9CS/IMG-3142.jpg"
  },
  {
    id: 2,
    name: "Church Administration",
    role: "The Apostolic Church Nigeria, Akoka District",
    content: "Peculiar Lifestyle Limited has consistently maintained a pristine and welcoming environment for our congregation. Their dedication, attention to detail, and highly respectful service are deeply appreciated by our entire community.",
    rating: 5,
    avatar: ""
  },
  {
    id: 3,
    name: "Oluwaseun A.",
    role: "Corporate Executive",
    content: "Peculiar Lifestyle Limited completely transformed the way I manage my time. Returning to a spotless home after a long business trip without worrying about groceries is truly a luxury.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1bf98a?q=80&w=2670&auto=format&fit=crop"
  },
  {
    id: 4,
    name: "Ngozi E.",
    role: "Entrepreneur & Mother",
    content: "Balancing my growing business and family life left me exhausted. Their scheduled cleaning and focused market runs have given me my weekends back. Highly professional.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?q=80&w=2787&auto=format&fit=crop"
  }
];

const testimonialsRow2 = [
  {
    id: 5,
    name: "Abel Braimoh.",
    role: "Ketu",
    content: "With my crazy work schedule, keeping my apartment pristine felt impossible. Peculiar Lifestyle came in and completely transformed my space. They are thorough, professional, and trustworthy. Coming home to a spotless, fresh-smelling house is the best feeling ever.",
    rating: 5,
    avatar: "https://i.ibb.co/SDSGsY8M/IMG-20260623-WA0010.jpg"
  },
  {
    id: 6,
    name: "Josh",
    role: "Ikotun",
    content: "I am incredibly particular about cleanliness, and they exceeded my expectations. They didn't just clean; they paid attention to the corners, the dusting, and the details most people skip. Exceptional service!",
    rating: 5,
    avatar: "https://i.ibb.co/5h6cs5Q8/IMG-20260623-WA0017.jpg"
  },
  {
    id: 7,
    name: "Debby Gbade",
    role: "Ketu",
    content: "I used to dread the weekend market rush, but Peculiar Lifestyle has changed the game for me. I sent over my shopping list, and they sourced everything perfectly fresh, clean, and well-packaged. It saved me hours of stress!",
    rating: 5,
    avatar: "https://i.ibb.co/yFCB2RdK/IMG-20260623-WA0006.jpg"
  }
];

const testimonialsRow3 = [
  {
    id: 8,
    name: "Joy",
    role: "F. Yaba",
    content: "Peculiar Lifestyle handles both my home cleaning and my weekly market runs, and it has completely freed up my weekends. The peace of mind knowing my chores are in professional hands is worth every single Kobo.",
    rating: 5,
    avatar: ""
  },
  {
    id: 9,
    name: "Abidemi. O",
    role: "Lekki",
    content: "Between work and life, I barely have time for the market, let alone deep cleaning. Having one trusted service handle both my market runs and home cleaning has been a total game-changer. Everything came back fresh, organized, and exactly as requested!",
    rating: 5,
    avatar: "https://i.ibb.co/rGTG7V3H/IMG-20260623-WA0016.jpg"
  },
  {
    id: 10,
    name: "Israel",
    role: "Onipanu",
    content: "I’m always picky about my foodstuff, but the personal shopping service exceeded my expectations. Every item was fresh, carefully selected, and perfectly packaged. It saved me hours of stress in the market!",
    rating: 5,
    avatar: "https://i.ibb.co/PnsrQwb/IMG-20260623-WA0018.jpg"
  }
];

function AutoScrollRow({ children, className }: { children: React.ReactNode, className: string }) {
  const scrollRef = useAutoScroll();
  return <div ref={scrollRef} className={className}>{children}</div>;
}

export default function Testimonials() {
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Testimonials" 
        description="Read what our clients have to say about Peculiar Lifestyle Limited." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Client Experiences
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            Do not just take our word for it. Hear from those whose time we have restored.
          </motion.p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Row 1 */}
          <AutoScrollRow className="flex flex-nowrap overflow-x-auto md:grid md:grid-cols-2 gap-4 md:gap-8 pb-4 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 hide-scrollbar scroll-smooth">
            {testimonialsRow1.map((testimonial, idx) => (
              <motion.div 
                key={testimonial.id}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: idx * 0.1, ease: "easeOut" }}
                className="w-[85vw] sm:w-[320px] shrink-0 md:w-auto bg-white rounded-2xl p-6 md:p-10 shadow-sm border border-gray-100 relative whitespace-normal flex flex-col"
              >
                <div className="absolute top-6 right-6 md:top-8 md:right-8 text-emerald/10">
                  <Quote size={48} className="md:w-16 md:h-16" />
                </div>
                
                <div className="flex text-gold mb-4 md:mb-6 relative z-10">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill={i < testimonial.rating ? "currentColor" : "none"} className={`md:w-4 md:h-4 ${i >= testimonial.rating ? "text-gray-300" : ""}`} />
                  ))}
                </div>
                
                <p className="text-gray-700 text-base md:text-xl leading-relaxed mb-6 md:mb-8 relative z-10 font-medium flex-grow">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center relative z-10 mt-auto">
                  {testimonial.avatar ? (
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name} 
                      className="w-12 h-12 md:w-14 md:h-14 rounded-full object-cover border-2 border-cream mr-3 md:mr-4 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-emerald/10 text-emerald flex items-center justify-center font-bold text-lg md:text-xl mr-3 md:mr-4 border-2 border-cream flex-shrink-0">
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="font-bold text-gray-900 text-sm md:text-base">{testimonial.name}</h4>
                    <p className="text-emerald text-xs md:text-sm uppercase tracking-wider font-semibold line-clamp-1 text-ellipsis overflow-hidden break-all">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AutoScrollRow>

          {/* Row 2 */}
          <AutoScrollRow className="flex flex-nowrap overflow-x-auto md:grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8 pb-4 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 hide-scrollbar scroll-smooth">
            {testimonialsRow2.map((testimonial, idx) => (
              <motion.div 
                key={testimonial.id}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: idx * 0.1, ease: "easeOut" }}
                className="w-[85vw] sm:w-[320px] shrink-0 md:w-auto bg-white rounded-2xl p-6 md:p-10 shadow-sm border border-gray-100 relative whitespace-normal flex flex-col"
              >
                <div className="absolute top-6 right-6 md:top-8 md:right-8 text-emerald/10">
                  <Quote size={48} className="md:w-16 md:h-16" />
                </div>
                
                <div className="flex text-gold mb-4 md:mb-6 relative z-10">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill={i < testimonial.rating ? "currentColor" : "none"} className={`md:w-4 md:h-4 ${i >= testimonial.rating ? "text-gray-300" : ""}`} />
                  ))}
                </div>
                
                <p className="text-gray-700 text-base md:text-xl leading-relaxed mb-6 md:mb-8 relative z-10 font-medium flex-grow">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center relative z-10 mt-auto">
                  {testimonial.avatar ? (
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name} 
                      className="w-12 h-12 md:w-14 md:h-14 rounded-full object-cover border-2 border-cream mr-3 md:mr-4 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-emerald/10 text-emerald flex items-center justify-center font-bold text-lg md:text-xl mr-3 md:mr-4 border-2 border-cream flex-shrink-0">
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="font-bold text-gray-900 text-sm md:text-base">{testimonial.name}</h4>
                    <p className="text-emerald text-xs md:text-sm uppercase tracking-wider font-semibold line-clamp-1 text-ellipsis overflow-hidden break-all">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AutoScrollRow>

          {/* Row 3 */}
          <AutoScrollRow className="flex flex-nowrap overflow-x-auto md:grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8 pb-4 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 hide-scrollbar scroll-smooth">
            {testimonialsRow3.map((testimonial, idx) => (
              <motion.div 
                key={testimonial.id}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: idx * 0.1, ease: "easeOut" }}
                className="w-[85vw] sm:w-[320px] shrink-0 md:w-auto bg-white rounded-2xl p-6 md:p-10 shadow-sm border border-gray-100 relative whitespace-normal flex flex-col"
              >
                <div className="absolute top-6 right-6 md:top-8 md:right-8 text-emerald/10">
                  <Quote size={48} className="md:w-16 md:h-16" />
                </div>
                
                <div className="flex text-gold mb-4 md:mb-6 relative z-10">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill={i < testimonial.rating ? "currentColor" : "none"} className={`md:w-4 md:h-4 ${i >= testimonial.rating ? "text-gray-300" : ""}`} />
                  ))}
                </div>
                
                <p className="text-gray-700 text-base md:text-xl leading-relaxed mb-6 md:mb-8 relative z-10 font-medium flex-grow">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center relative z-10 mt-auto">
                  {testimonial.avatar ? (
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name} 
                      className="w-12 h-12 md:w-14 md:h-14 rounded-full object-cover border-2 border-cream mr-3 md:mr-4 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-emerald/10 text-emerald flex items-center justify-center font-bold text-lg md:text-xl mr-3 md:mr-4 border-2 border-cream flex-shrink-0">
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="font-bold text-gray-900 text-sm md:text-base">{testimonial.name}</h4>
                    <p className="text-emerald text-xs md:text-sm uppercase tracking-wider font-semibold line-clamp-1 text-ellipsis overflow-hidden break-all">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AutoScrollRow>
        </div>
      </section>
    </div>
  );
}
