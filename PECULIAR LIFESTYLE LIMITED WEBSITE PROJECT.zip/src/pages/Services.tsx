import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAutoScroll } from '../hooks/useAutoScroll';

function AutoScrollRow({ children, className }: { children: React.ReactNode, className: string }) {
  const scrollRef = useAutoScroll();
  return <div ref={scrollRef} className={className}>{children}</div>;
}

const services = [
  {
    category: "Premium Cleaning Services",
    items: [
      {
        title: "Residential Deep Cleaning",
        desc: "A meticulous, top-to-bottom clean focusing on areas outside of a regular cleaning schedule. Ideal for spring cleaning or post-illness.",
      },
      {
        title: "Recurring Home Upkeep",
        desc: "Set a regular schedule to ensure your sanctuary remains pristine without you ever having to lift a finger.",
      },
      {
        title: "Move-In/Move-Out Cleaning",
        desc: "Ensure a flawless transition. We prepare your new home for a fresh start or leave your old space immaculate.",
      },
      {
        title: "Specialized Floor Care",
        desc: "Expert treatment for marble, hardwood, and premium carpet materials to maintain their luxury finish.",
      },
      {
        title: "Post-Construction Cleanup",
        desc: "We clear the dust and debris following renovations, revealing the true beauty of your new space.",
      },
      {
        title: "Special Event Cleaning",
        desc: "Pre-event preparation and post-event restoration, so you can focus entirely on hosting your guests.",
      }
    ]
  },
  {
    category: "Efficient Market Runs",
    items: [
      {
        title: "Custom Grocery Sourcing",
        desc: "We handpick fresh, premium produce and staples according to your exact dietary needs and preferences.",
      },
      {
        title: "Specialist Food Items",
        desc: "Sourcing hard-to-find ingredients, organic specialties, and luxury brands for your culinary requirements.",
      },
      {
        title: "Bulk Purchase Handling",
        desc: "Efficient management of household stock, ensuring you never run out of the essentials.",
      },
      {
        title: "Precise Delivery Scheduling",
        desc: "Direct-to-pantry delivery organized around your schedule for maximum convenience.",
      }
    ]
  }
];

export default function Services() {
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Our Services" 
        description="Premium home management services including deep cleaning and efficient market runs." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Our Services
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            We curate an environment of peace, order, and excellence.
          </motion.p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {services.map((category, idx) => (
            <div key={idx} className="mb-16 md:mb-24 last:mb-0">
              <div className="flex items-center mb-8 md:mb-12">
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif font-bold text-gray-900">{category.category}</h2>
                <div className="ml-4 md:ml-6 flex-grow h-px bg-gold/30 hidden sm:block"></div>
              </div>
              
              <AutoScrollRow className="flex flex-nowrap overflow-x-auto md:grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8 pb-8 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 hide-scrollbar scroll-smooth">
                {category.items.map((service, sIdx) => (
                  <motion.div
                    key={sIdx}
                    initial={{ opacity: 0, x: 50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: sIdx * 0.1, ease: "easeOut" }}
                    className="w-[85vw] sm:w-[320px] shrink-0 md:w-auto bg-white rounded-2xl p-6 md:p-8 border border-gray-100 shadow-sm hover:shadow-xl transition-all group flex flex-col h-full whitespace-normal"
                  >
                    <div className="w-10 h-10 md:w-12 md:h-12 bg-emerald/5 rounded-full flex items-center justify-center text-emerald mb-4 md:mb-6 group-hover:bg-gold group-hover:text-white transition-colors">
                      <Check className="w-5 h-5 md:w-6 md:h-6" />
                    </div>
                    <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-3 md:mb-4">{service.title}</h3>
                    <p className="text-sm md:text-base text-gray-600 mb-6 md:mb-8 flex-grow">{service.desc}</p>
                    <Link to={`/book?service=${encodeURIComponent(service.title)}`} className="inline-flex items-center text-emerald font-semibold hover:text-gold transition-colors mt-auto group/link text-sm md:text-base">
                      Book this service
                      <ArrowRight className="ml-2 w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                    </Link>
                  </motion.div>
                ))}
              </AutoScrollRow>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
