import { useEffect, useRef } from 'react';

export function useAutoScroll() {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    let animationFrameId: number;
    let isUserInteracting = false;

    const handleTouchStart = () => { isUserInteracting = true; };
    const handleTouchEnd = () => { 
      setTimeout(() => { isUserInteracting = false; }, 2000); 
    };
    const handleMouseEnter = () => { isUserInteracting = true; };
    const handleMouseLeave = () => { 
      setTimeout(() => { isUserInteracting = false; }, 1000); 
    };

    el.addEventListener('touchstart', handleTouchStart, { passive: true });
    el.addEventListener('touchend', handleTouchEnd, { passive: true });
    el.addEventListener('mouseenter', handleMouseEnter);
    el.addEventListener('mouseleave', handleMouseLeave);

    const step = () => {
      // Only scroll if screen is smaller than Tailwind md breakpoint (768px)
      if (window.innerWidth < 768 && !isUserInteracting) {
        // If reached the end, reset to start smoothly or instantly
        if (el.scrollLeft >= el.scrollWidth - el.clientWidth - 1) {
          el.scrollLeft = 0;
        } else {
          el.scrollLeft += 0.5; // Adjust this value to change speed
        }
      }
      animationFrameId = requestAnimationFrame(step);
    };

    animationFrameId = requestAnimationFrame(step);

    return () => {
      el.removeEventListener('touchstart', handleTouchStart);
      el.removeEventListener('touchend', handleTouchEnd);
      el.removeEventListener('mouseenter', handleMouseEnter);
      el.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return scrollRef;
}
