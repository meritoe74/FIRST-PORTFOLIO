import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import * as LucideIcons from 'lucide-react';
import { ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

import { GalleryRenderer } from '../components/Galleries';

export default function ServiceDetail() {
  const { slug } = useParams();
  const [service, setService] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', email: '', projectType: '', message: '' });
  const [submitLoading, setSubmitLoading] = useState(false);

  useEffect(() => {
    fetch(`/api/services/${slug}`)
      .then(res => res.json())
      .then(data => {
        if (!data.error) {
          setService(data);
          setForm(f => ({ ...f, projectType: data.title }));
        }
        setLoading(false);
      })
      .catch(e => {
        console.error(e);
        setLoading(false);
      });
  }, [slug]);

  if (loading) return <div className="min-h-screen pt-32 px-6 text-center text-white">Loading service details...</div>;

  if (!service) {
    return <div className="min-h-screen pt-32 px-6 text-center text-white">Service not found</div>;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitLoading(true);
    
    // Add artificial delay for smoother UI feedback
    const toastId = toast.loading('Sending request...');
    
    try {
      const res = await fetch('/api/service_requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          projectType: form.projectType,
          message: form.message
        })
      });
      if (res.ok) {
        toast.success('Request sent successfully!', { id: toastId });
        setForm({ ...form, name: '', email: '', message: '' });
      } else {
        toast.error('Failed to send request. Please try again.', { id: toastId });
      }
    } catch (err) {
      toast.error('Network error. Failed to send.', { id: toastId });
    } finally {
      setSubmitLoading(false);
    }
  };

  const renderIcon = (iconName: string) => {
    // @ts-ignore
    const IconComponent = LucideIcons[iconName] || LucideIcons.HelpCircle;
    return <IconComponent size={32} />;
  };

  return (
    <div className="w-full min-h-screen pt-32 pb-32 px-6 md:px-24 relative overflow-hidden bg-[#020617]">
      <div className="absolute inset-0 z-0 pointer-events-none opacity-40">
        <div className="absolute top-0 left-0 w-[40vw] h-[40vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-20 animate-[pulse_10s_ease-in-out_infinite]" />
        <div className="absolute bottom-0 right-0 w-[40vw] h-[40vw] bg-accent rounded-full mix-blend-screen filter blur-[250px] opacity-20 animate-[pulse_12s_ease-in-out_infinite_reverse]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <Link to="/services" className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-12 uppercase tracking-[0.2em] text-xs font-medium">
          <ArrowLeft size={16} /> Back to Services
        </Link>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-accent mb-8 shadow-[0_0_30px_rgba(124,77,255,0.2)]">
            {renderIcon(service.icon)}
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-poppins font-bold tracking-tight mb-8 text-white">
            {service.title}
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light leading-relaxed max-w-4xl mb-16">
            {service.longDesc}
          </p>
        </motion.div>

        {/* Portfolio / Samples Section */}
        <div className="mb-24">
          <h2 className="text-2xl font-poppins font-semibold text-white mb-10">Showcase</h2>
          <GalleryRenderer slug={service.slug} images={service.images} folders={(service as any).folders} />
        </div>

        {/* Dedicated Request Form */}
        <motion.div
           initial={{ opacity: 0, y: 40 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           transition={{ duration: 0.8 }}
           className="bg-white/[0.02] border border-white/10 rounded-[2.5rem] p-10 backdrop-blur-2xl shadow-[0_16px_48px_rgba(0,0,0,0.2)] relative overflow-hidden max-w-4xl"
        >
          <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-accent/10 rounded-full blur-[100px] pointer-events-none" />
          
          <h2 className="text-3xl font-poppins font-semibold text-white mb-4 relative z-10">Request this Service</h2>
          <p className="text-gray-400 mb-10 relative z-10">Fill out the form below to inquire about our {service.title} services. We'll get back to you shortly.</p>
          
          <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Full Name</label>
                <input 
                  required
                  type="text" 
                  value={form.name}
                  onChange={e => setForm({...form, name: e.target.value})}
                  className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-3">
                <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Email Address</label>
                <input 
                  required
                  type="email" 
                  value={form.email}
                  onChange={e => setForm({...form, email: e.target.value})}
                  className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                  placeholder="hello@example.com"
                />
              </div>
            </div>
            
            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Project Type</label>
              <input 
                readOnly
                type="text" 
                value={form.projectType}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-gray-500 cursor-not-allowed"
              />
            </div>

            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Message / Brief Description</label>
              <textarea 
                required
                rows={4}
                value={form.message}
                onChange={e => setForm({...form, message: e.target.value})}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700 resize-none"
                placeholder="Tell us about your project goals..."
              />
            </div>

            <button 
              type="submit"
              disabled={submitLoading}
              className="group relative inline-flex items-center justify-center bg-white text-black px-10 py-5 rounded-full overflow-hidden w-full sm:w-auto disabled:opacity-50"
            >
              <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-[0.16,1,0.3,1]" />
              <span className="relative z-10 text-xs font-bold uppercase tracking-[0.2em] group-hover:text-white transition-colors duration-500 delay-100 flex items-center gap-3">
                {submitLoading ? 'Sending...' : 'Submit Request'} <span className="text-lg leading-none">&rarr;</span>
              </span>
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
