import React, { useState, useEffect, useRef } from 'react';
import { UploadCloud, File, Trash2, Image as ImageIcon, X, FileText, Film, HardDrive, Edit2, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

interface FileUpload {
  id: number;
  filename: string;
  originalName: string;
  url: string;
  size: number;
  section: string;
  createdAt: string;
}

const SECTIONS = ['General', 'Logo Design', 'Photography', 'Graphic Design', 'Hero', 'Featured Projects'];

export default function AdminUploads() {
  const [files, setFiles] = useState<FileUpload[]>([]);
  const [loading, setLoading] = useState(true);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [editingFile, setEditingFile] = useState<FileUpload | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = () => {
    setLoading(true);
    fetch('/api/uploads')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setFiles(data);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        toast.error('Failed to load uploads');
        setLoading(false);
      });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(Array.from(e.target.files));
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFiles = (newFiles: File[]) => {
    newFiles.forEach(file => {
      uploadFile(file);
    });
  };

  const uploadFile = (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('section', 'General');
    
    const fileId = file.name + '-' + Date.now();
    setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));
    
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload', true);
    
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const percentComplete = (e.loaded / e.total) * 100;
        setUploadProgress(prev => ({ ...prev, [fileId]: Math.round(percentComplete) }));
      }
    };

    xhr.onload = () => {
      if (xhr.status === 200) {
        toast.success(`Uploaded ${file.name}`);
        fetchFiles();
      } else {
        toast.error(`Failed to upload ${file.name}`);
      }
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[fileId];
        return newProgress;
      });
    };
    
    xhr.onerror = () => {
      toast.error(`Failed to upload ${file.name}`);
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[fileId];
        return newProgress;
      });
    };

    xhr.send(formData);
  };

  const deleteFile = async (id: number) => {
    if (!window.confirm('Delete this file permanently?')) return;
    try {
      const res = await fetch(`/api/uploads/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('File deleted');
        fetchFiles();
      } else {
        toast.error('Failed to delete file');
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to delete file');
    }
  };

  const updateSection = async (id: number, section: string) => {
    try {
      const res = await fetch(`/api/uploads/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section })
      });
      if (res.ok) {
        toast.success('Section updated');
        setEditingFile(null);
        fetchFiles();
      } else {
        toast.error('Failed to update section');
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to update section');
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '')) return <ImageIcon size={24} className="text-blue-400" />;
    if (['mp4', 'mov', 'avi', 'webm'].includes(ext || '')) return <Film size={24} className="text-purple-400" />;
    return <FileText size={24} className="text-green-400" />;
  };

  const isImage = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '');
  };

  const totalUsed = files.reduce((acc, file) => acc + (file.size || 0), 0);

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white drop-shadow-md">Media & Uploads</h1>
          <p className="text-gray-400 text-sm tracking-wide">Manage your images, videos, and assign them to frontend sections.</p>
        </div>
        <div className="flex items-center gap-4 bg-white/[0.02] border border-white/10 rounded-full px-5 py-2.5 shadow-inner backdrop-blur-md">
          <HardDrive size={18} className="text-accent" />
          <div className="text-sm font-medium">
            <span className="text-white">{formatSize(totalUsed)}</span> <span className="text-gray-500">used</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upload Zone */}
        <div className="lg:col-span-1 space-y-6">
          <div 
            className={`border-2 border-dashed rounded-3xl p-10 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 relative overflow-hidden backdrop-blur-md ${dragActive ? 'border-accent bg-accent/10 border-solid shadow-[0_0_30px_rgba(124,77,255,0.2)]' : 'border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.04]'}`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input 
              ref={fileInputRef}
              type="file" 
              multiple 
              className="hidden" 
              onChange={handleChange}
            />
            
            <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-transform duration-500 ${dragActive ? 'scale-110 bg-accent/20 text-accent' : 'bg-white/5 text-gray-400 group-hover:scale-110 group-hover:text-white group-hover:bg-white/10 shadow-inner'}`}>
              <UploadCloud size={32} />
            </div>
            <h3 className="text-xl font-medium mb-2 text-white">Drag & drop files here</h3>
            <p className="text-xs text-gray-400 max-w-[200px] leading-relaxed">Limit 50MB per file. Supported formats: JPG, PNG, WEBP, MP4.</p>
            <button className="mt-6 px-6 py-2.5 bg-accent/10 hover:bg-accent/20 text-accent border border-accent/20 rounded-full text-sm font-medium transition-colors shadow-[0_4px_15px_rgba(124,77,255,0.1)] hover:shadow-[0_4px_20px_rgba(124,77,255,0.2)]">
              Browse Files
            </button>
          </div>

          {/* Upload Progress */}
          {Object.keys(uploadProgress).length > 0 && (
            <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-6 space-y-4 shadow-[0_8px_32px_rgba(0,0,0,0.15)] backdrop-blur-md">
              <h4 className="text-sm font-medium text-white mb-4">Uploading Files...</h4>
              {Object.entries(uploadProgress).map(([id, progress]) => (
                <div key={id} className="space-y-2">
                  <div className="flex justify-between text-xs text-gray-400 font-medium">
                    <span className="truncate max-w-[200px]">{id.split('-')[0]}</span>
                    <span className="text-accent">{progress}%</span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                    <div className="bg-gradient-to-r from-accent to-[#A855F7] h-full rounded-full transition-all duration-300 relative shadow-[0_0_10px_rgba(124,77,255,0.5)]" style={{ width: `${progress}%` }}>
                       <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Files Grid */}
        <div className="lg:col-span-2">
          <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 md:p-8 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] h-full min-h-[500px]">
             
            <div className="flex justify-between items-center mb-6 border-b border-white/5 pb-4">
               <h3 className="text-lg font-medium text-white">Your Files</h3>
               <div className="text-sm text-gray-500 bg-white/5 px-3 py-1 rounded-full">{files.length} items</div>
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center h-64 text-gray-400 space-y-4">
                <div className="w-8 h-8 border-2 border-white/20 border-t-accent rounded-full animate-spin"></div>
                <span className="text-xs tracking-widest uppercase font-medium">Loading Media</span>
              </div>
            ) : files.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-center text-gray-500 w-full border-2 border-dashed border-white/5 rounded-2xl mx-auto">
                <File size={40} className="mb-4 opacity-30" />
                <p>No files uploaded yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 auto-rows-max">
                <AnimatePresence>
                  {files.map((file, i) => (
                    <motion.div 
                      key={file.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.2, delay: i * 0.02 }}
                      className="group relative bg-[#09101C] border border-white/10 rounded-2xl overflow-hidden hover:border-accent/40 transition-all cursor-pointer flex flex-col hover:shadow-[0_8px_24px_rgba(124,77,255,0.15)] shadow-md"
                    >
                      <div className="w-full aspect-square overflow-hidden relative bg-black flex items-center justify-center">
                        {isImage(file.originalName) ? (
                          <img src={file.url} alt={file.originalName} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100" />
                        ) : (
                          <div className="transform group-hover:scale-110 transition-transform duration-500">
                             {getFileIcon(file.originalName)}
                          </div>
                        )}
                        
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-3">
                           <div className="flex gap-2 justify-end mb-1">
                             <button onClick={() => setEditingFile(file)} className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-accent border border-white/20 transition-all backdrop-blur-md tooltip-trigger" title="Edit Section">
                               <Edit2 size={14} />
                             </button>
                             <button onClick={(e) => { e.stopPropagation(); deleteFile(file.id); }} className="w-8 h-8 rounded-full bg-red-500/20 text-red-200 border border-red-500/30 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all backdrop-blur-md" title="Delete File">
                               <Trash2 size={14} />
                             </button>
                           </div>
                        </div>
                      </div>
                      <div className="p-3 bg-white/[0.01]">
                        <div className="text-xs font-medium text-gray-200 truncate mb-1" title={file.originalName}>
                          {file.originalName}
                        </div>
                        <div className="flex justify-between items-center text-[10px]">
                           <span className="text-accent font-medium bg-accent/10 px-1.5 py-0.5 rounded uppercase tracking-wider">{file.section}</span>
                           <span className="text-gray-500">{formatSize(file.size)}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

      </div>

      <AnimatePresence>
        {editingFile && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
             <motion.div 
               initial={{ scale: 0.95 }}
               animate={{ scale: 1 }}
               exit={{ scale: 0.95 }}
               className="bg-[#09101C] border border-white/10 p-8 rounded-3xl w-full max-w-sm shadow-2xl relative"
             >
                <button onClick={() => setEditingFile(null)} className="absolute top-4 right-4 text-gray-500 hover:text-white"><X size={20}/></button>
                <h3 className="text-xl text-white font-medium mb-6">Assign to Section</h3>
                <div className="w-full aspect-video rounded-xl bg-black mb-6 overflow-hidden flex items-center justify-center border border-white/5">
                   {isImage(editingFile.originalName) ? (
                     <img src={editingFile.url} alt="Preview" className="w-full h-full object-cover" />
                   ) : getFileIcon(editingFile.originalName)}
                </div>
                <div className="space-y-4">
                   <label className="text-xs uppercase tracking-widest text-gray-500">Frontend Section</label>
                   <div className="grid grid-cols-2 gap-2">
                      {SECTIONS.map(sec => (
                        <button
                          key={sec}
                          onClick={() => updateSection(editingFile.id, sec)}
                          className={`px-3 py-2 text-xs font-medium rounded-lg text-left transition-all ${editingFile.section === sec ? 'bg-accent/20 border-accent text-accent' : 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10 hover:text-white'} border`}
                        >
                          {sec}
                        </button>
                      ))}
                   </div>
                </div>
             </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
