import React, { useEffect, useState } from 'react';
import { Trash2, Mail, Clock, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

interface Message {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
  isRead: number;
}

export default function AdminMessages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = () => {
    setLoading(true);
    fetch('/api/messages')
      .then(res => res.json())
      .then(data => {
        setMessages(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        toast.error('Failed to load messages');
        setLoading(false);
      });
  };

  const deleteMessage = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this message?')) return;
    try {
      const res = await fetch(`/api/messages/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Message deleted');
        fetchMessages();
      } else {
        toast.error('Failed to delete message');
      }
    } catch (err) {
      console.error(err);
      toast.error('Error deleting message');
    }
  };

  const markAsRead = async (id: number) => {
    try {
      const res = await fetch(`/api/messages/${id}/read`, { method: 'PUT' });
      if (res.ok) {
        fetchMessages();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white">Inbox Messages</h1>
          <p className="text-gray-400 text-sm tracking-wide">Manage your general contact form submissions.</p>
        </div>
        <div className="flex items-center gap-4 bg-white/[0.02] border border-white/10 rounded-full px-5 py-2.5 shadow-inner backdrop-blur-md">
          <Mail size={18} className="text-accent" />
          <div className="text-sm font-medium">
            <span className="text-white">{messages.length}</span> <span className="text-gray-500">total messages</span>
          </div>
        </div>
      </div>

      <div className="bg-white/[0.02] border border-white/5 rounded-3xl overflow-hidden backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
        {loading ? (
          <div className="p-16 text-center flex flex-col items-center justify-center space-y-4">
            <div className="w-8 h-8 border-2 border-white/20 border-t-accent rounded-full animate-spin"></div>
            <span className="text-xs tracking-widest uppercase font-medium text-gray-400">Loading Inbox</span>
          </div>
        ) : messages.length === 0 ? (
          <div className="p-16 text-center flex flex-col items-center border-2 border-dashed border-white/5 rounded-3xl m-8">
            <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-500 mb-4 shadow-inner">
              <Mail size={24} />
            </div>
            <p className="text-gray-300 font-medium">Inbox Zero</p>
            <p className="text-sm text-gray-500 mt-1">No messages to read right now.</p>
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div 
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className={`p-6 md:p-8 transition-colors group ${msg.isRead === 0 ? 'bg-accent-[0.03] hover:bg-accent/5' : 'hover:bg-white/[0.02]'}`}
                >
                  <div className="flex flex-col md:flex-row gap-6 justify-between items-start">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-center gap-4 flex-wrap">
                        {msg.isRead === 0 && <div className="w-2 h-2 rounded-full bg-accent shadow-[0_0_8px_rgba(124,77,255,0.8)]"></div>}
                        <h3 className={`text-lg transition-colors ${msg.isRead === 0 ? 'font-bold text-white' : 'font-medium text-gray-200'}`}>
                          {msg.name}
                        </h3>
                        <a href={`mailto:${msg.email}`} className="text-xs font-medium text-gray-400 hover:text-accent tracking-wide transition-colors bg-white/5 px-2.5 py-1 rounded-md border border-white/5">
                          {msg.email}
                        </a>
                        <div className="flex items-center gap-1.5 text-xs text-gray-500">
                          <Clock size={12} />
                          {new Date(msg.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      {msg.subject && (
                        <div className="text-sm font-medium text-accent">
                          Subject: {msg.subject}
                        </div>
                      )}
                      
                      <div className="bg-black/40 p-5 rounded-2xl border border-white/5 text-gray-300 text-sm leading-relaxed whitespace-pre-wrap shadow-inner relative">
                        {msg.message}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 shrink-0 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                      {msg.isRead === 0 && (
                        <button 
                          onClick={() => markAsRead(msg.id)}
                          className="w-10 h-10 rounded-full flex items-center justify-center text-accent hover:text-white hover:bg-accent hover:shadow-[0_0_15px_rgba(124,77,255,0.4)] transition-all bg-accent/10 border border-accent/20 tooltip-trigger"
                          title="Mark as Read"
                        >
                          <CheckCircle2 size={16} />
                        </button>
                      )}
                      <button 
                        onClick={() => deleteMessage(msg.id)}
                        className="w-10 h-10 rounded-full flex items-center justify-center text-red-400 hover:text-white hover:bg-red-500 hover:shadow-[0_0_15px_rgba(239,68,68,0.4)] transition-all bg-red-500/10 border border-red-500/20 tooltip-trigger"
                        title="Delete Message"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
