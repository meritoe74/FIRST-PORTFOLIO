import React, { useState, useEffect, useRef } from 'react';
import * as LucideIcons from 'lucide-react';
import { Edit2, Image as ImageIcon, Save, X, Plus, UploadCloud, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminServices() {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<any>(null);
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const res = await fetch('/api/services');
      const data = await res.json();
      setServices(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (service: any) => {
    setEditingId(service.id);
    setEditForm({ ...service });
  };

  const handleSave = async () => {
    try {
      await fetch(`/api/services/${editForm.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm)
      });
      setServices(prev => prev.map(s => s.id === editForm.id ? editForm : s));
      setEditingId(null);
      setEditForm(null);
    } catch (e) {
      console.error(e);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const formData = new FormData();
      formData.append('file', file);
      
      setUploadProgress(10);
      try {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/upload', true);
        
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const percentComplete = (e.loaded / e.total) * 100;
            setUploadProgress(Math.round(percentComplete));
          }
        };

        xhr.onload = () => {
          if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            setEditForm((prev: any) => ({
              ...prev,
              images: [...(prev.images || []), data.url]
            }));
          }
          setUploadProgress(0);
        };
        
        xhr.onerror = () => {
          console.error("Upload failed");
          setUploadProgress(0);
        };

        xhr.send(formData);
      } catch (err) {
        console.error(err);
        setUploadProgress(0);
      }
    }
    // reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveImage = (index: number) => {
    setEditForm((prev: any) => {
      const newImages = [...prev.images];
      newImages.splice(index, 1);
      return { ...prev, images: newImages };
    });
  };

  const renderIcon = (iconName: string) => {
    // @ts-ignore
    const IconComponent = LucideIcons[iconName] || LucideIcons.HelpCircle;
    return <IconComponent size={32} />;
  };

  if (loading) return <div className="text-white text-center py-20">Loading services...</div>;

  return (
    <div className="max-w-[1200px] mx-auto space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white">Services Configuration</h1>
          <p className="text-gray-400 text-sm tracking-wide">Manage the services offered, descriptions, and feature images.</p>
        </div>
        <button className="flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-white px-5 py-2.5 rounded-full text-sm font-medium transition-all shadow-inner">
          <Plus size={16} /> Add Service
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <AnimatePresence>
          {services.map(service => (
            <motion.div 
              layout
              key={service.id} 
              className={`bg-white/[0.02] border border-white/5 rounded-3xl overflow-hidden backdrop-blur-xl transition-all duration-300 ${editingId === service.id ? 'col-span-1 md:col-span-2 border-accent/40 shadow-[0_8px_32px_rgba(124,77,255,0.1)]' : 'hover:bg-white/[0.04]'}`}
            >
              {editingId === service.id ? (
                <div className="p-8">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-medium text-white flex items-center gap-3">
                      <div className="p-2 bg-accent/20 text-accent rounded-lg">{renderIcon(service.icon)}</div>
                      Editing {service.title}
                    </h3>
                    <div className="flex gap-2">
                       <button onClick={() => setEditingId(null)} className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"><X size={18}/></button>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Service Title</label>
                        <input type="text" value={editForm.title} onChange={e => setEditForm({...editForm, title: e.target.value})} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Slug</label>
                        <input type="text" value={editForm.slug} readOnly className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-gray-500 text-sm cursor-not-allowed" />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Short Description</label>
                      <textarea value={editForm.desc} onChange={e => setEditForm({...editForm, desc: e.target.value})} className="w-full h-24 bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none resize-none"></textarea>
                    </div>
                    
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Long Description</label>
                      <textarea value={editForm.longDesc} onChange={e => setEditForm({...editForm, longDesc: e.target.value})} className="w-full h-40 bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none resize-none"></textarea>
                    </div>

                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-4">Gallery Images</label>
                      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide items-center">
                        {editForm.images?.map((img: string, i: number) => (
                           <div key={i} className="relative w-32 h-32 rounded-xl overflow-hidden group shrink-0 border border-white/10">
                              <img src={img} alt="Gallery" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                              <button onClick={() => handleRemoveImage(i)} className="absolute top-2 right-2 w-8 h-8 bg-red-500/80 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={14}/></button>
                           </div>
                        ))}
                        <div 
                          className="w-32 h-32 rounded-xl border-2 border-dashed border-white/10 hover:border-accent/50 flex flex-col items-center justify-center cursor-pointer hover:bg-accent/5 transition-colors shrink-0 text-gray-500 hover:text-accent relative"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          {uploadProgress > 0 ? (
                            <div className="flex flex-col items-center">
                               <div className="w-6 h-6 border-2 border-white/20 border-t-accent rounded-full animate-spin mb-2"></div>
                               <span className="text-xs">{uploadProgress}%</span>
                            </div>
                          ) : (
                            <>
                              <UploadCloud size={24} className="mb-2"/>
                              <span className="text-xs uppercase tracking-widest">Add Image</span>
                            </>
                          )}
                          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" multiple onChange={handleImageUpload} />
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-white/5 flex justify-end gap-3">
                       <button onClick={() => setEditingId(null)} className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl text-sm font-medium transition-colors border border-white/10">Discard Changes</button>
                       <button onClick={handleSave} className="flex items-center gap-2 px-5 py-2.5 bg-accent hover:bg-accent/90 text-white rounded-xl text-sm font-medium transition-colors border border-accent/50 shadow-inner">
                         <Save size={16} /> Save Configuration
                       </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-8 h-full flex flex-col bg-white/[0.01]">
                  <div className="flex justify-between items-start mb-6">
                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl text-accent shadow-inner flex items-center justify-center">
                      {renderIcon(service.icon)}
                    </div>
                    <button onClick={() => handleEdit(service)} className="w-10 h-10 rounded-full flex items-center justify-center bg-white/5 hover:bg-accent hover:text-white text-gray-400 transition-all border border-white/10">
                      <Edit2 size={16} />
                    </button>
                  </div>
                  <h3 className="text-xl font-medium text-white mb-3">{service.title}</h3>
                  <p className="text-sm text-gray-400 leading-relaxed mb-8 flex-1 line-clamp-3">{service.desc}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-widest font-medium">
                    <ImageIcon size={14} className="text-gray-400" />
                    <span>{service.images?.length || 0} Gallery Images</span>
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
