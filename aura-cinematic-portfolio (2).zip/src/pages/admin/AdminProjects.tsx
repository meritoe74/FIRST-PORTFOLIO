import React, { useEffect, useState, useRef } from 'react';
import { Project, Category } from '../../types';
import { Plus, Edit2, Trash2, X, UploadCloud, Search, Image as ImageIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

export default function AdminProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const defaultForm = { title: '', slug: '', categoryId: 1, excerpt: '', description: '', tools: '', imageUrl: '', featured: 0, orderIndex: 0, tags: '', mediaGallery: '', externalLink: '' };
  const [form, setForm] = useState(defaultForm);
  const [uploadProgress, setUploadProgress] = useState(0);

  useEffect(() => {
    fetchProjects();
    fetch('/api/categories').then(res => res.json()).then(setCategories);
  }, []);

  const fetchProjects = () => {
    fetch('/api/projects')
      .then(res => res.json())
      .then(setProjects)
      .catch(err => {
        console.error(err);
        toast.error('Failed to load projects');
      });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload', true);
    
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        setUploadProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    xhr.onload = () => {
      if (xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        setForm(prev => ({ ...prev, imageUrl: data.url }));
        toast.success('Image uploaded successfully');
      } else {
        toast.error('Failed to upload image');
      }
      setUploadProgress(0);
    };

    xhr.onerror = () => {
      toast.error('Failed to upload image');
      setUploadProgress(0);
    };

    xhr.send(formData);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const url = isEditing ? `/api/projects/${editingId}` : '/api/projects';
      const method = isEditing ? 'PUT' : 'POST';

      const payload = {
        ...form,
        tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
        mediaGallery: form.mediaGallery.split(',').map(m => m.trim()).filter(Boolean)
      };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (res.ok) {
        toast.success(isEditing ? 'Project updated successfully' : 'Project created successfully');
        closeModal();
        fetchProjects();
      } else {
        toast.error(isEditing ? 'Failed to update project' : 'Failed to create project');
      }
    } catch (err) {
      console.error(err);
      toast.error('An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (project: Project) => {
    setForm({
      title: project.title,
      slug: project.slug,
      categoryId: project.categoryId,
      excerpt: project.excerpt,
      description: project.description,
      tools: project.tools || '',
      imageUrl: project.imageUrl || '',
      featured: project.featured || 0,
      orderIndex: project.orderIndex || 0,
      tags: project.tags ? JSON.parse(project.tags).join(', ') : '',
      mediaGallery: project.mediaGallery ? JSON.parse(project.mediaGallery).join(', ') : '',
      externalLink: project.externalLink || ''
    });
    setEditingId(project.id);
    setIsEditing(true);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this project permanently?')) return;
    try {
      const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Project deleted');
        fetchProjects();
      } else {
        toast.error('Failed to delete project');
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to delete project');
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setIsEditing(false);
    setEditingId(null);
    setForm(defaultForm);
  };

  return (
    <div className="max-w-[1400px] mx-auto space-y-8 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white drop-shadow-md">Portfolio Projects</h1>
          <p className="text-gray-400 text-sm tracking-wide">Manage your works, case studies, and live projects.</p>
        </div>
        <div className="flex gap-4">
           <div className="bg-white/5 border border-white/10 rounded-full px-4 py-2 flex items-center backdrop-blur-md hidden md:flex">
              <Search size={16} className="text-gray-400 mr-2" />
              <input type="text" placeholder="Search projects..." className="bg-transparent border-none focus:outline-none text-sm text-white" />
           </div>
           <button 
             onClick={() => setIsModalOpen(true)}
             className="bg-accent hover:bg-accent/90 text-white px-6 py-2.5 rounded-full flex items-center gap-2 font-medium transition-all shadow-[0_0_15px_rgba(124,77,255,0.4)] hover:shadow-[0_0_25px_rgba(124,77,255,0.6)] border border-accent/50 text-sm tracking-wide"
           >
             <Plus size={16} /> Add Project
           </button>
        </div>
      </div>

      <div className="bg-white/[0.02] border border-white/5 rounded-3xl overflow-hidden backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="border-b border-white/5 text-[10px] uppercase tracking-[0.2em] text-gray-500 bg-white/[0.01]">
                <th className="p-6 font-medium">Project Title</th>
                <th className="p-6 font-medium">Category</th>
                <th className="p-6 font-medium">Date added</th>
                <th className="p-6 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {projects.map((project, i) => (
                  <motion.tr 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    key={project.id} 
                    className="border-b border-white/5 hover:bg-white/[0.03] transition-colors group"
                  >
                    <td className="p-4 md:p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-xl overflow-hidden bg-white/5 border border-white/10 shrink-0 flex items-center justify-center">
                          {project.imageUrl ? (
                            <img src={project.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                          ) : (
                            <ImageIcon size={20} className="text-gray-500" />
                          )}
                        </div>
                        <div>
                          <div className="font-medium text-white mb-1 text-base">{project.title}</div>
                          <div className="text-[10px] text-gray-400 font-mono bg-white/5 inline-block px-2 py-0.5 rounded-md border border-white/5">/{project.slug}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 md:p-6">
                      <span className="bg-white/5 text-gray-300 border border-white/10 px-3 py-1 rounded-full text-xs font-medium tracking-wide">{project.categoryName}</span>
                    </td>
                    <td className="p-4 md:p-6 text-gray-400 text-sm flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent shadow-[0_0_8px_rgba(124,77,255,0.8)]"></div>
                      {new Date(project.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-4 md:p-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => handleEdit(project)} className="w-9 h-9 rounded-full flex items-center justify-center text-gray-400 hover:text-accent hover:bg-accent/10 border border-transparent hover:border-accent/30 transition-all tooltip-trigger" title="Edit Project">
                          <Edit2 size={14} />
                        </button>
                        <button 
                          onClick={() => handleDelete(project.id)}
                          className="w-9 h-9 rounded-full flex items-center justify-center text-gray-400 hover:text-red-400 hover:bg-red-500/10 border border-transparent hover:border-red-500/30 transition-all tooltip-trigger" title="Delete Project"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
              {projects.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-16 text-center text-gray-500">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4 border border-white/10"><Search size={24} /></div>
                    <p>No projects found. Ready to create your first one?</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="bg-[#09101C] border border-white/10 rounded-[2rem] w-full max-w-3xl my-12 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-accent/20 rounded-full filter blur-[100px] pointer-events-none"></div>

              <button onClick={closeModal} className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors z-10 border border-white/10">
                <X size={20} />
              </button>
              
              <div className="p-8 lg:p-12 relative z-10">
                <h2 className="text-2xl font-display font-medium mb-8 text-white">{isEditing ? 'Edit Project' : 'Create New Project'}</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  
                  {/* Upload Area */}
                  <div 
                    className={`border-2 border-dashed rounded-2xl p-10 text-center transition-all cursor-pointer relative overflow-hidden group ${form.imageUrl ? 'border-accent/50 bg-accent/5' : 'border-white/10 bg-white/5 hover:border-accent/50 hover:bg-black/20'}`}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {form.imageUrl ? (
                      <div className="absolute inset-0 flex items-center justify-center bg-black">
                         <img src={form.imageUrl} alt="Preview" className="w-full h-full object-cover opacity-60 group-hover:opacity-30 transition-opacity" />
                         <div className="absolute flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white">
                            <UploadCloud size={32} className="mb-2 drop-shadow-md" />
                            <span className="font-medium text-sm drop-shadow-md tracking-wide">Replace Cover Image</span>
                         </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center space-y-4">
                        <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 group-hover:text-accent group-hover:bg-accent/10 transition-all">
                          <UploadCloud size={24} />
                        </div>
                        <div>
                          <p className="font-medium text-white mb-1">Click to upload featured image</p>
                          <p className="text-xs text-gray-500 uppercase tracking-widest">JPG, PNG, WEBP (Max 5MB)</p>
                        </div>
                      </div>
                    )}
                    {uploadProgress > 0 && uploadProgress < 100 && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center text-white z-20">
                        <div className="w-12 h-12 border-2 border-white/10 border-t-accent rounded-full animate-spin mb-4"></div>
                        <div className="text-sm font-medium tracking-widest uppercase text-accent">Uploading {uploadProgress}%</div>
                      </div>
                    )}
                    <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} accept="image/*" />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Project Title</label>
                      <input required type="text" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" value={form.title} onChange={e => {
                          const t = e.target.value;
                          setForm({...form, title: t, slug: t.toLowerCase().replace(/[^a-z0-9]+/g, '-')});
                        }} 
                      />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">URL Slug</label>
                      <input required type="text" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" value={form.slug} onChange={e => setForm({...form, slug: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Category</label>
                      <select className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 appearance-none transition-colors" value={form.categoryId} onChange={e => setForm({...form, categoryId: parseInt(e.target.value)})}>
                        {categories.map(c => <option key={c.id} value={c.id} className="bg-[#09101C] text-white">{c.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Tools / Software <span className="lowercase normal-case text-[10px] text-gray-600">(comma separated)</span></label>
                      <input type="text" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" placeholder="React, Figma..." value={form.tools} onChange={e => setForm({...form, tools: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Tags <span className="lowercase normal-case text-[10px] text-gray-600">(comma separated)</span></label>
                      <input type="text" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" placeholder="e.g. UX, Editorial..." value={form.tags} onChange={e => setForm({...form, tags: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">External Link</label>
                      <input type="url" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" placeholder="https://..." value={form.externalLink} onChange={e => setForm({...form, externalLink: e.target.value})} />
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Order Index</label>
                        <input type="number" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" placeholder="0" value={form.orderIndex} onChange={e => setForm({...form, orderIndex: parseInt(e.target.value) || 0})} />
                      </div>
                      <div className="flex-1 flex flex-col justify-end pb-3">
                        <label className="flex items-center gap-3 cursor-pointer">
                          <input type="checkbox" className="w-5 h-5 rounded border-white/10 bg-black/20 text-accent focus:ring-accent focus:ring-offset-0" checked={form.featured === 1} onChange={e => setForm({...form, featured: e.target.checked ? 1 : 0})} />
                          <span className="text-sm font-medium text-white">Featured</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Short Excerpt (List view)</label>
                    <input required type="text" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" value={form.excerpt} onChange={e => setForm({...form, excerpt: e.target.value})} />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Full Description</label>
                    <textarea required rows={4} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 resize-none transition-colors" value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Media Gallery URLs <span className="lowercase normal-case text-[10px] text-gray-600">(comma separated, for fullscreen gallery)</span></label>
                    <textarea rows={2} className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 resize-none transition-colors" placeholder="https://image1.jpg, https://image2.jpg" value={form.mediaGallery} onChange={e => setForm({...form, mediaGallery: e.target.value})} />
                  </div>

                 <div className="flex justify-end gap-3 pt-6 border-t border-white/5">
                   <button type="button" onClick={closeModal} className="px-6 py-2.5 font-medium text-white bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-colors text-sm">Cancel</button>
                   <button type="submit" disabled={loading} className="px-8 py-2.5 bg-accent hover:bg-accent/90 text-white rounded-xl font-medium tracking-wide transition-colors text-sm shadow-[0_4px_15px_rgba(124,77,255,0.3)] border border-accent/50 disabled:opacity-50">
                     {loading ? 'Saving...' : (isEditing ? 'Save Changes' : 'Publish Project')}
                   </button>
                 </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
