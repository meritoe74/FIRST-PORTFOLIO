import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, LineChart, Line, Legend } from 'recharts';
import { Eye, Users, MousePointer2, ArrowUpRight, ArrowDownRight, Clock, MapPin, Monitor, Smartphone, Globe } from 'lucide-react';
import { motion } from 'motion/react';

const visitData = [
  { name: 'Mon', organic: 1200, direct: 800, referral: 400 },
  { name: 'Tue', organic: 1400, direct: 900, referral: 300 },
  { name: 'Wed', organic: 1100, direct: 1100, referral: 600 },
  { name: 'Thu', organic: 1600, direct: 1000, referral: 450 },
  { name: 'Fri', organic: 1800, direct: 1200, referral: 500 },
  { name: 'Sat', organic: 2400, direct: 800, referral: 700 },
  { name: 'Sun', organic: 2100, direct: 1000, referral: 800 },
];

const sourceData = [
  { name: 'Instagram', value: 45 },
  { name: 'Google', value: 30 },
  { name: 'Direct', value: 15 },
  { name: 'Twitter', value: 10 },
];

export default function AdminAnalytics() {
  return (
    <div className="max-w-[1600px] mx-auto space-y-8">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white">Analytics</h1>
          <p className="text-gray-400 text-sm tracking-wide">Deep dive into your portfolio traffic and engagement.</p>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-lg p-1 shadow-inner backdrop-blur-md flex text-sm">
          <button className="px-4 py-1.5 rounded-md bg-white/10 text-white font-medium shadow-sm">7 Days</button>
          <button className="px-4 py-1.5 rounded-md text-gray-400 hover:text-white transition-colors">30 Days</button>
          <button className="px-4 py-1.5 rounded-md text-gray-400 hover:text-white transition-colors">1 Year</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="Total Pageviews" value="42,894" trend="+12.5%" trendUp={true} icon={<Eye />} />
        <MetricCard title="Unique Visitors" value="12,403" trend="+5.2%" trendUp={true} icon={<Users />} />
        <MetricCard title="Bounce Rate" value="34.2%" trend="-2.1%" trendUp={true} icon={<MousePointer2 />} />
        <MetricCard title="Avg Session" value="2m 45s" trend="-0.4%" trendUp={false} icon={<Clock />} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="xl:col-span-2 bg-white/[0.02] border border-white/5 rounded-3xl p-8 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-lg font-medium text-white">Traffic Sources Overview</h3>
            <button className="text-xs text-accent hover:text-white transition-colors">Export CSV</button>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={visitData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorOrganic" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#7C4DFF" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#7C4DFF" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorDirect" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorReferral" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#4B5563" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#4B5563" fontSize={12} tickLine={false} axisLine={false} />
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '12px' }}
                  itemStyle={{ fontSize: '12px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#9CA3AF' }} />
                <Area type="monotone" dataKey="organic" name="Organic Search" stroke="#7C4DFF" strokeWidth={2} fillOpacity={1} fill="url(#colorOrganic)" />
                <Area type="monotone" dataKey="direct" name="Direct" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#colorDirect)" />
                <Area type="monotone" dataKey="referral" name="Social/Referral" stroke="#10B981" strokeWidth={2} fillOpacity={1} fill="url(#colorReferral)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Small Widgets */}
        <div className="space-y-6">
          <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 backdrop-blur-xl">
             <h3 className="text-sm font-medium text-white mb-6 uppercase tracking-widest text-gray-500">Top Locations</h3>
             <div className="space-y-4">
                <LocationBar country="United States" val={45} />
                <LocationBar country="United Kingdom" val={22} />
                <LocationBar country="Canada" val={15} />
                <LocationBar country="Germany" val={8} />
                <LocationBar country="Others" val={10} />
             </div>
          </div>

          <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 backdrop-blur-xl">
             <h3 className="text-sm font-medium text-white mb-6 uppercase tracking-widest text-gray-500">Devices</h3>
             <div className="grid grid-cols-2 gap-4">
                <DeviceStat icon={<Monitor />} label="Desktop" value="62%" />
                <DeviceStat icon={<Smartphone />} label="Mobile" value="38%" />
             </div>
          </div>
        </div>
      </div>

    </div>
  );
}

function MetricCard({ title, value, trend, trendUp, icon }: any) {
  return (
    <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 hover:bg-white/[0.04] transition-colors relative overflow-hidden group">
       <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full filter blur-[40px] opacity-0 group-hover:opacity-100 transition-opacity"></div>
       <div className="flex justify-between items-start mb-4 relative z-10">
         <div className="p-3 bg-white/5 border border-white/10 rounded-xl text-gray-300 shadow-inner">
           {icon}
         </div>
         <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-md ${trendUp ? 'text-green-400 bg-green-400/10' : 'text-red-400 bg-red-400/10'}`}>
            {trendUp ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            {trend}
         </div>
       </div>
       <div className="relative z-10">
         <div className="text-sm text-gray-400 mb-1">{title}</div>
         <div className="text-3xl font-display font-medium text-white tracking-tight">{value}</div>
       </div>
    </div>
  )
}

function LocationBar({ country, val }: { country: string, val: number }) {
  return (
    <div>
      <div className="flex justify-between text-xs text-gray-400 mb-1.5">
        <span>{country}</span>
        <span className="text-white">{val}%</span>
      </div>
      <div className="w-full bg-white/5 rounded-full h-1.5 hide-overflow">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${val}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="bg-gradient-to-r from-accent to-[#A855F7] h-full rounded-full"
        />
      </div>
    </div>
  )
}

function DeviceStat({ icon, label, value }: any) {
  return (
    <div className="flex flex-col items-center justify-center p-4 bg-white/5 border border-white/10 rounded-xl">
       <div className="text-gray-400 mb-2">{icon}</div>
       <div className="text-xl font-medium text-white mb-1">{value}</div>
       <div className="text-[10px] text-gray-500 uppercase tracking-widest">{label}</div>
    </div>
  )
}
