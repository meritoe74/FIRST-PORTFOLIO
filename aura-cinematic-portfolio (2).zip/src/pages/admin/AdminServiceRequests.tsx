import React, { useEffect, useState } from 'react';
import { Trash2, Briefcase, Clock, CheckCircle, Circle, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

interface ServiceRequest {
  id: number;
  name: string;
  email: string;
  projectType: string;
  message: string;
  status: string;
  createdAt: string;
  isRead: number;
}

export default function AdminServiceRequests() {
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = () => {
    setLoading(true);
    fetch('/api/service_requests')
      .then(res => res.json())
      .then(data => {
        setRequests(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        toast.error('Failed to load requests');
        setLoading(false);
      });
  };

  const deleteRequest = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this service request?')) return;
    try {
      const res = await fetch(`/api/service_requests/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Request deleted');
        fetchRequests();
      } else {
        toast.error('Failed to delete request');
      }
    } catch (err) {
      console.error(err);
      toast.error('Error deleting request');
    }
  };

  const toggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'pending' ? 'completed' : 'pending';
    try {
      const res = await fetch(`/api/service_requests/${id}/status`, { 
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        toast.success(`Marked as ${newStatus}`);
        fetchRequests();
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to update status');
    }
  };

  const markAsRead = async (id: number) => {
    try {
      const res = await fetch(`/api/service_requests/${id}/read`, { method: 'PUT' });
      if (res.ok) {
        fetchRequests();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredRequests = filter === 'All' 
    ? requests 
    : requests.filter(r => r.projectType === filter);

  // Get unique service types for the filter dropdown
  const serviceTypes = ['All', ...Array.from(new Set(requests.map(r => r.projectType)))];

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white">Service Requests</h1>
          <p className="text-gray-400 text-sm tracking-wide">Manage specific service inquiries and project briefs.</p>
        </div>
        
        <div className="flex items-center gap-4">
          {requests.length > 0 && (
            <select 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-white/[0.02] border border-white/10 px-4 py-2.5 rounded-full text-white focus:outline-none focus:border-accent text-sm shadow-inner backdrop-blur-md"
            >
              {serviceTypes.map(type => (
                <option key={type} value={type} className="bg-[#09101C] text-white py-1">{type}</option>
              ))}
            </select>
          )}
          <div className="flex items-center gap-2 bg-white/[0.02] border border-white/10 rounded-full px-5 py-2.5 shadow-inner backdrop-blur-md">
            <Briefcase size={18} className="text-accent" />
            <div className="text-sm font-medium">
              <span className="text-white">{filteredRequests.length}</span> <span className="text-gray-500">requests</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white/[0.02] border border-white/5 rounded-3xl overflow-hidden backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]">
        {loading ? (
          <div className="p-16 text-center flex flex-col items-center justify-center space-y-4">
            <div className="w-8 h-8 border-2 border-white/20 border-t-accent rounded-full animate-spin"></div>
            <span className="text-xs tracking-widest uppercase font-medium text-gray-400">Loading Requests</span>
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-16 text-center flex flex-col items-center border-2 border-dashed border-white/5 rounded-3xl m-8">
            <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-500 mb-4 shadow-inner">
              <Briefcase size={24} />
            </div>
            <p className="text-gray-300 font-medium">No service requests found.</p>
            <p className="text-sm text-gray-500 mt-1">When clients request a service, it will appear here.</p>
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            <AnimatePresence>
              {filteredRequests.map((req) => (
                <motion.div 
                  key={req.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className={`p-6 md:p-8 transition-colors group ${req.status === 'completed' ? 'opacity-60 hover:opacity-100' : ''} ${req.isRead === 0 ? 'bg-accent-[0.03] hover:bg-accent/5' : 'hover:bg-white/[0.02]'}`}
                >
                  <div className="flex flex-col md:flex-row gap-6 justify-between items-start">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-center gap-4 flex-wrap">
                        {req.isRead === 0 && <div className="w-2 h-2 rounded-full bg-accent shadow-[0_0_8px_rgba(124,77,255,0.8)]"></div>}
                        <button 
                          onClick={() => toggleStatus(req.id, req.status)}
                          className={`flex items-center gap-2 text-xs font-medium uppercase tracking-wider px-3 py-1.5 rounded-full border transition-all hover:scale-105 active:scale-95 ${
                            req.status === 'completed' 
                              ? 'border-green-500/30 text-green-400 bg-green-500/10 hover:bg-green-500/20 shadow-[0_0_10px_rgba(34,197,94,0.2)]' 
                              : 'border-yellow-500/30 text-yellow-400 bg-yellow-500/10 hover:bg-yellow-500/20 shadow-[0_0_10px_rgba(234,179,8,0.2)]'
                          }`}
                        >
                          {req.status === 'completed' ? <CheckCircle size={14} /> : <Circle size={14} />}
                          {req.status}
                        </button>
                        
                        <div className="text-xs font-medium text-accent bg-accent/10 px-3 py-1.5 rounded-full border border-accent/20">
                          {req.projectType}
                        </div>
                        
                        <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-white/5 px-2.5 py-1.5 rounded-md border border-white/5">
                          <Clock size={12} />
                          {new Date(req.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      <div className="flex items-baseline gap-3">
                        <h3 className={`text-xl transition-colors ${req.isRead === 0 ? 'font-bold text-white' : 'font-medium text-gray-200'}`}>
                          {req.name}
                        </h3>
                        <a href={`mailto:${req.email}`} className="text-gray-400 text-sm hover:text-accent transition-colors bg-white/5 px-2.5 py-1 rounded-md border border-white/5">
                          {req.email}
                        </a>
                      </div>
                      
                      <div className="bg-black/40 p-5 rounded-2xl border border-white/5 text-gray-300 text-sm leading-relaxed whitespace-pre-wrap mt-2 shadow-inner">
                        {req.message}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 shrink-0 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                      {req.isRead === 0 && (
                        <button 
                          onClick={() => markAsRead(req.id)}
                          className="w-10 h-10 rounded-full flex items-center justify-center text-accent hover:text-white hover:bg-accent hover:shadow-[0_0_15px_rgba(124,77,255,0.4)] transition-all bg-accent/10 border border-accent/20 tooltip-trigger"
                          title="Mark as Read"
                        >
                          <CheckCircle2 size={16} />
                        </button>
                      )}
                      <button 
                        onClick={() => deleteRequest(req.id)}
                        className="w-10 h-10 rounded-full flex items-center justify-center text-red-400 hover:text-white hover:bg-red-500 hover:shadow-[0_0_15px_rgba(239,68,68,0.4)] transition-all bg-red-500/10 border border-red-500/20 tooltip-trigger"
                        title="Delete Request"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
