import React, { useState } from 'react';
import { UploadCloud, Image as ImageIcon, User, Briefcase, Mail, Link as LinkIcon, Shield, Palette } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState('profile');

  const tabs = [
    { id: 'profile', label: 'Profile', icon: <User size={16} /> },
    { id: 'contact', label: 'Contact Info', icon: <Mail size={16} /> },
    { id: 'social', label: 'Social & Links', icon: <LinkIcon size={16} /> },
    { id: 'resume', label: 'Resume/CV', icon: <Briefcase size={16} /> },
    { id: 'appearance', label: 'Appearance', icon: <Palette size={16} /> },
    { id: 'security', label: 'Security', icon: <Shield size={16} /> },
  ];

  return (
    <div className="max-w-[1400px] mx-auto min-h-screen pb-20">
      <div className="mb-10">
        <h1 className="text-3xl lg:text-4xl font-display font-medium mb-3 tracking-tight text-white drop-shadow-md">Global Settings</h1>
        <p className="text-gray-400 text-sm tracking-wide">Configure your platform preferences, branding, and security.</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        
        {/* Sidebar Nav */}
        <div className="lg:w-64 shrink-0 space-y-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-4 rounded-2xl transition-all duration-300 text-sm font-medium ${
                activeTab === tab.id 
                ? 'bg-accent/10 text-white border border-accent/20 shadow-[0_0_15px_rgba(124,77,255,0.1)]' 
                : 'text-gray-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
              }`}
            >
              <div className={`p-2 rounded-lg transition-colors ${activeTab === tab.id ? 'bg-accent/20 text-accent' : 'bg-white/5'}`}>
                {tab.icon}
              </div>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 min-w-0">
          <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 lg:p-10 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] min-h-[600px] relative overflow-hidden">
             
             {/* Glows */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-accent/20 rounded-full filter blur-[100px] pointer-events-none"></div>

             <AnimatePresence mode="wait">
               <motion.div
                 key={activeTab}
                 initial={{ opacity: 0, y: 15 }}
                 animate={{ opacity: 1, y: 0 }}
                 exit={{ opacity: 0, y: -15 }}
                 transition={{ duration: 0.3 }}
                 className="relative z-10"
               >
                 {activeTab === 'profile' && <ProfileSettings />}
                 {activeTab === 'resume' && <ResumeSettings />}
                 {activeTab === 'contact' && <ContactSettings />}
                 {activeTab === 'social' && <SocialSettings />}
                 {activeTab === 'appearance' && <AppearanceSettings />}
                 {activeTab === 'security' && <SecuritySettings />}
               </motion.div>
             </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProfileSettings() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-medium text-white mb-8">Public Profile</h2>
        <div className="flex flex-col md:flex-row items-start md:items-center gap-8 mb-8">
          <div className="w-32 h-32 rounded-full overflow-hidden bg-white/5 border-2 border-white/10 shrink-0 relative group">
             <img src="https://images.unsplash.com/photo-1555169062-01246bedf4d4?q=80&w=200&auto=format&fit=crop" className="w-full h-full object-cover" />
             <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer backdrop-blur-sm">
                <UploadCloud size={24} className="text-white" />
             </div>
          </div>
          <div className="space-y-2">
             <div className="text-white font-medium">Profile Image</div>
             <div className="text-sm text-gray-400 max-w-sm">Upload a portrait image for the dashboard. Recommended size: 500x500px or larger.</div>
             <button className="mt-2 px-5 py-2.5 bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-xl text-sm font-medium transition-colors">Upload New Image</button>
          </div>
        </div>

        <div className="space-y-6">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div>
               <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Display Name</label>
               <input type="text" defaultValue="Emmanuel O." className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
             </div>
             <div>
               <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Professional Title</label>
               <input type="text" defaultValue="Creative Director" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
             </div>
           </div>
           <div>
             <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Short Bio</label>
             <textarea className="w-full h-32 bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors resize-none" defaultValue="Directing creative vision and executing digital experiences."></textarea>
           </div>
        </div>
      </div>

      <div className="pt-8 border-t border-white/5 flex justify-end">
        <button className="px-8 py-3 bg-accent hover:bg-accent/90 text-white rounded-xl text-sm font-medium transition-all shadow-[0_4px_15px_rgba(124,77,255,0.3)] hover:shadow-[0_4px_25px_rgba(124,77,255,0.5)]">Save Profile Changes</button>
      </div>
    </div>
  )
}

function ContactSettings() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-medium text-white mb-8">Contact Information</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Public Email</label>
          <input type="email" defaultValue="meritevents74@gmail.com" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Support Email (Optional)</label>
          <input type="email" placeholder="support@yourdomain.com" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Phone Number</label>
          <input type="text" defaultValue="+234 811 177 7805" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Business Hours</label>
          <input type="text" defaultValue="Mon - Fri, 9am - 5pm" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Physical Location / Address</label>
          <input type="text" defaultValue="Lad/Lak, Bariga" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
      </div>
      <div className="pt-8 border-t border-white/5 flex justify-end">
        <button className="px-8 py-3 bg-accent hover:bg-accent/90 text-white rounded-xl text-sm font-medium transition-all shadow-[0_4px_15px_rgba(124,77,255,0.3)] hover:shadow-[0_4px_25px_rgba(124,77,255,0.5)]">Update Contact Info</button>
      </div>
    </div>
  )
}

function SocialSettings() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-medium text-white mb-8">Social Media Links</h2>
      <div className="space-y-6">
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Instagram URL</label>
          <input type="text" defaultValue="https://www.instagram.com/merit_wedding_and_events_ltd" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">WhatsApp / Phone Link</label>
          <input type="text" defaultValue="https://wa.me/2348111777805" className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">LinkedIn URL</label>
          <input type="text" placeholder="https://linkedin.com/in/..." className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Twitter / X URL</label>
          <input type="text" placeholder="https://x.com/..." className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
      </div>
      <div className="pt-8 border-t border-white/5 flex justify-end">
        <button className="px-8 py-3 bg-accent hover:bg-accent/90 text-white rounded-xl text-sm font-medium transition-all shadow-[0_4px_15px_rgba(124,77,255,0.3)] hover:shadow-[0_4px_25px_rgba(124,77,255,0.5)]">Save Social Links</button>
      </div>
    </div>
  )
}

function ResumeSettings() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-medium text-white mb-8">Resume / CV Document</h2>
      <div className="border border-white/5 bg-white/[0.02] rounded-3xl p-12 text-center flex flex-col items-center justify-center min-h-[300px]">
         <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center text-accent mb-6">
            <UploadCloud size={32} />
         </div>
         <h3 className="text-lg text-white font-medium mb-3">Upload your latest Resume</h3>
         <p className="text-gray-400 text-sm mb-8 max-w-sm">Accepted formats: PDF, DOCX, ZIP. Automatically replaces the download link on your site.</p>
         <button className="px-8 py-3 bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-xl text-sm font-medium transition-colors">Select File</button>
      </div>
    </div>
  )
}

function AppearanceSettings() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-medium text-white mb-8">Theme Customization</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        <div className="border-2 border-accent rounded-xl p-4 cursor-pointer bg-accent/[0.02] shadow-[0_4px_20px_rgba(124,77,255,0.1)] relative">
           <div className="absolute top-3 right-3 w-4 h-4 rounded-full bg-accent shadow-[0_0_8px_rgba(124,77,255,0.8)]"></div>
           <div className="h-24 rounded-lg bg-[#070D18] mb-4 flex items-center justify-center border border-white/5 overflow-hidden relative">
              <div className="w-16 h-16 rounded-full bg-accent blur-[30px] opacity-40"></div>
           </div>
           <div className="text-sm font-medium text-white text-center">Midnight Blue (Active)</div>
        </div>
        <div className="border border-white/10 hover:border-white/20 rounded-xl p-4 cursor-pointer bg-white/[0.01]">
           <div className="h-24 rounded-lg bg-[#121212] mb-4 flex items-center justify-center border border-white/5 overflow-hidden">
              <div className="w-16 h-16 rounded-full bg-white blur-[30px] opacity-10"></div>
           </div>
           <div className="text-sm font-medium text-gray-400 text-center">Carbon Dark</div>
        </div>
      </div>
    </div>
  )
}

function SecuritySettings() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-medium text-white mb-8">Login & Security</h2>
      <div className="space-y-6">
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Current Password</label>
          <input type="password" placeholder="••••••••" className="w-full max-w-md bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">New Password</label>
          <input type="password" placeholder="••••••••" className="w-full max-w-md bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
        <div>
          <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Confirm New Password</label>
          <input type="password" placeholder="••••••••" className="w-full max-w-md bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors" />
        </div>
      </div>
      <div className="pt-8 border-t border-white/5 flex justify-start">
        <button className="px-8 py-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl text-sm font-medium transition-all">Update Password</button>
      </div>
    </div>
  )
}
