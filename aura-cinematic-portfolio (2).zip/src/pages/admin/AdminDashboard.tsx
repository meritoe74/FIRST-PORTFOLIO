import React, { useEffect, useState } from 'react';
import { Layers, Activity, Users, Eye, ArrowUpRight, ArrowDownRight, Clock, MapPin, UploadCloud, MessageSquare, MoreHorizontal, Image } from 'lucide-react';
import { Project, Message } from '../../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Link } from 'react-router-dom';

const data = [
  { name: 'Mon', views: 4000, visitors: 2400 },
  { name: 'Tue', views: 3000, visitors: 1398 },
  { name: 'Wed', views: 2000, visitors: 9800 },
  { name: 'Thu', views: 2780, visitors: 3908 },
  { name: 'Fri', views: 1890, visitors: 4800 },
  { name: 'Sat', views: 2390, visitors: 3800 },
  { name: 'Sun', views: 3490, visitors: 4300 },
];

export default function AdminDashboard() {
  const [stats, setStats] = useState({ projects: 0, messages: 0, views: 12480 });
  const [recentProjects, setRecentProjects] = useState<Project[]>([]);

  useEffect(() => {
    Promise.all([
      fetch('/api/projects').then(res => res.json()),
      fetch('/api/messages').then(res => res.json())
    ]).then(([projects, messages]) => {
      setStats(s => ({ ...s, projects: projects.length, messages: messages.length }));
      setRecentProjects(projects.slice(0, 4));
    });
  }, []);

  return (
    <div className="space-y-8 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-display font-medium mb-2 tracking-tight text-white drop-shadow-md">Dashboard Overview</h1>
          <p className="text-gray-400 text-sm tracking-wide">Welcome back. Here's what's happening with your studio today.</p>
        </div>
        <div className="flex gap-4">
          <button className="px-5 py-2.5 rounded-full bg-white/[0.03] border border-white/10 hover:bg-white/10 transition-all text-sm font-medium">Export Report</button>
          <button className="px-5 py-2.5 rounded-full bg-accent hover:bg-accent/90 text-white transition-all text-sm font-medium shadow-[0_0_15px_rgba(124,77,255,0.4)]">Publish Changes</button>
        </div>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatCard icon={<Layers />} label="Total Projects" value={stats.projects} trend="+2 this month" trendUp={true} />
        <StatCard icon={<Eye />} label="Total Views" value={stats.views.toLocaleString()} trend="+14% this week" trendUp={true} />
        <StatCard icon={<Users />} label="Unique Visitors" value="4,203" trend="-2% this week" trendUp={false} />
        <StatCard icon={<Activity />} label="Messages" value={stats.messages} trend="3 Unread" trendUp={true} special />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        
        {/* Left Column (Chart & Projects) */}
        <div className="xl:col-span-2 space-y-8">
          
          {/* Main Chart */}
          <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.2)]">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-xl font-medium tracking-wide">Performance Overview</h3>
                <p className="text-xs text-gray-500 uppercase tracking-widest mt-1">Last 7 Days</p>
              </div>
              <select className="bg-white/[0.05] border border-white/10 rounded-lg px-4 py-2 text-sm text-gray-300 focus:outline-none focus:border-accent">
                <option>This Week</option>
                <option>This Month</option>
                <option>This Year</option>
              </select>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#7C4DFF" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#7C4DFF" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorVisitors" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" stroke="#4B5563" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#4B5563" fontSize={12} tickLine={false} axisLine={false} />
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '12px', padding: '12px' }}
                    itemStyle={{ color: '#E5E7EB', fontSize: '14px' }}
                  />
                  <Area type="monotone" dataKey="views" stroke="#7C4DFF" strokeWidth={2} fillOpacity={1} fill="url(#colorViews)" />
                  <Area type="monotone" dataKey="visitors" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#colorVisitors)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recent Projects */}
          <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.2)]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-medium tracking-wide">Recent Projects</h3>
              <Link to="/admin/projects" className="text-sm text-accent hover:text-white transition-colors">View All &rarr;</Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-xs uppercase tracking-widest text-gray-500">
                    <th className="pb-4 font-medium">Project</th>
                    <th className="pb-4 font-medium">Category</th>
                    <th className="pb-4 font-medium">Date</th>
                    <th className="pb-4 font-medium">Status</th>
                    <th className="pb-4 font-medium"></th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {recentProjects.map((p, i) => (
                    <tr key={p.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
                      <td className="py-4 flex items-center gap-4">
                        <div className="w-12 h-12 rounded-lg bg-white/5 overflow-hidden border border-white/10">
                          {p.imageUrl ? 
                            <img src={p.imageUrl} alt={p.title} className="w-full h-full object-cover" /> : 
                            <div className="w-full h-full bg-accent/20 flex items-center justify-center text-accent"><Image size={16}/></div>
                          }
                        </div>
                        <span className="font-medium">{p.title}</span>
                      </td>
                      <td className="py-4 text-gray-400 capitalize">{p.categoryName}</td>
                      <td className="py-4 text-gray-400">{new Date(p.createdAt).toLocaleDateString()}</td>
                      <td className="py-4">
                        <span className="px-3 py-1 text-xs font-medium bg-green-500/10 text-green-400 rounded-full border border-green-500/20">Published</span>
                      </td>
                      <td className="py-4 text-right">
                        <button className="text-gray-500 hover:text-white transition-colors"><MoreHorizontal size={18} /></button>
                      </td>
                    </tr>
                  ))}
                  {recentProjects.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-gray-500">No projects yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column (Side Panels) */}
        <div className="xl:col-span-1 space-y-8">
          
          {/* Quick Draft */}
          <div className="bg-gradient-to-br from-[#1E1B4B]/80 to-[#0F172A]/80 border border-accent/20 rounded-[2rem] p-8 backdrop-blur-2xl shadow-[0_8px_32px_rgba(124,77,255,0.1)] relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-accent/20 rounded-full filter blur-[50px]"></div>
            <h3 className="text-xl font-medium tracking-wide mb-6 relative z-10 text-white">Quick Draft</h3>
            <textarea 
              placeholder="Jot down a quick project idea or notes..." 
              className="w-full h-32 bg-black/20 border border-white/10 rounded-xl p-4 text-sm text-gray-300 placeholder:text-gray-600 focus:outline-none focus:border-accent/50 resize-none mb-4 relative z-10"
            ></textarea>
            <button className="w-full py-3 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-sm font-medium transition-colors relative z-10">Save Draft</button>
          </div>

          {/* Activity Timeline */}
          <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.2)]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-medium tracking-wide">Recent Activity</h3>
            </div>
            
            <div className="space-y-6">
              <ActivityItem icon={<UploadCloud size={14} className="text-blue-400"/>} title="New image uploaded" time="2h ago" desc="portfolio-cover-v2.jpg" />
              <ActivityItem icon={<MessageSquare size={14} className="text-green-400"/>} title="New project inquiry" time="5h ago" desc="From Sarah Jenkins" />
              <ActivityItem icon={<MoreHorizontal size={14} className="text-accent"/>} title="Project updated" time="1d ago" desc="'Neon Echoes' details modified" />
              <ActivityItem icon={<Users size={14} className="text-orange-400"/>} title="New subscriber" time="2d ago" desc="hello@designco.com" />
            </div>
            
            <button className="w-full mt-6 py-2 border border-white/10 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-white/5 transition-colors">Load More</button>
          </div>

        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, trend, trendUp, special = false }: any) {
  return (
    <div className={`relative overflow-hidden group bg-white/[0.02] border ${special ? 'border-accent/30 bg-accent/[0.05]' : 'border-white/5'} rounded-[2rem] p-6 hover:bg-white/[0.05] hover:border-white/10 transition-all duration-500 shadow-[0_8px_32px_rgba(0,0,0,0.15)]`}>
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <div className="relative z-10">
        <div className="flex items-center gap-4 text-accent mb-6">
          <div className={`p-3 rounded-xl shadow-inner ${special ? 'bg-accent/20' : 'bg-white/5 border border-white/10 group-hover:scale-110 transition-transform duration-300'}`}>
            {icon}
          </div>
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-[0.2em]">{label}</span>
        </div>
        <div className="text-4xl lg:text-5xl font-display font-medium mb-3 tracking-tight">{value}</div>
        <div className={`flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-md inline-flex ${trendUp !== false ? 'text-green-400 bg-green-400/10' : 'text-red-400 bg-red-400/10'}`}>
          {trendUp !== false ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {trend}
        </div>
      </div>
    </div>
  );
}

function ActivityItem({ icon, title, desc, time }: any) {
  return (
    <div className="flex gap-4 relative">
      <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center shrink-0 z-10">
        {icon}
      </div>
      {/* Timeline line */}
      <div className="absolute left-4 top-8 bottom-[-24px] w-px bg-white/5 -z-0 last:hidden"></div>
      
      <div className="flex-1 pb-1">
        <div className="flex justify-between items-start mb-0.5">
          <h4 className="text-sm font-medium text-gray-200">{title}</h4>
          <span className="text-[10px] text-gray-500 uppercase tracking-widest">{time}</span>
        </div>
        <p className="text-xs text-gray-400">{desc}</p>
      </div>
    </div>
  );
}
