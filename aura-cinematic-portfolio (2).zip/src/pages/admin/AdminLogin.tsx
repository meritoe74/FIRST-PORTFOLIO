import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.token) localStorage.setItem('admin_token', data.token);
        navigate('/admin');
      } else {
        setError(data.error || 'Login failed');
      }
    } catch (err) {
      setError('Network error');
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col justify-center items-center px-4 relative overflow-hidden">
      <div className="absolute top-[-10%] right-[-5%] w-[50vw] h-[50vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-20 pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[60vw] h-[60vw] bg-accent rounded-full mix-blend-screen filter blur-[250px] opacity-10 pointer-events-none" />
      
      <div className="w-full max-w-md bg-white/[0.02] border border-white/5 rounded-3xl p-8 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] relative z-10">
        <h2 className="text-3xl font-display text-white mb-6 text-center tracking-tighter">STUDIO <span className="text-accent">HQ</span></h2>
        <form onSubmit={handleLogin} className="space-y-6">
          {error && <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>}
          <div>
            <label className="block text-xs uppercase tracking-widest text-gray-500 mb-2">Email Address</label>
            <input 
              type="email" 
              required 
              value={email} 
              onChange={e => setEmail(e.target.value)}
              className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:border-accent/50 focus:outline-none focus:bg-black/40 transition-colors"
            />
          </div>
          <button type="submit" className="w-full bg-accent hover:bg-accent/80 text-white font-medium py-3 rounded-xl transition-colors tracking-wide">
            Access Dashboard
          </button>
        </form>
        <p className="text-center mt-6 text-xs text-gray-500">
           Restricted access. Only authorized administrators can log in.
        </p>
      </div>
    </div>
  );
}
