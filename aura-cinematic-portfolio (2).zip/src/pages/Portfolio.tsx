import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, X, ExternalLink, Tag } from 'lucide-react';
import { GalleryRenderer } from '../components/Galleries';

export default function Portfolio() {
  const [services, setServices] = useState<any[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/services')
      .then(res => res.json())
      .then(data => {
        setServices(data || []);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const handleFilter = (slug: string) => {
    setActiveCategory(slug);
  };

  const filteredServices = activeCategory === 'all' 
    ? services 
    : services.filter(s => s.slug === activeCategory);

  return (
    <div className="min-h-screen bg-[#020617] px-6 md:px-24 pb-32 pt-24 relative overflow-hidden">
      {/* Background Visuals */}
      <div className="absolute top-[-10%] right-[-5%] w-[50vw] h-[50vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-20 pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[60vw] h-[60vw] bg-accent rounded-full mix-blend-screen filter blur-[250px] opacity-10 pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="pb-16 relative z-10"
      >
        <h1 className="text-5xl md:text-8xl font-display font-medium tracking-tighter mb-8 text-white drop-shadow-lg">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500">PORTFOLIO</span>
        </h1>
        
        {/* Filters */}
        <div className="flex flex-wrap gap-3 md:gap-4 mt-8 md:mt-12 border-b border-white/5 pb-8">
          <button 
            onClick={() => handleFilter('all')}
            className={`px-5 md:px-8 py-2 md:py-3 rounded-full border text-[10px] md:text-xs tracking-[0.2em] uppercase font-medium transition-all duration-300 ${activeCategory === 'all' ? 'border-accent bg-accent/20 text-white shadow-[0_0_20px_rgba(124,77,255,0.3)]' : 'border-white/10 bg-white/[0.02] text-gray-400 hover:border-white/30 hover:bg-white/[0.05]'}`}
          >
            All Works
          </button>
          {services.map(srv => (
            <button 
              key={srv.id}
              onClick={() => handleFilter(srv.slug)}
              className={`px-5 md:px-8 py-2 md:py-3 rounded-full border text-[10px] md:text-xs tracking-[0.2em] uppercase font-medium transition-all duration-300 ${activeCategory === srv.slug ? 'border-accent bg-accent/20 text-white shadow-[0_0_20px_rgba(124,77,255,0.3)]' : 'border-white/10 bg-white/[0.02] text-gray-400 hover:border-white/30 hover:bg-white/[0.05]'}`}
            >
              {srv.title}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Grid */}
      {loading ? (
        <div className="h-[50vh] flex items-center justify-center relative z-10">
          <div className="w-12 h-12 rounded-full border-4 border-white/10 border-t-accent animate-spin shadow-[0_0_15px_rgba(124,77,255,0.5)]" />
        </div>
      ) : (
        <div className="relative z-10 flex flex-col gap-32">
           {filteredServices.map((service, idx) => (
             <motion.div 
               key={service.id}
               initial={{ opacity: 0, y: 40 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true, margin: '-100px' }}
               transition={{ duration: 1 }}
               className="w-full"
             >
               <h2 className="text-3xl md:text-5xl font-poppins font-medium text-white mb-16 tracking-tight flex items-center gap-6">
                 {service.title}
                 <span className="h-px flex-1 bg-gradient-to-r from-accent/30 to-transparent" />
               </h2>
               <GalleryRenderer slug={service.slug} images={service.images} folders={service.folders} />
             </motion.div>
           ))}
        </div>
      )}
    </div>
  );
}
