import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export default function About() {
  const [portraitUrl, setPortraitUrl] = useState('https://i.ibb.co/1Ywy4fyB/Whats-App-Image-2026-05-27-at-7-10-36-AM.jpg');

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.portraitUrl) {
          setPortraitUrl(data.portraitUrl);
        }
      })
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="w-full">
      <section className="px-6 md:px-24 pt-24 pb-32 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-24 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h1 className="text-5xl md:text-7xl font-display font-medium tracking-tight">
              DESIGN WITH <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-blue-500">PURPOSE</span>
            </h1>
            <p className="text-xl text-gray-400 font-light leading-relaxed">
              I am Emmanuel Oyeyinka, a creative director and visual designer specializing in crafting premium digital experiences. I blend technical precision with cinematic aesthetics to create interfaces that don't just work—they make you feel something.
            </p>
            <div className="flex gap-4">
              <a href="mailto:meritoe74@gmail.com" className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-8 py-4 rounded-full font-medium tracking-[0.2em] uppercase text-sm transition-all duration-300 backdrop-blur-md shadow-[0_8px_32px_rgba(0,0,0,0.2)] hover:shadow-[0_8px_32px_rgba(255,255,255,0.1)]">
                Get in Touch
              </a>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-[3/4] rounded-3xl overflow-hidden grayscale hover:grayscale-0 transition-all duration-700 bg-primary-bg shadow-2xl p-2 border border-white/10 bg-white/[0.02] backdrop-blur-md">
              <img 
                src={portraitUrl} 
                alt="Portrait" 
                className="w-full h-full object-cover rounded-2xl"
              />
            </div>
            
            {/* Experience Badge */}
            <div className="absolute -bottom-6 -left-6 bg-accent/90 border border-white/20 text-white p-8 rounded-3xl backdrop-blur-xl shadow-[0_8px_32px_rgba(124,77,255,0.4)]">
              <div className="text-4xl font-display font-medium mb-1">10+</div>
              <div className="text-xs tracking-[0.2em] uppercase opacity-90 font-medium">Years EXP.</div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="px-6 md:px-24 py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-secondary-bg/30 border-y border-white/5 backdrop-blur-3xl -z-10" />
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-display mb-16 tracking-tight">TOOLKIT</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {['Figma', 'React', 'Framer Motion', 'Tailwind', 'Next.js', 'GSAP', 'After Effects', 'Photoshop'].map((tool, i) => (
              <motion.div 
                key={tool}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-8 border border-white/5 rounded-2xl text-center bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/20 transition-all duration-500 cursor-default backdrop-blur-xl shadow-lg"
              >
                <div className="text-lg font-medium tracking-wide text-gray-300 hover:text-white transition-colors">{tool}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
