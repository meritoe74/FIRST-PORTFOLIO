import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { MapPin, Mail, Instagram, Phone, MessageCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState('Lad/Lak, Bariga');

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.location) {
          setLocation(data.location);
        }
      })
      .catch(console.error);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Add artificial delay for smoother UI feedback
    const toastId = toast.loading('Sending message...');
    
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      
      if (res.ok) {
        toast.success('Message sent successfully!', { id: toastId });
        setForm({ name: '', email: '', subject: '', message: '' });
      } else {
        toast.error('Failed to send message. Please try again.', { id: toastId });
      }
    } catch (err) {
      toast.error('Network error. Failed to send.', { id: toastId });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full min-h-screen px-6 md:px-24 pt-24 pb-32">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-24">
        
        {/* Contact Info */}
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-16"
        >
          <div>
            <h1 className="text-5xl md:text-8xl font-display font-medium tracking-tight mb-8">
              LET'S <br/><span className="text-gray-500">TALK</span>
            </h1>
            <p className="text-xl text-gray-400 font-light max-w-md">
              Have a project in mind or want to explore an idea? Reach out and let's craft something remarkable together.
            </p>
          </div>
          
          <div className="space-y-6">
            <a href="mailto:meritoe74@gmail.com" className="flex items-center gap-6 text-xl group cursor-pointer">
              <div className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white/[0.02] border border-white/10 text-accent group-hover:-translate-y-1 group-hover:bg-accent group-hover:border-accent group-hover:text-white transition-all duration-300 backdrop-blur-md shadow-inner group-hover:shadow-[0_0_20px_rgba(124,77,255,0.4)]">
                <Mail size={22} />
              </div>
              <span className="group-hover:text-white text-gray-300 transition-colors">meritoe74@gmail.com</span>
            </a>
            
            <a href="tel:08111777805" className="flex items-center gap-6 text-xl group cursor-pointer">
              <div className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white/[0.02] border border-white/10 text-accent group-hover:-translate-y-1 group-hover:bg-accent group-hover:border-accent group-hover:text-white transition-all duration-300 backdrop-blur-md shadow-inner group-hover:shadow-[0_0_20px_rgba(124,77,255,0.4)]">
                <Phone size={22} />
              </div>
              <span className="group-hover:text-white text-gray-300 transition-colors">0811 177 7805</span>
            </a>
            
            <a href="https://wa.me/2348111777805" target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 text-xl group cursor-pointer">
              <div className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white/[0.02] border border-white/10 text-[#25D366] group-hover:-translate-y-1 group-hover:bg-[#25D366] group-hover:border-[#25D366] group-hover:text-white transition-all duration-300 backdrop-blur-md shadow-inner group-hover:shadow-[0_0_20px_rgba(37,211,102,0.4)]">
                <MessageCircle size={22} />
              </div>
              <span className="group-hover:text-white text-gray-300 transition-colors">WhatsApp Chat</span>
            </a>
            
            <a href="https://www.instagram.com/merit_wedding_and_events_ltd" target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 text-base sm:text-lg md:text-xl group cursor-pointer w-full">
              <div className="w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center shrink-0 rounded-2xl bg-white/[0.02] border border-white/10 text-accent group-hover:-translate-y-1 group-hover:bg-accent group-hover:border-accent group-hover:text-white transition-all duration-300 backdrop-blur-md shadow-inner group-hover:shadow-[0_0_20px_rgba(124,77,255,0.4)]">
                <Instagram size={22} className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <span className="group-hover:text-white text-gray-300 transition-colors break-words text-left flex-1 min-w-0 font-medium">@merit_wedding_and_events_ltd</span>
            </a>
            
            <a href={`https://maps.google.com/?q=${encodeURIComponent(location)}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 text-xl group cursor-pointer">
              <div className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white/[0.02] border border-white/10 text-accent group-hover:-translate-y-1 group-hover:bg-accent group-hover:border-accent group-hover:text-white transition-all duration-300 backdrop-blur-md shadow-inner group-hover:shadow-[0_0_20px_rgba(124,77,255,0.4)]">
                <MapPin size={22} />
              </div>
              <span className="group-hover:text-white text-gray-300 transition-colors">{location}</span>
            </a>
          </div>
        </motion.div>

        {/* Form */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/[0.02] border border-white/5 p-12 rounded-[2.5rem] backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.2)] relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent pointer-events-none" />
          
          <form onSubmit={handleSubmit} className="space-y-10 relative z-10">
            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Your Name</label>
              <input 
                required
                type="text" 
                value={form.name}
                onChange={e => setForm({...form, name: e.target.value})}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Email Address</label>
              <input 
                required
                type="email" 
                value={form.email}
                onChange={e => setForm({...form, email: e.target.value})}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                placeholder="john@company.com"
              />
            </div>
            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Subject</label>
              <input 
                required
                type="text" 
                value={form.subject}
                onChange={e => setForm({...form, subject: e.target.value})}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                placeholder="Project Inquiry"
              />
            </div>
            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Project Details</label>
              <textarea 
                required
                rows={4}
                value={form.message}
                onChange={e => setForm({...form, message: e.target.value})}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors resize-none placeholder:text-gray-700"
                placeholder="Tell me about your timeline and budget..."
              />
            </div>
            
            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-white/10 hover:bg-white/20 border border-white/20 text-white py-5 rounded-2xl font-medium tracking-[0.2em] uppercase text-sm transition-all duration-300 backdrop-blur-md shadow-lg hover:shadow-[0_8px_32px_rgba(255,255,255,0.1)] disabled:opacity-50"
            >
              {loading ? 'Sending...' : 'Send Message'}
            </button>
          </form>
        </motion.div>

      </div>
    </div>
  );
}
