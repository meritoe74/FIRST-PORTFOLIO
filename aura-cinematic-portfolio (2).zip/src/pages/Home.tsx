import React, { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ArrowRight, Download, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [cvUrl, setCvUrl] = useState('');
  const [location, setLocation] = useState('Lad/Lak, Bariga');
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.cvUrl) {
          setCvUrl(data.cvUrl);
        }
        if (data.location) {
          setLocation(data.location);
        }
      })
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="w-full bg-[#020617]" ref={containerRef}>
      {/* Hero Section */}
      <section className="relative min-h-[95vh] flex flex-col justify-center pt-24 lg:pt-32 pb-16 lg:pb-32 px-6 md:px-24 overflow-hidden">
        {/* Cinematic Deep Blue Background Visual */}
        <div className="absolute inset-0 bg-[#020617] z-0" />
        <motion.div 
          className="absolute inset-0 z-0 opacity-60 pointer-events-none"
          style={{ y, opacity }}
        >
          <div className="absolute top-[10%] right-[5%] w-[60vw] h-[60vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[250px] opacity-30 animate-[pulse_10s_ease-in-out_infinite]" />
          <div className="absolute bottom-[-20%] left-[5%] w-[50vw] h-[50vw] bg-accent rounded-full mix-blend-screen filter blur-[220px] opacity-20 animate-[pulse_12s_ease-in-out_infinite_reverse]" />
        </motion.div>

        {/* Premium Floating Bubbles */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {[
            { size: 180, left: '10%', top: '15%', delay: 0, duration: 18, color: 'rgba(124,77,255,0.03)' },
            { size: 320, left: '75%', top: '10%', delay: 2, duration: 25, color: 'rgba(30,58,138,0.04)' },
            { size: 120, left: '45%', top: '60%', delay: 5, duration: 15, color: 'rgba(124,77,255,0.05)' },
            { size: 260, left: '80%', top: '65%', delay: 1, duration: 22, color: 'rgba(30,58,138,0.03)' },
            { size: 220, left: '5%', top: '70%', delay: 4, duration: 20, color: 'rgba(124,77,255,0.02)' },
            { size: 90, left: '55%', top: '25%', delay: 3, duration: 16, color: 'rgba(255,255,255,0.02)' },
          ].map((bubble, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full border border-white/10 backdrop-blur-[12px] shadow-[inset_0_0_30px_rgba(255,255,255,0.05),0_8px_32px_rgba(0,0,0,0.3)]"
              style={{
                width: bubble.size,
                height: bubble.size,
                left: bubble.left,
                top: bubble.top,
                background: `linear-gradient(135deg, ${bubble.color}, transparent)`,
                boxShadow: `0 0 40px ${bubble.color}, inset 0 0 20px rgba(255,255,255,0.05)`
              }}
              animate={{
                y: [0, -40, 0, 40, 0],
                x: [0, 30, 0, -30, 0],
                rotate: [0, 90, 180, 270, 360],
              }}
              transition={{
                duration: bubble.duration,
                repeat: Infinity,
                ease: "linear",
                delay: bubble.delay,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-7xl mx-auto flex flex-col gap-16 md:gap-20">
          <div className="flex flex-row md:grid md:grid-cols-12 gap-5 sm:gap-8 md:gap-16 items-start md:items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="w-[45%] md:w-full md:col-span-5 flex flex-col items-center justify-center gap-3 md:gap-6 self-stretch"
            >
              <div className="w-full relative aspect-[3/5] md:aspect-[4/5] rounded-3xl md:rounded-[3rem] overflow-hidden border border-white/10 bg-white/[0.02] backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.3)] group flex-1 sticky top-24 md:static max-h-[300px] sm:max-h-[400px] md:max-h-none">
                <div className="absolute inset-0 bg-gradient-to-t from-[#07111F] md:via-transparent to-transparent opacity-90 md:opacity-80 z-10 pointer-events-none" />
                <img 
                  src="https://i.ibb.co/1Ywy4fyB/Whats-App-Image-2026-05-27-at-7-10-36-AM.jpg" 
                  alt="Emmanuel Oyeyinka Portrait" 
                  className="w-full h-full object-cover object-top transform group-hover:scale-105 transition-transform duration-1000 ease-[0.25,1,0.5,1] grayscale-[30%] group-hover:grayscale-0"
                />
              </div>
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
                className="text-center w-full"
              >
                <h2 className="text-[11px] sm:text-sm md:text-3xl font-poppins font-medium text-white tracking-widest shadow-accent drop-shadow-[0_0_15px_rgba(124,77,255,0.4)] relative z-20">
                  Emmanuel
                  <br className="md:hidden" />
                  <span className="md:inline"> Oyeyinka</span>
                </h2>
                <div className="w-6 md:w-12 h-px bg-accent/60 mx-auto mt-1 md:mt-4 shadow-[0_0_12px_rgba(124,77,255,0.8)]"></div>
              </motion.div>
            </motion.div>
            
            <div className="w-[55%] md:w-full md:col-span-7 flex flex-col relative z-20">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
              >
                <h1 className="text-[1.35rem] sm:text-3xl md:text-5xl lg:text-6xl xl:text-[4.5rem] font-poppins font-bold leading-[1.15] md:leading-[1.1] tracking-tight mb-3 md:mb-8 text-white drop-shadow-2xl">
                  Social Media Creativity &<br className="hidden md:block" />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 to-gray-500">Digital Branding.</span>
                </h1>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
              >
                <p className="text-[10px] sm:text-sm md:text-lg lg:text-xl text-gray-300 font-light leading-[1.6] md:leading-relaxed drop-shadow-lg mb-5 md:mb-12 max-w-2xl">
                  I craft visuals that stop the scroll and spark engagement. Every design, caption, and campaign is created with strategy, creativity, and audience connection in mind. My journey in the creative space is driven by a passion for visual storytelling, content creation, and digital branding. From social media designs to photography, cinematography, and content strategy, I transform ideas into impactful digital experiences that build attention, engagement, and lasting brand identity.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, filter: 'blur(10px)' }}
                animate={{ opacity: 1, filter: 'blur(0px)' }}
                transition={{ duration: 1.2, delay: 0.8 }}
                className="flex flex-col w-full sm:w-auto sm:flex-row items-center gap-4 md:gap-6 mt-2 md:mt-4"
              >
                {cvUrl ? (
                  <a 
                    href={cvUrl} 
                    download 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="group relative flex items-center justify-between sm:justify-start gap-4 md:gap-6 bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-accent/50 px-5 md:px-8 py-3 md:py-5 rounded-xl md:rounded-2xl backdrop-blur-2xl transition-all duration-500 shadow-[0_8px_32px_rgba(0,0,0,0.2)] hover:shadow-[0_0_40px_rgba(124,77,255,0.3)] w-full sm:w-max active:scale-[0.98] overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-accent/0 via-accent/10 to-accent/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out pointer-events-none" />
                    <span className="text-[10px] md:text-sm font-poppins font-medium text-white uppercase tracking-[0.15em] relative z-10 w-full text-center sm:text-left truncate">Download CV</span>
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-accent/20 text-accent flex items-center justify-center group-hover:bg-accent group-hover:text-white transition-all duration-500 shadow-[inset_0_0_10px_rgba(124,77,255,0.2)] group-hover:shadow-[0_0_20px_rgba(124,77,255,0.6)] shrink-0 relative z-10 group-hover:-translate-y-1">
                      <Download size={16} />
                    </div>
                  </a>
                ) : (
                  <div className="group relative flex items-center justify-between sm:justify-start gap-4 md:gap-6 bg-white/[0.02] border border-white/5 px-5 md:px-8 py-3 md:py-5 rounded-xl md:rounded-2xl backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.2)] w-full sm:w-max opacity-50">
                    <span className="text-[10px] md:text-sm font-poppins font-medium text-gray-400 uppercase tracking-[0.15em] w-full text-center sm:text-left truncate">Resume / CV</span>
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white/5 text-gray-500 flex items-center justify-center shrink-0">
                      <Download size={16} />
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center gap-10 lg:gap-12 w-full pt-16 mt-8 border-t border-white/5 relative z-20">
            <motion.div
              variants={{
                hidden: { opacity: 0 },
                show: { opacity: 1, transition: { staggerChildren: 0.08, delayChildren: 0.4 } }
              }}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              className="flex flex-wrap gap-4 justify-center max-w-5xl mx-auto"
            >
              {[
                'Creative Director', 'Graphic Designer', 'Photographer', 
                'Cinematographer', 'Social Media Manager', 'Visual Storyteller', 
                'Content Creator', 'Scriptwriter', 'Brand Creative'
              ].map((role) => (
                <motion.div
                  key={role}
                  variants={{
                    hidden: { opacity: 0, scale: 0.9, y: 15 },
                    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring", stiffness: 80, damping: 15 } }
                  }}
                  whileHover={{ scale: 1.05, backgroundColor: 'rgba(124,77,255,0.15)', borderColor: 'rgba(124,77,255,0.4)', boxShadow: '0 8px 24px rgba(124,77,255,0.2)' }}
                  className="px-6 py-3.5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-2xl text-[11px] sm:text-xs font-medium tracking-[0.15em] uppercase text-gray-300 cursor-default transition-all duration-300 shadow-[0_4px_24px_rgba(0,0,0,0.1)] hover:-translate-y-1"
                >
                  {role}
                </motion.div>
              ))}
            </motion.div>

            {/* Creative Toolkit */}
            <div className="w-full mt-6 mb-4">
              <h3 className="text-center text-[10px] md:text-xs font-poppins font-medium text-gray-500 uppercase tracking-[0.3em] mb-8">Creative Toolkit</h3>
              <motion.div
                variants={{
                  hidden: { opacity: 0 },
                  show: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.6 } }
                }}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true }}
                className="flex flex-wrap gap-5 md:gap-8 justify-center max-w-4xl mx-auto px-4"
              >
                {[
                  { name: 'Adobe Illustrator', img: 'https://cdn.worldvectorlogo.com/logos/adobe-illustrator-cc-3.svg' },
                  { name: 'CorelDRAW', img: 'https://cdn.worldvectorlogo.com/logos/coreldraw-2.svg' },
                  { name: 'Canva', img: 'https://cdn.worldvectorlogo.com/logos/canva-1.svg' },
                  { name: 'Adobe Photoshop', img: 'https://cdn.worldvectorlogo.com/logos/adobe-photoshop-2.svg' },
                  { name: 'Adobe Premiere Pro', img: 'https://cdn.worldvectorlogo.com/logos/premiere-pro-cc.svg' },
                ].map((tool) => (
                  <motion.div
                    key={tool.name}
                    variants={{
                      hidden: { opacity: 0, scale: 0.8, y: 20 },
                      show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring", stiffness: 100, damping: 15 } }
                    }}
                    whileHover={{ scale: 1.1, translateY: -5 }}
                    className="group relative flex items-center justify-center w-16 h-16 md:w-20 md:h-20 rounded-2xl md:rounded-[1.5rem] bg-white/[0.02] border border-white/10 backdrop-blur-3xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] hover:bg-white/[0.05] hover:border-accent/50 hover:shadow-[0_0_30px_rgba(124,77,255,0.3)] transition-all duration-500 cursor-pointer"
                  >
                    <div className="absolute inset-0 bg-gradient-to-tr from-accent/20 to-transparent opacity-0 group-hover:opacity-100 rounded-2xl md:rounded-[1.5rem] transition-opacity duration-500" />
                    <img src={tool.img} alt={tool.name} className="w-8 h-8 md:w-10 md:h-10 object-contain drop-shadow-lg filter group-hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.5)] transition-all duration-300 transform group-hover:scale-110 z-10" />
                    <div className="absolute -bottom-8 opacity-0 group-hover:opacity-100 transition-all duration-300 text-[9px] md:text-[10px] text-gray-300 font-medium tracking-[0.1em] uppercase whitespace-nowrap bg-[#020617] px-3 py-1.5 border border-white/10 shadow-[0_4px_12px_rgba(0,0,0,0.5)] rounded-full z-20 transform translate-y-2 group-hover:translate-y-0">
                      {tool.name}
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, filter: 'blur(10px)', y: 20 }}
              whileInView={{ opacity: 1, filter: 'blur(0px)', y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-6 mt-4"
            >
              <div className="inline-flex items-center justify-center sm:justify-start gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-8 py-4 rounded-[1.5rem] shadow-[0_8px_32px_rgba(0,0,0,0.2)] w-full sm:w-auto">
                <div className="relative flex items-center justify-center w-8 h-8 shrink-0">
                  <div className="absolute inset-0 bg-accent rounded-full opacity-20 animate-ping" />
                  <div className="relative w-3 h-3 rounded-full bg-accent shadow-[0_0_12px_rgba(124,77,255,0.8)]" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-gray-400 font-medium whitespace-nowrap">NSQ Certified Creative</span>
                  <span className="text-sm font-medium text-white tracking-wide whitespace-nowrap">Professional Credentials</span>
                </div>
              </div>

              <a href={`https://maps.google.com/?q=${encodeURIComponent(location)}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center sm:justify-start gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-8 py-4 rounded-[1.5rem] shadow-[0_8px_32px_rgba(0,0,0,0.2)] group hover:bg-white/[0.04] hover:border-accent/30 transition-all duration-300 w-full sm:w-auto">
                <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 group-hover:text-accent group-hover:scale-110 transition-all shrink-0">
                  <MapPin size={16} />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-gray-400 font-medium whitespace-nowrap">Based In</span>
                  <span className="text-sm font-medium text-white tracking-wide whitespace-nowrap group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-300 transition-colors">{location}</span>
                </div>
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Works Preview */}
      <section className="py-24 md:py-32 overflow-hidden bg-[#020617] relative">
        <div className="px-6 md:px-24 flex flex-col md:flex-row justify-between md:items-end mb-16 md:mb-24 gap-6 relative z-20">
          <h2 className="text-4xl md:text-6xl font-display font-medium tracking-tight text-white drop-shadow-md">
            SELECTED <span className="text-gray-500">WORKS</span>
          </h2>
          <Link to="/portfolio" className="inline-flex gap-2 items-center text-accent hover:text-white transition-colors uppercase tracking-[0.15em] text-xs sm:text-sm font-medium">
            View All <ArrowRight size={20} />
          </Link>
        </div>

        <div className="relative w-full overflow-hidden flex items-center h-[350px] md:h-[500px]">
          {/* Fading Edges */}
          <div className="absolute left-0 top-0 bottom-0 w-16 md:w-64 bg-gradient-to-r from-[#020617] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-16 md:w-64 bg-gradient-to-l from-[#020617] to-transparent z-10 pointer-events-none" />

          {/* Marquee Container */}
          <motion.div
            className="flex gap-4 md:gap-10 w-max pr-4 md:pr-10"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ repeat: Infinity, ease: "linear", duration: 45 }}
          >
            {[
              { id: 1, title: 'Cinematography Reel', category: 'Cinematography', img: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=2000&auto=format&fit=crop' },
              { id: 2, title: 'Cosmic Brand Identity', category: 'Logo Design', img: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop' },
              { id: 3, title: 'Elevate Visuals', category: 'Graphic Design', img: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=2000&auto=format&fit=crop' },
              { id: 4, title: 'Urban Portraits', category: 'Photography', img: 'https://images.unsplash.com/photo-1554046920-90dc206963e8?q=80&w=2000&auto=format&fit=crop' },
              { id: 5, title: 'Dynamic Cuts', category: 'Video Editing', img: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=2000&auto=format&fit=crop' },
              { id: 6, title: 'Viral Campaigns', category: 'Social Media Designs', img: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=2000&auto=format&fit=crop' },
              { id: 7, title: 'Nexus Rebrand', category: 'Branding Projects', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=2000&auto=format&fit=crop' },
              { id: 8, title: 'Oasis UI Concept', category: 'Website Projects', img: 'https://images.unsplash.com/photo-1541462608143-67571c6738dd?q=80&w=2000&auto=format&fit=crop' },
              // Duplicate to loop seamlessly
              { id: '1-dup', title: 'Cinematography Reel', category: 'Cinematography', img: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=2000&auto=format&fit=crop' },
              { id: '2-dup', title: 'Cosmic Brand Identity', category: 'Logo Design', img: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop' },
              { id: '3-dup', title: 'Elevate Visuals', category: 'Graphic Design', img: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=2000&auto=format&fit=crop' },
              { id: '4-dup', title: 'Urban Portraits', category: 'Photography', img: 'https://images.unsplash.com/photo-1554046920-90dc206963e8?q=80&w=2000&auto=format&fit=crop' },
              { id: '5-dup', title: 'Dynamic Cuts', category: 'Video Editing', img: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=2000&auto=format&fit=crop' },
              { id: '6-dup', title: 'Viral Campaigns', category: 'Social Media Designs', img: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=2000&auto=format&fit=crop' },
              { id: '7-dup', title: 'Nexus Rebrand', category: 'Branding Projects', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=2000&auto=format&fit=crop' },
              { id: '8-dup', title: 'Oasis UI Concept', category: 'Website Projects', img: 'https://images.unsplash.com/photo-1541462608143-67571c6738dd?q=80&w=2000&auto=format&fit=crop' },
            ].map((item, i) => (
              <div 
                key={`${item.id}-${i}`}
                className="group relative cursor-pointer flex flex-col overflow-hidden w-[260px] md:w-[450px] aspect-[4/5] md:aspect-[4/3] bg-white/[0.02] border border-white/5 rounded-2xl md:rounded-[2rem] hover:border-white/10 transition-all duration-700 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] flex-shrink-0 hover:shadow-[0_8px_40px_rgba(124,77,255,0.2)]"
              >
                <div className="absolute inset-0 bg-primary-bg shadow-inner z-0">
                  <img 
                    src={item.img} 
                    alt={item.title} 
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000 ease-[0.25,1,0.5,1] opacity-70 group-hover:opacity-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/40 to-transparent opacity-90 group-hover:opacity-70 transition-opacity duration-500" />
                </div>
                
                <div className="relative z-10 flex flex-col justify-end h-full p-5 md:p-8">
                  <div className="transform md:translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                    <p className="text-accent tracking-[0.2em] uppercase text-[9px] md:text-xs font-medium mb-1 md:mb-2 md:opacity-0 group-hover:opacity-100 transition-opacity duration-500 md:delay-100">{item.category}</p>
                    <h3 className="text-xl md:text-3xl font-display tracking-tight text-gray-200 group-hover:text-white transition-colors">{item.title}</h3>
                  </div>
                  
                  <div className="absolute top-4 right-4 md:top-8 md:right-8 opacity-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:rotate-0 rotate-45 bg-accent/20 p-2 md:p-3 rounded-full border border-accent/20 text-accent backdrop-blur-md">
                    <ArrowRight size={16} className="md:w-5 md:h-5" />
                  </div>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Services Snippet */}
      <section className="py-24 md:py-32 px-0 bg-[#020617] border-y border-white/5 relative overflow-hidden">
        {/* Subtle Background Glows */}
        <div className="absolute top-0 right-0 w-[40vw] h-[40vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-20 animate-[pulse_10s_ease-in-out_infinite]" />
        
        <div className="px-6 md:px-24 mb-16 relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div>
            <div className="inline-flex items-center gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-5 py-2 rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.1)] mb-6">
              <span className="text-[10px] tracking-[0.2em] uppercase text-accent font-medium whitespace-nowrap">NSQ Certified</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-poppins font-bold tracking-tight text-white mb-4">
              Creative <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 to-gray-500">Expertise.</span>
            </h2>
            <p className="text-gray-400 font-light max-w-xl text-sm md:text-base">Elevating brands and digital experiences through strategic content, visual storytelling, and premium design.</p>
          </div>
          <Link to="/services" className="px-6 md:px-0 inline-flex items-center gap-3 group text-xs sm:text-sm font-medium tracking-[0.1em] uppercase text-white hover:text-accent transition-colors pb-2 border-b border-white/20 hover:border-accent w-max">
            View All Services <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="relative w-full overflow-hidden flex items-center pb-12">
          {/* Fading Edges */}
          <div className="absolute left-0 top-0 bottom-0 w-16 md:w-48 bg-gradient-to-r from-[#020617] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-16 md:w-48 bg-gradient-to-l from-[#020617] to-transparent z-10 pointer-events-none" />

          {/* Marquee Container */}
          <motion.div
            className="flex gap-4 md:gap-8 w-max pr-4 md:pr-8"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ repeat: Infinity, ease: "linear", duration: 30 }}
          >
            {[
              { title: 'Social Media Management', desc: 'Strategic content and engaged digital presence.', num: '01' },
              { title: 'Cinematography & Video', desc: 'Premium narratives and compelling edits.', num: '02' },
              { title: 'Website Development', desc: 'Responsive portfolios and premium UI/UX.', num: '03' },
              { title: 'Graphic Design', desc: 'Branding and visually striking campaigns.', num: '04' },
              // Duplicate to loop seamlessly
              { title: 'Social Media Management', desc: 'Strategic content and engaged digital presence.', num: '01' },
              { title: 'Cinematography & Video', desc: 'Premium narratives and compelling edits.', num: '02' },
              { title: 'Website Development', desc: 'Responsive portfolios and premium UI/UX.', num: '03' },
              { title: 'Graphic Design', desc: 'Branding and visually striking campaigns.', num: '04' }
            ].map((service, index) => (
              <div 
                key={`${service.title}-${index}`}
                className="w-[280px] md:w-[400px] p-6 md:p-10 border border-white/5 rounded-2xl md:rounded-[2rem] bg-white/[0.02] backdrop-blur-2xl hover:bg-white/[0.04] hover:border-accent/30 transition-all duration-500 shadow-[0_8px_32px_rgba(0,0,0,0.2)] group relative overflow-hidden flex-shrink-0"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative z-10">
                  <div className="text-3xl md:text-4xl text-white/5 font-poppins font-bold mb-4 md:mb-6 group-hover:text-accent/30 transition-colors duration-500">{service.num}</div>
                  <h3 className="text-lg md:text-2xl font-poppins font-semibold mb-2 md:mb-4 text-white group-hover:-translate-y-1 transition-transform duration-300">{service.title}</h3>
                  <p className="text-gray-400 text-xs md:text-sm leading-relaxed font-light group-hover:text-gray-300 transition-colors duration-300">
                    {service.desc}
                  </p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>
    </div>
  );
}
