import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';
import { Project } from '../types';

export default function ProjectDetail() {
  const { slug } = useParams();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/projects/${slug}`)
      .then(res => res.json())
      .then(data => {
        setProject(data);
        setLoading(false);
      });
  }, [slug]);

  if (loading) return <div className="min-h-screen pt-32 px-6 flex justify-center text-white/50">Loading...</div>;
  if (!project) return <div className="min-h-screen pt-32 px-6 text-center text-white">Project not found</div>;

  return (
    <div className="min-h-screen pb-32">
      <div className="px-6 md:px-24 pt-12 pb-16">
        <Link to="/portfolio" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-white transition-colors mb-16 uppercase tracking-wider">
          <ArrowLeft size={16} /> Back to Archive
        </Link>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-8xl font-display font-medium tracking-tighter mb-12"
        >
          {project.title}
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-12 border-t border-white/10 pt-12"
        >
          <div className="md:col-span-1 space-y-8">
            <div>
              <h4 className="text-xs uppercase tracking-widest text-gray-500 mb-2">Category</h4>
              <p className="font-medium text-lg">{project.categoryName}</p>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-widest text-gray-500 mb-2">Tools</h4>
              <p className="font-medium text-lg">{project.tools || 'Creative Suite'}</p>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-widest text-gray-500 mb-2">Year</h4>
              <p className="font-medium text-lg">{new Date(project.createdAt).getFullYear()}</p>
            </div>
          </div>
          <div className="md:col-span-3">
            <h4 className="text-xs uppercase tracking-widest text-gray-500 mb-6">Overview</h4>
            <p className="text-xl md:text-3xl text-gray-300 font-light leading-relaxed">
              {project.description}
            </p>
          </div>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4, duration: 0.8 }}
        className="w-full h-[60vh] md:h-[80vh] bg-secondary-bg overflow-hidden my-12"
      >
        <img 
          src={project.imageUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564'} 
          alt={project.title} 
          className="w-full h-full object-cover"
        />
      </motion.div>
    </div>
  );
}
