import React from 'react';
import { Share2, Film, PenTool, Video, Camera, Monitor, Hexagon } from 'lucide-react';

export const servicesData = [
  { 
    id: 1, 
    slug: 'social-media-management',
    title: 'Social Media Management', 
    icon: <Share2 size={32} />, 
    desc: 'Strategic content creation, community engagement, and visual storytelling tailored to elevate your brand presence and drive audience growth.',
    longDesc: 'Our social media management service goes beyond simply posting content. We develop comprehensive strategies based on deep audience insights, competitor analysis, and platform-specific trends. From crafting engaging visual narratives to managing community interactions and running targeted campaigns, we ensure your brand maintains a dynamic, responsive, and influential presence across all digital channels.',
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=2000&auto=format&fit=crop'
    ]
  },
  { 
    id: 2, 
    slug: 'cinematography',
    title: 'Cinematography', 
    icon: <Film size={32} />, 
    desc: 'Premium visual narratives captured with cinematic precision. From conceptualization to final grade, telling stories that leave a lasting impact.',
    longDesc: 'We treat every project as a cinematic piece capable of moving audiences and shaping perceptions. Utilizing high-end camera equipment, sophisticated lighting techniques, and an acute understanding of visual storytelling, our cinematography service delivers breathtaking footage. Whether it is a commercial, a brand documentary, or a creative short, we focus on composition, movement, and narrative flow to produce visually stunning results.',
    images: [
      'https://images.unsplash.com/photo-1579722359409-cf8fe17f9ba5?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1590605929668-cb0aa5f2f5fc?q=80&w=2000&auto=format&fit=crop'
    ]
  },
  { 
    id: 3, 
    slug: 'graphic-design',
    title: 'Graphic Design', 
    icon: <PenTool size={32} />, 
    desc: 'Purpose-driven visual design that communicates brand identity with clarity, modern aesthetics, and professional typographic hierarchy.',
    longDesc: 'Our graphic design philosophy centers around clarity, emotion, and purpose. We craft bespoke visual identities, marketing collateral, and digital assets that resonate with your target audience. By mastering typography, color theory, and layout composition, we ensure every design piece is not only visually arresting but strategically aligned with your brand\'s core message and values.',
    images: [
      'https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2000&auto=format&fit=crop'
    ],
    folders: [
      {
        name: 'Batch 1',
        images: [
          'https://i.ibb.co/GQ5SzWcD/FB-IMG-1779882463527.jpg',
          'https://i.ibb.co/35dBD6Hd/FB-IMG-1779882468425.jpg',
          'https://i.ibb.co/JS9bzMc/FB-IMG-1779882470666.jpg',
          'https://i.ibb.co/LDR5R68V/FB-IMG-1779882473374.jpg',
          'https://i.ibb.co/wFbNpdd2/FB-IMG-1779882476516.jpg',
          'https://i.ibb.co/xqKv7KqV/FB-IMG-1779882478848.jpg',
          'https://i.ibb.co/tTWS4gWL/FB-IMG-1779891242957.jpg',
          'https://i.ibb.co/RTZnW4bg/FB-IMG-1779891240314.jpg',
          'https://i.ibb.co/fdyB5CMk/FB-IMG-1779891238152.jpg',
          'https://i.ibb.co/Kphd7dj1/FB-IMG-1779891235360.jpg',
          'https://i.ibb.co/99jDPHFR/FB-IMG-1779891232851.jpg'
        ]
      }
    ]
  },
  { 
    id: 4, 
    slug: 'video-editing',
    title: 'Video Editing', 
    icon: <Video size={32} />, 
    desc: 'Dynamic pacing, immersive sound design, and seamless transitions to transform raw footage into compelling, high-retention visual stories.',
    longDesc: 'Video editing is where the story truly comes to life. We specialize in dynamic pacing, intricate sound design, seamless visual effects, and professional color grading. Our approach transforms raw footage into compelling, high-retention stories optimized for any platform, ensuring your message is delivered with maximum impact and engagement.',
    images: [
      'https://images.unsplash.com/photo-1574717024653-61fd2cf6d44d?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1592652431766-3d23ebed0ee4?q=80&w=2000&auto=format&fit=crop'
    ]
  },
  { 
    id: 5, 
    slug: 'photography',
    title: 'Photography', 
    icon: <Camera size={32} />, 
    desc: 'Capturing moments, products, and brand stories with a keen eye for lighting, composition, and emotional resonance.',
    longDesc: 'From high-end product shoots to lifestyle branding and corporate portraits, our photography service captures the essence of your subject. We meticulously control lighting, environment, and composition to deliver crisp, beautiful, and emotionally resonant images that strengthen your brand\'s visual catalog.',
    images: [
      'https://i.ibb.co/DDvps3Bp/FB-IMG-1779879723140.jpg',
      'https://i.ibb.co/jPvnKWHY/FB-IMG-1779880138765.jpg',
      'https://i.ibb.co/ksKRtnbV/FB-IMG-1779880136217.jpg',
      'https://i.ibb.co/60bn5dpF/FB-IMG-1779880133971.jpg',
      'https://i.ibb.co/vCxK3Fjw/FB-IMG-1779879760679.jpg',
      'https://i.ibb.co/zckxz43/FB-IMG-1779879758086.jpg',
      'https://i.ibb.co/NdJnFQ2r/FB-IMG-1779879757728.jpg',
      'https://i.ibb.co/5x2v25Vr/FB-IMG-1779879747603.jpg',
      'https://i.ibb.co/F47vBz7B/FB-IMG-1779879744646.jpg',
      'https://i.ibb.co/mVsQtS9M/FB-IMG-1779879741465.jpg',
      'https://i.ibb.co/8nsrGrS6/FB-IMG-1779879736809.jpg',
      'https://i.ibb.co/Mkq74X1k/FB-IMG-1779879734398.jpg',
      'https://i.ibb.co/0RQJtLJx/FB-IMG-1779879731466.jpg',
      'https://i.ibb.co/KcPBXdNs/FB-IMG-1779879729065.jpg'
    ]
  },
  { 
    id: 6, 
    slug: 'website-development',
    title: 'Website Development', 
    icon: <Monitor size={32} />, 
    desc: 'Building responsive, modern portfolio and business websites with premium UI/UX, smooth animated web experiences, and admin dashboard integrations.',
    longDesc: 'We architect and build premium web experiences that blend striking design with robust functionality. Specializing in modern frameworks like React and Next.js, we deliver fast, responsive, and accessible websites. From immersive animations to custom admin dashboards and seamless API integrations, we provide end-to-end digital solutions that convert visitors into clients.',
    images: [
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2000&auto=format&fit=crop'
    ]
  },
  { 
    id: 7, 
    slug: 'logo-design',
    title: 'Logo Design', 
    icon: <Hexagon size={32} />, 
    desc: 'Crafting unique, memorable, and timeless logos that perfectly encapsulate your brand identity and set you apart in the marketplace.',
    longDesc: 'Your logo is the face of your business. We design custom, high-quality logos that are simple, scalable, and impactful. Our process begins with understanding your brand values, target audience, and industry to create a distinct symbol or wordmark that represents who you are. We deliver versatile logo packages suitable for digital, print, and merchandise.',
    images: [],
    folders: [
      {
        name: 'Batch 1',
        images: [
          'https://i.ibb.co/GffQkG48/FB-IMG-1779882829371.jpg',
          'https://i.ibb.co/0yRJyL0w/FB-IMG-1779882826534.jpg',
          'https://i.ibb.co/5gppCYQY/FB-IMG-1779882824935.jpg',
          'https://i.ibb.co/Qt7qR98/FB-IMG-1779882822200.jpg',
          'https://i.ibb.co/Ldr5q95h/FB-IMG-1779882819576.jpg'
        ]
      },
      {
        name: 'Batch 2',
        images: [
          'https://i.ibb.co/FZxYXS6/FB-IMG-1779881915289.jpg',
          'https://i.ibb.co/Rp56Bv76/FB-IMG-1779881945351.jpg',
          'https://i.ibb.co/Rkfr5HrK/FB-IMG-1779881948198.jpg',
          'https://i.ibb.co/FLX3m1jP/FB-IMG-1779881950642.jpg',
          'https://i.ibb.co/Z1YzZNFq/FB-IMG-1779881953031.jpg',
          'https://i.ibb.co/yc5Zk3VX/FB-IMG-1779881955360.jpg',
          'https://i.ibb.co/LXNyrQVw/FB-IMG-1779881957807.jpg',
          'https://i.ibb.co/LXNyrQVw/FB-IMG-1779881957807.jpg',
          'https://i.ibb.co/tMhwmZJL/FB-IMG-1779882213573.jpg',
          'https://i.ibb.co/KRKvD9P/FB-IMG-1779882217530.jpg',
          'https://i.ibb.co/zWhCFyQ2/FB-IMG-1779882220437.jpg'
        ]
      },
      {
        name: 'Batch 3',
        images: [
          'https://i.ibb.co/GQ5SzWcD/FB-IMG-1779882463527.jpg',
          'https://i.ibb.co/35dBD6Hd/FB-IMG-1779882468425.jpg',
          'https://i.ibb.co/JS9bzMc/FB-IMG-1779882470666.jpg',
          'https://i.ibb.co/LDR5R68V/FB-IMG-1779882473374.jpg',
          'https://i.ibb.co/wFbNpdd2/FB-IMG-1779882476516.jpg',
          'https://i.ibb.co/xqKv7KqV/FB-IMG-1779882478848.jpg'
        ]
      },
      {
        name: 'Batch 4',
        images: [
          'https://i.ibb.co/Ndy83WhW/FB-IMG-1779882397902.jpg',
          'https://i.ibb.co/YF5KhvK9/FB-IMG-1779882402488.jpg',
          'https://i.ibb.co/3qgP2P6/FB-IMG-1779882404865.jpg',
          'https://i.ibb.co/N2LSJ7vK/FB-IMG-1779882411742.jpg',
          'https://i.ibb.co/zW9YxVzR/FB-IMG-1779882409727.jpg',
          'https://i.ibb.co/nZWXrMT/FB-IMG-1779882416787.jpg',
          'https://i.ibb.co/fdRdWGVD/FB-IMG-1779882414307.jpg',
          'https://i.ibb.co/p6BqvcFV/FB-IMG-1779882433264.jpg',
          'https://i.ibb.co/Q7w2vkMF/FB-IMG-1779882430508.jpg',
          'https://i.ibb.co/xqFWq45Z/FB-IMG-1779882435832.jpg',
          'https://i.ibb.co/bgwyn80S/FB-IMG-1779882400271.jpg'
        ]
      },
      {
        name: 'Batch 5',
        images: [
          'https://i.ibb.co/HDbpdMG6/FB-IMG-1779882778043.jpg',
          'https://i.ibb.co/NXXP1zg/FB-IMG-1779882770597.jpg',
          'https://i.ibb.co/YFNZ6TvS/FB-IMG-1779882785509.jpg',
          'https://i.ibb.co/hR05VHM1/FB-IMG-1779882797526.jpg',
          'https://i.ibb.co/jZMRcPV4/FB-IMG-1779882787962.jpg',
          'https://i.ibb.co/LDtS0NMH/FB-IMG-1779882791492.jpg',
          'https://i.ibb.co/40MQW00/FB-IMG-1779882774367.jpg',
          'https://i.ibb.co/hxRJXtKR/FB-IMG-1779882768467.jpg',
          'https://i.ibb.co/HL3zK1JM/FB-IMG-1779882766270.jpg',
          'https://i.ibb.co/35TRjPjr/FB-IMG-1779882764103.jpg',
          'https://i.ibb.co/ynjqHHkF/FB-IMG-1779882761096.jpg',
          'https://i.ibb.co/9mMcWQfy/FB-IMG-1779882758145.jpg',
          'https://i.ibb.co/tp2sgTgB/FB-IMG-1779882756656.jpg',
          'https://i.ibb.co/YTbXs9Vd/FB-IMG-1779882753712.jpg',
          'https://i.ibb.co/27Dbhhb9/FB-IMG-1779882751594.jpg',
          'https://i.ibb.co/d0MMs0MC/FB-IMG-1779882744563.jpg',
          'https://i.ibb.co/S4GS3n74/FB-IMG-1779882747721.jpg',
          'https://i.ibb.co/fY52JTbL/FB-IMG-1779882741454.jpg',
          'https://i.ibb.co/bjsrKpV8/FB-IMG-1779882737818.jpg',
          'https://i.ibb.co/9mBDdWJ1/FB-IMG-1779882731684.jpg',
          'https://i.ibb.co/bg5m1FRQ/FB-IMG-1779882733991.jpg',
          'https://i.ibb.co/jKzC7gJ/FB-IMG-1779882726403.jpg',
          'https://i.ibb.co/F4BbZgwC/FB-IMG-1779882728399.jpg',
          'https://i.ibb.co/shCCmMb/FB-IMG-1779882719940.jpg',
          'https://i.ibb.co/F4GrQ1Kn/FB-IMG-1779882723569.jpg',
          'https://i.ibb.co/S47WRbH7/FB-IMG-1779882712388.jpg',
          'https://i.ibb.co/fGZdghQf/FB-IMG-1779882715155.jpg',
          'https://i.ibb.co/9m4XzGtj/FB-IMG-1779882695658.jpg',
          'https://i.ibb.co/1fTMQPbG/FB-IMG-1779882705031.jpg',
          'https://i.ibb.co/Mx23HgwJ/FB-IMG-1779882682868.jpg',
          'https://i.ibb.co/dwbF4dbr/FB-IMG-1779882689905.jpg',
          'https://i.ibb.co/5XFPGpHk/FB-IMG-1779882675536.jpg',
          'https://i.ibb.co/1tnPjKWc/FB-IMG-1779882680121.jpg',
          'https://i.ibb.co/Cs7fnNmg/FB-IMG-1779882663842.jpg',
          'https://i.ibb.co/BV56Qn3G/FB-IMG-1779882666379.jpg',
          'https://i.ibb.co/27ggpMKK/FB-IMG-1779882659062.jpg',
          'https://i.ibb.co/mFDdgPDj/FB-IMG-1779882661772.jpg',
          'https://i.ibb.co/ym909JTM/FB-IMG-1779882653716.jpg',
          'https://i.ibb.co/GvBhPnB2/FB-IMG-1779882656758.jpg',
          'https://i.ibb.co/99Q7jLxn/FB-IMG-1779882642431.jpg',
          'https://i.ibb.co/qFkwDLmP/FB-IMG-1779882651298.jpg',
          'https://i.ibb.co/sTC7KQH/FB-IMG-1779882637645.jpg',
          'https://i.ibb.co/XfJ1MjNv/FB-IMG-1779882639562.jpg',
          'https://i.ibb.co/CK0Ws0T7/FB-IMG-1779882633077.jpg',
          'https://i.ibb.co/HL3zK1JM/FB-IMG-1779882766270.jpg',
          'https://i.ibb.co/Df5pdrWD/FB-IMG-1779882628795.jpg',
          'https://i.ibb.co/5qLCJPx/FB-IMG-1779882630964.jpg',
          'https://i.ibb.co/sv4LxYFR/FB-IMG-1779882573397.jpg',
          'https://i.ibb.co/Cs1BzwMk/FB-IMG-1779882550067.jpg',
          'https://i.ibb.co/3y6qSVL9/FB-IMG-1779882561514.jpg',
          'https://i.ibb.co/0y0zFMSp/FB-IMG-1779882577818.jpg',
          'https://i.ibb.co/BK6nJCnC/FB-IMG-1779882782343.jpg',
          'https://i.ibb.co/CK4gybfd/FB-IMG-1779882800814.jpg',
          'https://i.ibb.co/d0GQYzZj/FB-IMG-1779882832782.jpg',
          'https://i.ibb.co/zTr7nqHm/FB-IMG-1779882836589.jpg'
        ]
      }
    ]
  }
];
