import React from 'react';
import { motion } from 'motion/react';

export const LogoGallery = ({ folders, images }: { folders?: any[], images?: string[] }) => {
  return (
    <div className="flex flex-col gap-16 w-full overflow-hidden -mx-6 px-6 lg:-mx-12 lg:px-12 py-10 rounded-3xl bg-black/20 backdrop-blur-sm border border-white/5 relative">
      <div className="absolute inset-0 bg-accent/5 rounded-3xl mix-blend-overlay pointer-events-none" />
      
      {folders?.map((folder, fIdx) => {
         const items = [...folder.images, ...folder.images, ...folder.images, ...folder.images];
         
         return (
         <div key={fIdx} className="w-full relative">
            <h3 className="text-xl font-poppins font-medium text-gray-200 mb-8 flex items-center gap-3">
               <span className="w-12 h-px bg-accent"></span> {folder.name}
            </h3>
            
            <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-primary to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-primary to-transparent z-10 pointer-events-none" />

            <div className="flex w-[400vw] sm:w-[300vw] md:w-[200vw]">
                <div className={`flex w-full ${fIdx % 2 === 0 ? 'animate-marquee' : 'animate-marquee-slow'} gap-8 hover:[animation-play-state:paused]`}>
                  {items.map((img, i) => (
                    <div key={i} className="flex-shrink-0 w-64 md:w-80 h-64 md:h-80 glass-card rounded-2xl p-6 group relative overflow-hidden flex items-center justify-center transition-all duration-500 hover:shadow-[0_0_50px_rgba(124,77,255,0.4)] hover:-translate-y-2 cursor-pointer border border-white/10 hover:border-accent/50 bg-white/[0.03]">
                       <div className="absolute inset-0 bg-gradient-to-b from-accent/20 to-transparent mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                       <img src={img} alt="Gallery item" className="w-full h-full object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] group-hover:scale-110 transition-transform duration-700 ease-out z-10" />
                    </div>
                  ))}
                </div>
            </div>
         </div>
       )})}

      {(!folders || folders.length === 0) && images && images.length > 0 && (
         <div className="w-full relative">
            <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-primary to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-primary to-transparent z-10 pointer-events-none" />

            <div className="flex w-[400vw] sm:w-[300vw] md:w-[200vw]">
                <div className="flex w-full animate-marquee gap-8 hover:[animation-play-state:paused]">
                  {[...images, ...images, ...images, ...images].map((img, i) => (
                    <div key={i} className="flex-shrink-0 w-64 md:w-80 h-64 md:h-80 glass-card rounded-2xl p-6 group relative overflow-hidden flex items-center justify-center transition-all duration-500 hover:shadow-[0_0_50px_rgba(124,77,255,0.4)] hover:-translate-y-2 cursor-pointer border border-white/10 hover:border-accent/50 bg-white/[0.03]">
                       <div className="absolute inset-0 bg-gradient-to-b from-accent/20 to-transparent mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                       <img src={img} alt="Gallery item" className="w-full h-full object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] group-hover:scale-110 transition-transform duration-700 ease-out z-10" />
                    </div>
                  ))}
                </div>
            </div>
         </div>
      )}
    </div>
  )
}

export const PhotographyGallery = ({ images }: { images?: string[] }) => {
  const items = images ? [...images, ...images, ...images, ...images] : [];
  
  return (
    <div className="w-full relative overflow-hidden py-16 -mx-6 px-6 lg:-mx-12 lg:px-12 bg-[#050A15]">
       <div className="absolute left-0 top-0 bottom-0 w-32 md:w-64 bg-gradient-to-r from-primary to-transparent z-20 pointer-events-none" />
       <div className="absolute right-0 top-0 bottom-0 w-32 md:w-64 bg-gradient-to-l from-primary to-transparent z-20 pointer-events-none" />
       
       <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
       <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-accent/30 to-transparent" />

       <div className="flex w-[600vw] md:w-[400vw]">
         <div className="flex w-full animate-marquee-slow gap-12 sm:gap-24 items-center">
            {items.map((img, i) => {
              const yOffset = i % 2 === 0 ? '-translate-y-8' : 'translate-y-8';
              
              return (
              <div key={i} className={`flex-shrink-0 w-[40vw] sm:w-[500px] md:w-[700px] aspect-[16/10] rounded-sm group relative overflow-hidden ${yOffset} transition-all duration-1000 shadow-[0_20px_40px_rgba(0,0,0,0.4)]`}>
                 <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent transition-colors duration-1000 z-10" />
                 <img src={img} alt="Gallery item" className="w-[110%] h-full object-cover group-hover:scale-105 transition-transform duration-[1500ms] ease-[cubic-bezier(0.25,1,0.5,1)]" />
                 <div className="absolute inset-0 border border-white/10 z-20 pointer-events-none group-hover:border-white/30 transition-colors duration-1000" />
              </div>
            )})}
         </div>
       </div>
    </div>
  );
}

export const CinematicGallery = ({ folders, images }: { folders?: any[], images?: string[] }) => {
  const allMedia = folders ? folders.flatMap(f => f.images) : (images || []);
  if (allMedia.length === 0) return <div className="text-gray-500 italic pb-8 text-sm">No media available.</div>;

  return (
    <div className="w-full">
      <div className="grid grid-cols-1 gap-12 sm:gap-16">
        {allMedia.map((img: string, idx: number) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="w-full relative group overflow-hidden rounded-xl border border-white/5 bg-black/40"
          >
            <div className="aspect-[21/9] sm:aspect-[2.35/1] relative w-full overflow-hidden">
               <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-1000 z-10 mix-blend-overlay" />
               <img src={img} alt="Cinematic" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2000ms] ease-out" />
               {/* Letterbox effect */}
               <div className="absolute top-0 left-0 w-full h-8 sm:h-12 bg-black z-20 pointer-events-none transform -translate-y-full group-hover:translate-y-0 transition-transform duration-700 ease-[0.16,1,0.3,1]" />
               <div className="absolute bottom-0 left-0 w-full h-8 sm:h-12 bg-black z-20 pointer-events-none transform translate-y-full group-hover:translate-y-0 transition-transform duration-700 ease-[0.16,1,0.3,1]" />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export const DefaultGallery = ({ folders, images }: { folders?: any[], images?: string[] }) => {
  return (
    <>
      {folders && folders.map((folder: any, folderIdx: number) => (
        <div key={`folder-${folderIdx}`} className="mb-16">
          <h3 className="text-xl font-poppins font-medium text-gray-300 mb-6 flex items-center gap-3">
            <span className="w-8 h-px bg-accent/50"></span> {folder.name}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {folder.images.map((img: string, idx: number) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: (idx % 3) * 0.1 }}
                className="rounded-3xl overflow-hidden border border-white/10 h-64 sm:h-80 relative group"
              >
                <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 transition-opacity z-10 mix-blend-overlay" />
                <img src={img} alt="Gallery item" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </motion.div>
            ))}
          </div>
        </div>
      ))}

      {images && images.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {images.map((img, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: (idx % 3) * 0.1 }}
              className="rounded-3xl overflow-hidden border border-white/10 h-64 sm:h-80 relative group"
            >
              <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 transition-opacity z-10 mix-blend-overlay" />
              <img src={img} alt="Gallery item" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            </motion.div>
          ))}
        </div>
      )}
    </>
  );
}

export const GalleryRenderer = ({ slug, folders, images }: { slug: string, folders?: any[], images?: string[] }) => {
  if (slug === 'logo-design' || slug === 'graphic-design' || slug === 'social-media-management') {
    return <LogoGallery folders={folders} images={images} />;
  }
  if (slug === 'photography') {
    return <PhotographyGallery images={images} />;
  }
  if (slug === 'cinematography' || slug === 'video-editing') {
     return <CinematicGallery folders={folders} images={images} />;
  }
  return <DefaultGallery folders={folders} images={images} />
}
