import React, { useEffect, useRef, useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import Lenis from 'lenis';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, Instagram, Phone, Mail, MapPin, MessageCircle } from 'lucide-react';

export function Navigation() {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  const links = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-[#07111F]/60 backdrop-blur-xl border-b border-white/5 text-white shadow-[0_4px_30px_rgba(0,0,0,0.1)] transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-xl font-display font-medium tracking-tighter uppercase relative group">
          <span className="group-hover:text-gray-300 transition-colors">Emmanuel</span>
          <span className="text-accent drop-shadow-[0_0_8px_rgba(124,77,255,0.4)]">Oyeyinka</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex gap-8 items-center bg-white/5 px-8 py-3 rounded-full border border-white/10 backdrop-blur-md shadow-inner">
          {links.map((link) => {
            const isActive = location.pathname === link.path || (link.path !== '/' && location.pathname.startsWith(link.path));
            return (
              <Link 
                key={link.path} 
                to={link.path}
                className={`text-xs tracking-[0.2em] relative uppercase font-medium transition-all duration-300 ${
                  isActive 
                    ? 'text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {link.name}
                {isActive && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute -bottom-2 left-0 right-0 h-[2px] bg-accent/80 rounded-full drop-shadow-[0_0_6px_rgba(124,77,255,0.8)]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Right side admin link */}
        <div className="hidden md:block">
          <Link 
            to="/admin" 
            className="text-xs uppercase tracking-widest text-gray-400 hover:text-white font-medium border border-white/10 rounded-full px-5 py-2.5 hover:bg-white/10 hover:border-white/20 transition-all duration-300"
          >
            ADMIN
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden z-50 text-white"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X /> : <Menu />}
        </button>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', ease: [0.76, 0, 0.24, 1], duration: 0.8 }}
              className="fixed inset-0 bg-primary-bg h-screen w-screen z-40 flex flex-col justify-center px-12"
            >
              <nav className="flex flex-col gap-8">
                {links.map((link, i) => (
                  <motion.div
                    key={link.path}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + (i * 0.1) }}
                  >
                    <Link 
                      to={link.path}
                      className="text-5xl font-display font-medium uppercase tracking-tighter hover:text-accent"
                    >
                      {link.name}
                    </Link>
                  </motion.div>
                ))}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                  className="mt-12"
                >
                  <Link to="/admin" className="text-xl font-display text-gray-500 hover:text-accent">Admin Login</Link>
                </motion.div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}

export function Footer() {
  const [location, setLocation] = useState('Lad/Lak, Bariga');

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.location) {
          setLocation(data.location);
        }
      })
      .catch(console.error);
  }, []);

  return (
    <footer className="w-full py-16 border-t border-white/5 mt-24 relative overflow-hidden bg-primary-bg">
      <div className="absolute inset-0 bg-gradient-to-t from-accent/5 to-transparent pointer-events-none" />
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-10 text-sm text-gray-500 relative z-10">
        <div className="text-center md:text-left">
          <div className="text-xl font-display font-medium tracking-tighter uppercase mb-4 text-white">
            Emmanuel<span className="text-accent drop-shadow-[0_0_8px_rgba(124,77,255,0.4)]">Oyeyinka</span>
          </div>
          <div className="tracking-[0.2em] uppercase text-xs font-medium opacity-60">
            &copy; {new Date().getFullYear()} All Rights Reserved.
          </div>
        </div>
        
        <div className="flex flex-wrap justify-center gap-x-8 gap-y-4">
          <a href="https://www.instagram.com/merit_wedding_and_events_ltd" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-white transition-colors group">
            <Instagram size={16} className="text-accent shrink-0 group-hover:scale-110 group-hover:drop-shadow-[0_0_8px_rgba(124,77,255,0.8)] transition-all" />
            <span className="uppercase tracking-[0.2em] text-xs font-medium">Instagram</span>
          </a>
          <a href="https://wa.me/2348111777805" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-white transition-colors group">
            <MessageCircle size={16} className="text-[#25D366] group-hover:scale-110 group-hover:drop-shadow-[0_0_8px_rgba(37,211,102,0.8)] transition-all" />
            <span className="uppercase tracking-[0.2em] text-xs font-medium">WhatsApp</span>
          </a>
          <a href="mailto:meritoe74@gmail.com" className="flex items-center gap-3 hover:text-white transition-colors group">
            <Mail size={16} className="text-accent group-hover:scale-110 group-hover:drop-shadow-[0_0_8px_rgba(124,77,255,0.8)] transition-all" />
            <span className="uppercase tracking-[0.2em] text-xs font-medium">Email</span>
          </a>
          <a href="tel:08111777805" className="flex items-center gap-3 hover:text-white transition-colors group">
            <Phone size={16} className="text-accent group-hover:scale-110 group-hover:drop-shadow-[0_0_8px_rgba(124,77,255,0.8)] transition-all" />
            <span className="uppercase tracking-[0.2em] text-xs font-medium">Phone</span>
          </a>
          <a href={`https://maps.google.com/?q=${encodeURIComponent(location)}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-white transition-colors group">
            <MapPin size={16} className="text-accent group-hover:scale-110 group-hover:drop-shadow-[0_0_8px_rgba(124,77,255,0.8)] transition-all" />
            <span className="uppercase tracking-[0.2em] text-xs font-medium">{location}</span>
          </a>
        </div>
      </div>
    </footer>
  );
}

export function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const cursor = cursorRef.current;
    if (!cursor) return;
    
    // Check if it's a touch device, hide cursor
    if (window.matchMedia("(pointer: coarse)").matches) {
       cursor.style.display = 'none';
       return;
    }

    const moveCursor = (e: MouseEvent) => {
      cursor.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0)`;
    };

    window.addEventListener('mousemove', moveCursor);
    return () => window.removeEventListener('mousemove', moveCursor);
  }, []);

  return (
    <div 
      ref={cursorRef} 
      className="fixed top-0 left-0 w-6 h-6 rounded-full border border-accent bg-accent-glow pointer-events-none z-[100] transform -translate-x-1/2 -translate-y-1/2 mix-blend-screen hidden md:block"
      style={{ transition: 'width 0.2s, height 0.2s' }}
    />
  );
}

export default function Layout() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  // Setup Lenis
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <>
      <CustomCursor />
      <Navigation />
      <AnimatePresence mode="wait">
        <motion.main
          key={pathname}
          initial={{ opacity: 0, filter: 'blur(10px)' }}
          animate={{ opacity: 1, filter: 'blur(0px)' }}
          exit={{ opacity: 0, filter: 'blur(10px)' }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="min-h-screen pt-24"
        >
          <Outlet />
          <Footer />
        </motion.main>
      </AnimatePresence>
    </>
  );
}
