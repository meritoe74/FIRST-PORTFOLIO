import express from 'express';
import path from 'path';
import multer from 'multer';
import fs from 'fs';
import nodemailer from 'nodemailer';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import { createClient } from '@supabase/supabase-js';
import { mockData } from './mockData';

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cookieParser());

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || '';
const supabase = SUPABASE_URL && SUPABASE_KEY ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

// Multer config for in-memory uploads (since diskStorage fails on serverless Netlify)
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-for-dev';
const ADMIN_EMAILS = ['meritoe74@gmail.com', 'meritevents74@gmail.com'];

// Helper to query either Supabase or fallback mock data
async function getTable(table: string) {
  if (supabase) {
    const { data } = await supabase.from(table).select('*');
    return data || [];
  }
  return mockData[table === 'service_requests' ? 'serviceRequests' : table] || [];
}

// Ensure static files inside uploads are still served if operating locally without Supabase
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));


app.post('/api/auth/login', (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });
  
  if (ADMIN_EMAILS.includes(email.toLowerCase())) {
    const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '1d' });
    res.cookie('admin_token', token, { 
      httpOnly: true, 
      secure: true,
      sameSite: 'none',
      maxAge: 24 * 60 * 60 * 1000 // 1 day
    });
    return res.json({ success: true, token });
  }
  return res.status(401).json({ error: 'Unauthorized Access: Invalid Email' });
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('admin_token', { sameSite: 'none', secure: true });
  res.json({ success: true });
});

app.get('/api/auth/check', (req, res) => {
  let token = req.cookies.admin_token;
  if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ authenticated: false });
  try {
    jwt.verify(token, JWT_SECRET);
    res.json({ authenticated: true });
  } catch (err) {
    res.status(401).json({ authenticated: false });
  }
});

const requireAdmin = (req: any, res: any, next: any) => {
  if (req.method === 'GET' && !req.path.startsWith('/api/admin/')) {
    return next();
  }
  let token = req.cookies?.admin_token;
  if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
};

app.post('/api/*', (req, res, next) => {
  if (['/api/auth/login', '/api/auth/logout', '/api/messages', '/api/service_requests', '/api/contact', '/api/upload'].includes(req.path)) {
    return next();
  }
  requireAdmin(req, res, next);
});
app.put('/api/*', requireAdmin);
app.delete('/api/*', requireAdmin);


// Categories
app.get('/api/categories', async (req, res) => {
  res.json(await getTable('categories'));
});

// Projects
app.get('/api/projects', async (req, res) => {
  const { categorySlug } = req.query;
  let projects = await getTable('projects');
  const categories = await getTable('categories');
  
  projects = projects.map((p: any) => {
    const cat = categories.find((c: any) => c.id === p.categoryId || c.id === p.category_id);
    return { ...p, categoryName: cat?.name, categorySlug: cat?.slug };
  });

  if (categorySlug) {
    projects = projects.filter((p: any) => p.categorySlug === categorySlug);
  }
  res.json(projects);
});

app.get('/api/projects/:slug', async (req, res) => {
  let projects = await getTable('projects');
  const categories = await getTable('categories');
  
  const project = projects.find((p: any) => p.slug === req.params.slug);
  if (!project) return res.status(404).json({ error: "Not found" });

  const cat = categories.find((c: any) => c.id === project.categoryId || c.id === project.category_id);
  res.json({ ...project, categoryName: cat?.name, categorySlug: cat?.slug });
});

app.post('/api/projects', async (req, res) => {
  if (supabase) {
    const { data } = await supabase.from('projects').insert([req.body]).select();
    return res.json({ id: data?.[0]?.id, success: true });
  }
  res.json({ success: true, mockMode: true });
});

app.put('/api/projects/:id', async (req, res) => {
  if (supabase) await supabase.from('projects').update(req.body).eq('id', req.params.id);
  res.json({ success: true });
});

app.delete('/api/projects/:id', async (req, res) => {
  if (supabase) await supabase.from('projects').delete().eq('id', req.params.id);
  res.json({ success: true });
});

// Contact & Service Requests
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER || 'meritoe74@gmail.com',
    pass: process.env.GMAIL_APP_PASSWORD || ''
  }
});

async function sendEmailIfconfigured(payload: any) {
  if (!process.env.GMAIL_APP_PASSWORD) return false;
  try {
    await transporter.sendMail(payload);
    return true;
  } catch (err) {
    console.error("Mail send failed", err);
    return false;
  }
}

app.post('/api/contact', async (req, res) => {
  const { name, email, subject, message } = req.body;
  if (supabase) {
    await supabase.from('messages').insert([{ name, email, subject, message }]);
  }
  
  const emailSent = await sendEmailIfconfigured({
      from: '"Emmanuel Oyeyinka" <' + (process.env.GMAIL_USER || 'meritoe74@gmail.com') + '>',
      to: 'meritoe74@gmail.com',
      replyTo: email,
      subject: 'New Contact Form: ' + (subject || 'No Subject') + ' - from ' + name,
      html: '<h2>New Message from ' + name + '</h2><p><strong>Email:</strong> ' + email + '</p><p>' + message + '</p>'
  });
  res.json({ success: true, emailSent });
});

app.get('/api/messages', async (req, res) => res.json(await getTable('messages')));
app.put('/api/messages/:id/read', async (req, res) => {
  if (supabase) await supabase.from('messages').update({ isRead: 1 }).eq('id', req.params.id);
  res.json({ success: true });
});
app.delete('/api/messages/:id', async (req, res) => {
  if (supabase) await supabase.from('messages').delete().eq('id', req.params.id);
  res.json({ success: true });
});

app.post('/api/service_requests', async (req, res) => {
  const { name, email, projectType, message } = req.body;
  if (supabase) {
    await supabase.from('service_requests').insert([{ name, email, projectType, message }]);
  }
  const emailSent = await sendEmailIfconfigured({
    from: '"Emmanuel Oyeyinka" <' + (process.env.GMAIL_USER || 'meritoe74@gmail.com') + '>',
    to: 'meritoe74@gmail.com',
    replyTo: email,
    subject: 'Service Request: ' + projectType + ' - from ' + name,
    html: '<h2>New Service Request</h2><p><strong>Name:</strong> ' + name + '</p><p><strong>Email:</strong> ' + email + '</p><p><strong>Type:</strong> ' + projectType + '</p><hr/><p>' + message + '</p>'
  });
  res.json({ success: true, emailSent });
});

app.get('/api/service_requests', async (req, res) => res.json(await getTable('service_requests')));
app.put('/api/service_requests/:id/read', async (req, res) => {
  if (supabase) await supabase.from('service_requests').update({ isRead: 1 }).eq('id', req.params.id);
  res.json({ success: true });
});
app.patch('/api/service_requests/:id/status', async (req, res) => {
  if (supabase) await supabase.from('service_requests').update({ status: req.body.status }).eq('id', req.params.id);
  res.json({ success: true });
});
app.delete('/api/service_requests/:id', async (req, res) => {
  if (supabase) await supabase.from('service_requests').delete().eq('id', req.params.id);
  res.json({ success: true });
});

// Uploads
app.get('/api/uploads', async (req, res) => res.json(await getTable('media')));

app.post('/api/upload', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const section = req.body.section || 'General';
  
  if (supabase) {
    const ext = req.file.originalname.split('.').pop();
    const fileName = Date.now() + '-' + Math.random().toString(36).substring(7) + '.' + ext;
    const { data: uploadData, error } = await supabase.storage.from('media').upload(fileName, req.file.buffer, {
      contentType: req.file.mimetype
    });
    
    if (error) return res.status(500).json({ error: error.message });
    
    const { data: publicUrlData } = supabase.storage.from('media').getPublicUrl(fileName);
    const url = publicUrlData.publicUrl;
    
    const { data: insertData } = await supabase.from('media').insert([{
      filename: fileName,
      originalName: req.file.originalname,
      url,
      size: req.file.size,
      section
    }]).select();
    
    return res.json({ id: insertData?.[0]?.id, url, originalname: req.file.originalname, size: req.file.size, section });
  } 
  
  // Local fallback (fake upload)
  res.json({ id: Date.now(), url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800', originalname: req.file.originalname, size: req.file.size, section });
});

app.put('/api/uploads/:id', async (req, res) => {
  if (supabase) await supabase.from('media').update({ section: req.body.section }).eq('id', req.params.id);
  res.json({ success: true });
});

app.delete('/api/uploads/:id', async (req, res) => {
  if (supabase) {
    const { data } = await supabase.from('media').select('*').eq('id', req.params.id).single();
    if (data) {
      await supabase.storage.from('media').remove([data.filename]);
      await supabase.from('media').delete().eq('id', req.params.id);
    }
  }
  res.json({ success: true });
});

// Settings, Services, Testimonials
app.get('/api/settings', async (req, res) => {
  const data = await getTable('settings') || [];
  const map = data.reduce((acc: any, curr: any) => ({ ...acc, [curr.key]: curr.value }), {});
  res.json(map);
});
app.post('/api/settings', async (req, res) => {
  if (supabase) {
    const { data } = await supabase.from('settings').select('*').eq('key', req.body.key).single();
    if (data) await supabase.from('settings').update({ value: req.body.value }).eq('key', req.body.key);
    else await supabase.from('settings').insert([req.body]);
  }
  res.json({ success: true });
});

app.get('/api/services', async (req, res) => {
  const data = await getTable('services');
  res.json(data.map((s:any) => ({
    ...s,
    images: typeof s.images === 'string' ? JSON.parse(s.images) : (s.images||[]),
    folders: typeof s.folders === 'string' ? JSON.parse(s.folders) : (s.folders||[])
  })));
});
app.get('/api/services/:slug', async (req, res) => {
  const data = await getTable('services');
  const service = data.find((s:any) => s.slug === req.params.slug);
  if (!service) return res.status(404).json({error: 'Not found'});
  res.json({
    ...service,
    images: typeof service.images === 'string' ? JSON.parse(service.images) : (service.images||[]),
    folders: typeof service.folders === 'string' ? JSON.parse(service.folders) : (service.folders||[])
  });
});
app.post('/api/services', async (req, res) => {
  if (supabase) {
    const { images, folders, ...rest } = req.body;
    const { data } = await supabase.from('services').insert([{
      ...rest, images: JSON.stringify(images||[]), folders: JSON.stringify(folders||[])
    }]).select();
    return res.json({ id: data?.[0]?.id, success: true });
  }
  res.json({ success: true });
});
app.put('/api/services/:id', async (req, res) => {
  if (supabase) {
    const { images, folders, ...rest } = req.body;
    await supabase.from('services').update({
      ...rest, images: JSON.stringify(images||[]), folders: JSON.stringify(folders||[])
    }).eq('id', req.params.id);
  }
  res.json({ success: true });
});
app.delete('/api/services/:id', async (req, res) => {
  if (supabase) await supabase.from('services').delete().eq('id', req.params.id);
  res.json({ success: true });
});

app.get('/api/testimonials', async (req, res) => res.json(await getTable('testimonials')));
app.post('/api/testimonials', async (req, res) => {
  if (supabase) await supabase.from('testimonials').insert([req.body]);
  res.json({ success: true });
});
app.delete('/api/testimonials/:id', async (req, res) => {
  if (supabase) await supabase.from('testimonials').delete().eq('id', req.params.id);
  res.json({ success: true });
});

export { app }; // Exported for Netlify handler

// Start server locally if not invoked by Netlify
if (process.env.NODE_ENV !== 'test' && !process.env.NETLIFY) {
  async function startServer() {
    if (process.env.NODE_ENV !== 'production') {
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } else {
      const distPath = path.join(process.cwd(), 'dist');
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }

    app.listen(PORT, '0.0.0.0', () => {
      console.log('Server running on http://localhost:' + PORT);
    });
  }
  startServer();
}
