export const mockData: any = {
  categories: [
    { id: 1, name: 'Cinematography', slug: 'cinematography' },
    { id: 2, name: 'Graphic Design', slug: 'graphic-design' },
    { id: 3, name: 'Photography', slug: 'photography' }
  ],
  projects: [
    {
      id: 1,
      categoryId: 2,
      title: 'Cosmic Brand Identity',
      slug: 'cosmic-brand',
      description: 'A complete brand overhaul for a futuristic tech startup.',
      excerpt: 'Futuristic aesthetic branding',
      imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop',
      tools: 'Illustrator, Photoshop, Figma',
      mediaGallery: '[]',
      categoryName: 'Graphic Design',
      categorySlug: 'graphic-design'
    },
    {
      id: 2,
      categoryId: 3,
      title: 'Neon Social Kit',
      slug: 'neon-social',
      description: 'Vibrant social media templates for an emerging music label.',
      excerpt: 'Music label social media graphics',
      imageUrl: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1?q=80&w=2000&auto=format&fit=crop',
      tools: 'Photoshop',
      mediaGallery: '[]',
      categoryName: 'Photography',
      categorySlug: 'photography'
    }
  ],
  services: [
    {
      id: 1,
      title: 'Social Media Management',
      slug: 'social-media-management',
      desc: 'Strategic content creation.',
      longDesc: 'Our social media management service goes beyond simply posting content.',
      icon: 'Share2',
      images: [
        'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=2000&auto=format&fit=crop'
      ],
      folders: []
    }
  ],
  testimonials: [
    {
      id: 1,
      name: 'Sarah Jenkins',
      role: 'Marketing Director',
      content: 'Absolutely phenomenal work. The attention to detail and creative vision exceeded all our expectations.',
      rating: 5,
      imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop'
    }
  ],
  messages: [],
  serviceRequests: [],
  media: []
};
