import Database from 'better-sqlite3';
const db = new Database('portfolio.db');

// update social media
try {
  db.prepare('UPDATE services SET images = json(?) WHERE slug = ?').run(
    JSON.stringify([
      'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=2000&auto=format&fit=crop', // Instagram
      'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?q=80&w=2000&auto=format&fit=crop', // FB
      'https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?q=80&w=2000&auto=format&fit=crop', // Platform
      'https://images.unsplash.com/photo-1611162616475-46b635cb6868?q=80&w=2000&auto=format&fit=crop', // Ads
      'https://images.unsplash.com/photo-1611162617263-4aec30edfd87?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1611162617711-2b62719a6b16?q=80&w=2000&auto=format&fit=crop'
    ]),
    'social-media-management'
  );

  db.prepare('UPDATE services SET images = json(?) WHERE slug = ?').run(
    JSON.stringify([
      'https://images.unsplash.com/photo-1542435503-956c469071fe?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1542744094-3a31f272c490?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2000&auto=format&fit=crop'
    ]),
    'content-creation'
  );
  
  db.prepare('UPDATE services SET folders = json(?) WHERE slug = ?').run(
    JSON.stringify([{
      name: 'Content Mockups',
      images: [
        'https://images.unsplash.com/photo-1626125345510-4603468eedfb?q=80&w=2000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1611162616475-46b635cb6868?q=80&w=2000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1516321497487-e288fb19713f?q=80&w=2000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1533750349088-cd071a9248e5?q=80&w=2000&auto=format&fit=crop'
      ]
    }]),
    'content-creation'
  );

  console.log('Services tables mockups updated');
} catch (e) {
  console.log('Error updating services', e);
}
