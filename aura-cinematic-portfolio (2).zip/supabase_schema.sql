-- Run this entire script in your Supabase SQL Editor.

-- Categories Table
CREATE TABLE IF NOT EXISTS public.categories (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE
);

-- Projects Table
CREATE TABLE IF NOT EXISTS public.projects (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    "categoryId" INTEGER REFERENCES public.categories(id),
    description TEXT,
    excerpt TEXT,
    "imageUrl" TEXT,
    tools TEXT,
    "mediaGallery" JSONB DEFAULT '[]'::jsonb,
    featured INTEGER DEFAULT 0,
    tags JSONB DEFAULT '[]'::jsonb,
    "externalLink" TEXT DEFAULT '',
    "orderIndex" INTEGER DEFAULT 0,
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Messages Table (Contact Form)
CREATE TABLE IF NOT EXISTS public.messages (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT DEFAULT '',
    message TEXT NOT NULL,
    "isRead" INTEGER DEFAULT 0,
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Service Requests Table
CREATE TABLE IF NOT EXISTS public.service_requests (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    "projectType" TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    "isRead" INTEGER DEFAULT 0,
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Media Table (Uploads)
CREATE TABLE IF NOT EXISTS public.media (
    id SERIAL PRIMARY KEY,
    filename TEXT NOT NULL,
    "originalName" TEXT NOT NULL,
    url TEXT NOT NULL,
    size INTEGER NOT NULL,
    section TEXT,
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Settings Table
CREATE TABLE IF NOT EXISTS public.settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Services Table
CREATE TABLE IF NOT EXISTS public.services (
    id SERIAL PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    icon TEXT NOT NULL,
    "desc" TEXT NOT NULL,
    "longDesc" TEXT NOT NULL,
    images JSONB DEFAULT '[]'::jsonb,
    folders JSONB DEFAULT '[]'::jsonb
);

-- Testimonials Table
CREATE TABLE IF NOT EXISTS public.testimonials (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    rating INTEGER DEFAULT 5,
    "imageUrl" TEXT,
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Storage bucket for media
INSERT INTO storage.buckets (id, name, public) VALUES ('media', 'media', true)
ON CONFLICT DO NOTHING;

-- Policies for storage to allow public read, and allow anon uploads since our Node app uses Anon key
CREATE POLICY "Public Read Access" ON storage.objects FOR SELECT USING (bucket_id = 'media');
CREATE POLICY "Public Insert Access" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'media');
CREATE POLICY "Public Delete Access" ON storage.objects FOR DELETE USING (bucket_id = 'media');

-- Initial Seed Data
INSERT INTO public.categories (name, slug) VALUES 
('Cinematography', 'cinematography'),
('Photography', 'photography'),
('Graphic Design', 'graphic-design')
ON CONFLICT (slug) DO NOTHING;

-- Ensure RLS is disabled for ease of use with backend anon key
ALTER TABLE public.categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.media DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.services DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.testimonials DISABLE ROW LEVEL SECURITY;
