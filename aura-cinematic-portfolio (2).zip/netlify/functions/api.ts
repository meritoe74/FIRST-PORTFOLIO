import serverless from 'serverless-http';
import app from '../../server-api'; // the new API backend

export const handler = serverless(app);
