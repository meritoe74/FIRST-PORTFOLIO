import express from 'express';
import path from 'path';
import multer from 'multer';
import Database from 'better-sqlite3';
import fs from 'fs';
import nodemailer from 'nodemailer';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Set up uploads directory
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer config for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// Provide uploads folder as static
app.use('/uploads', express.static(uploadsDir));

// Initialize SQLite DB
const dbFile = path.join(process.cwd(), 'portfolio.db');
const db = new Database(dbFile);

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    categoryId INTEGER NOT NULL,
    description TEXT,
    excerpt TEXT,
    imageUrl TEXT,
    tools TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(categoryId) REFERENCES categories(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT DEFAULT '',
    message TEXT NOT NULL,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS service_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    projectType TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    originalName TEXT NOT NULL,
    url TEXT NOT NULL,
    size INTEGER NOT NULL,
    section TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    icon TEXT NOT NULL,
    desc TEXT NOT NULL,
    longDesc TEXT NOT NULL,
    images TEXT,
    folders TEXT
  );

  CREATE TABLE IF NOT EXISTS testimonials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    rating INTEGER DEFAULT 5,
    imageUrl TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed data if empty
try {
  db.exec('ALTER TABLE messages ADD COLUMN subject TEXT DEFAULT ""');
} catch (e) {
  // Ignore if column already exists
}

try {
  db.exec('ALTER TABLE messages ADD COLUMN isRead INTEGER DEFAULT 0');
} catch (e) {}

try {
  db.exec('ALTER TABLE service_requests ADD COLUMN isRead INTEGER DEFAULT 0');
} catch (e) {}

try { db.exec('ALTER TABLE projects ADD COLUMN mediaGallery TEXT DEFAULT "[]"'); } catch (e) {}
try { db.exec('ALTER TABLE projects ADD COLUMN featured INTEGER DEFAULT 0'); } catch (e) {}
try { db.exec('ALTER TABLE projects ADD COLUMN tags TEXT DEFAULT "[]"'); } catch (e) {}
try { db.exec('ALTER TABLE projects ADD COLUMN externalLink TEXT DEFAULT ""'); } catch (e) {}
try { db.exec('ALTER TABLE projects ADD COLUMN orderIndex INTEGER DEFAULT 0'); } catch (e) {}

const countTestimonials = db.prepare('SELECT COUNT(*) as count FROM testimonials').get() as { count: number };
if (countTestimonials.count === 0) {
  const insertTestimonial = db.prepare('INSERT INTO testimonials (name, role, content, rating, imageUrl) VALUES (?, ?, ?, ?, ?)');
  insertTestimonial.run('Sarah Jenkins', 'Marketing Director', 'Absolutely phenomenal work. The attention to detail and creative vision exceeded all our expectations.', 5, 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop');
  insertTestimonial.run('Michael Chen', 'Startup Founder', 'They brought our brand to life. The process was seamless and the final result stunning.', 5, 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&auto=format&fit=crop');
}

const countServices = db.prepare('SELECT COUNT(*) as count FROM services').get() as { count: number };
if (countServices.count === 0) {
  const insertService = db.prepare('INSERT INTO services (slug, title, icon, desc, longDesc, images, folders) VALUES (?, ?, ?, ?, ?, ?, ?)');
  
  insertService.run(
    'social-media-management', 'Social Media Management', 'Share2',
    'Strategic content creation, community engagement, and visual storytelling tailored to elevate your brand presence and drive audience growth.',
    'Our social media management service goes beyond simply posting content. We develop comprehensive strategies based on deep audience insights, competitor analysis, and platform-specific trends. From crafting engaging visual narratives to managing community interactions and running targeted campaigns, we ensure your brand maintains a dynamic, responsive, and influential presence across all digital channels.',
    JSON.stringify([
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=2000&auto=format&fit=crop'
    ]),
    JSON.stringify([])
  );

  insertService.run(
    'cinematography', 'Cinematography', 'Film',
    'Premium visual narratives captured with cinematic precision. From conceptualization to final grade, telling stories that leave a lasting impact.',
    'We treat every project as a cinematic piece capable of moving audiences and shaping perceptions. Utilizing high-end camera equipment, sophisticated lighting techniques, and an acute understanding of visual storytelling, our cinematography service delivers breathtaking footage. Whether it is a commercial, a brand documentary, or a creative short, we focus on composition, movement, and narrative flow to produce visually stunning results.',
    JSON.stringify([
      'https://images.unsplash.com/photo-1579722359409-cf8fe17f9ba5?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1590605929668-cb0aa5f2f5fc?q=80&w=2000&auto=format&fit=crop'
    ]),
    JSON.stringify([])
  );

  insertService.run(
    'graphic-design', 'Graphic Design', 'PenTool',
    'Purpose-driven visual design that communicates brand identity with clarity, modern aesthetics, and professional typographic hierarchy.',
    'Our graphic design philosophy centers around clarity, emotion, and purpose. We craft bespoke visual identities, marketing collateral, and digital assets that resonate with your target audience. By mastering typography, color theory, and layout composition, we ensure every design piece is not only visually arresting but strategically aligned with your brand\'s core message and values.',
    JSON.stringify([
      'https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2000&auto=format&fit=crop'
    ]),
    JSON.stringify([{
      name: 'Batch 1',
      images: [
        'https://i.ibb.co/GQ5SzWcD/FB-IMG-1779882463527.jpg',
        'https://i.ibb.co/35dBD6Hd/FB-IMG-1779882468425.jpg',
        'https://i.ibb.co/JS9bzMc/FB-IMG-1779882470666.jpg',
        'https://i.ibb.co/LDR5R68V/FB-IMG-1779882473374.jpg',
        'https://i.ibb.co/wFbNpdd2/FB-IMG-1779882476516.jpg',
        'https://i.ibb.co/xqKv7KqV/FB-IMG-1779882478848.jpg',
        'https://i.ibb.co/tTWS4gWL/FB-IMG-1779891242957.jpg',
        'https://i.ibb.co/RTZnW4bg/FB-IMG-1779891240314.jpg',
        'https://i.ibb.co/fdyB5CMk/FB-IMG-1779891238152.jpg',
        'https://i.ibb.co/Kphd7dj1/FB-IMG-1779891235360.jpg',
        'https://i.ibb.co/99jDPHFR/FB-IMG-1779891232851.jpg'
      ]
    }])
  );

  insertService.run(
    'video-editing', 'Video Editing', 'Video',
    'Dynamic pacing, immersive sound design, and seamless transitions to transform raw footage into compelling, high-retention visual stories.',
    'Video editing is where the story truly comes to life. We specialize in dynamic pacing, intricate sound design, seamless visual effects, and professional color grading. Our approach transforms raw footage into compelling, high-retention stories optimized for any platform, ensuring your message is delivered with maximum impact and engagement.',
    JSON.stringify([
      'https://images.unsplash.com/photo-1574717024653-61fd2cf6d44d?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1592652431766-3d23ebed0ee4?q=80&w=2000&auto=format&fit=crop'
    ]),
    JSON.stringify([])
  );

  insertService.run(
    'photography', 'Photography', 'Camera',
    'Capturing moments, products, and brand stories with a keen eye for lighting, composition, and emotional resonance.',
    'From high-end product shoots to lifestyle branding and corporate portraits, our photography service captures the essence of your subject. We meticulously control lighting, environment, and composition to deliver crisp, beautiful, and emotionally resonant images that strengthen your brand\'s visual catalog.',
    JSON.stringify([
      'https://i.ibb.co/DDvps3Bp/FB-IMG-1779879723140.jpg',
      'https://i.ibb.co/jPvnKWHY/FB-IMG-1779880138765.jpg',
      'https://i.ibb.co/ksKRtnbV/FB-IMG-1779880136217.jpg',
      'https://i.ibb.co/60bn5dpF/FB-IMG-1779880133971.jpg',
      'https://i.ibb.co/vCxK3Fjw/FB-IMG-1779879760679.jpg',
      'https://i.ibb.co/zckxz43/FB-IMG-1779879758086.jpg',
      'https://i.ibb.co/NdJnFQ2r/FB-IMG-1779879757728.jpg',
      'https://i.ibb.co/5x2v25Vr/FB-IMG-1779879747603.jpg',
      'https://i.ibb.co/F47vBz7B/FB-IMG-1779879744646.jpg',
      'https://i.ibb.co/mVsQtS9M/FB-IMG-1779879741465.jpg',
      'https://i.ibb.co/8nsrGrS6/FB-IMG-1779879736809.jpg',
      'https://i.ibb.co/Mkq74X1k/FB-IMG-1779879734398.jpg',
      'https://i.ibb.co/0RQJtLJx/FB-IMG-1779879731466.jpg',
      'https://i.ibb.co/KcPBXdNs/FB-IMG-1779879729065.jpg'
    ]),
    JSON.stringify([])
  );

  insertService.run(
    'website-development', 'Website Development', 'Monitor',
    'Building responsive, modern portfolio and business websites with premium UI/UX, smooth animated web experiences, and admin dashboard integrations.',
    'We architect and build premium web experiences that blend striking design with robust functionality. Specializing in modern frameworks like React and Next.js, we deliver fast, responsive, and accessible websites. From immersive animations to custom admin dashboards and seamless API integrations, we provide end-to-end digital solutions that convert visitors into clients.',
    JSON.stringify([
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2000&auto=format&fit=crop'
    ]),
    JSON.stringify([])
  );

  insertService.run(
    'logo-design', 'Logo Design', 'Hexagon',
    'Crafting unique, memorable, and timeless logos that perfectly encapsulate your brand identity and set you apart in the marketplace.',
    'Your logo is the face of your business. We design custom, high-quality logos that are simple, scalable, and impactful. Our process begins with understanding your brand values, target audience, and industry to create a distinct symbol or wordmark that represents who you are. We deliver versatile logo packages suitable for digital, print, and merchandise.',
    JSON.stringify([
      'https://i.ibb.co/xnT8wWS/DEVOTIONAL-SERVICE-FLIER-FOR-OUR-SOCIAL-MEDIA-1.jpg',
      'https://i.ibb.co/mCGLD20Y/MISSIONARY-SUNDAY-FLIER-FOR-OUR-SOCIAL-MEDIA-4.jpg'
    ]),
    JSON.stringify([])
  );
}

const countCats = db.prepare('SELECT COUNT(*) as count FROM categories').get() as { count: number };
if (countCats.count === 0) {
  const insertCat = db.prepare('INSERT INTO categories (name, slug) VALUES (?, ?)');
  insertCat.run('Cinematography', 'cinematography');
  insertCat.run('Photography', 'photography');
  insertCat.run('Graphic Design', 'graphic-design');
  insertCat.run('Logo Design', 'logo-design');
  insertCat.run('Video Editing', 'video-editing');
  insertCat.run('Branding', 'branding');
  insertCat.run('Social Media', 'social-media');
  insertCat.run('Website Dev', 'website-development');
  insertCat.run('Content Creation', 'content-creation');

  const insertProj = db.prepare('INSERT INTO projects (title, slug, categoryId, description, excerpt, imageUrl, tools) VALUES (?, ?, ?, ?, ?, ?, ?)');
  insertProj.run(
    'Cosmic Brand Identity', 'cosmic-brand', 6, 
    'A complete brand overhaul for a futuristic tech startup.', 
    'Futuristic aesthetic branding', 
    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop', 
    'Illustrator, Photoshop, Figma'
  );
  insertProj.run(
    'Oasis UI Concept', 'oasis-ui', 2, 
    'Minimalist and clean UI kit for a wellness application.', 
    'Wellness app UI Concept', 
    'https://images.unsplash.com/photo-1541462608143-67571c6738dd?q=80&w=2000&auto=format&fit=crop', 
    'Figma, Framer'
  );
  insertProj.run(
    'Neon Social Kit', 'neon-social', 3, 
    'Vibrant social media templates for an emerging music label.', 
    'Music label social media graphics', 
    'https://images.unsplash.com/photo-1557672172-298e090bd0f1?q=80&w=2000&auto=format&fit=crop', 
    'Photoshop, After Effects'
  );
}

// --- Auth setup ---
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';

app.use(cookieParser());

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-for-dev';
const ADMIN_EMAILS = ['meritoe74@gmail.com', 'meritevents74@gmail.com'];

app.post('/api/auth/login', (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });
  
  if (ADMIN_EMAILS.includes(email.toLowerCase())) {
    const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '1d' });
    res.cookie('admin_token', token, { 
      httpOnly: true, 
      secure: true,
      sameSite: 'none',
      maxAge: 24 * 60 * 60 * 1000 // 1 day
    });
    return res.json({ success: true, token });
  }
  return res.status(401).json({ error: 'Unauthorized Access: Invalid Email' });
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('admin_token', { sameSite: 'none', secure: true });
  res.json({ success: true });
});

app.get('/api/auth/check', (req, res) => {
  let token = req.cookies.admin_token;
  if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ authenticated: false });
  try {
    jwt.verify(token, JWT_SECRET);
    res.json({ authenticated: true });
  } catch (err) {
    res.status(401).json({ authenticated: false });
  }
});

const requireAdmin = (req: any, res: any, next: any) => {
  if (req.method === 'GET' && !req.path.startsWith('/api/admin/')) {
    // allow public GETs to normal APIS but protect PUT/POST/DELETE
    return next();
  }
  let token = req.cookies.admin_token;
  if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
};

// Protect modifier API Routes
app.post('/api/*', (req, res, next) => {
  if (['/api/auth/login', '/api/auth/logout', '/api/messages', '/api/service-requests', '/api/upload'].includes(req.path)) {
    return next();
  }
  requireAdmin(req, res, next);
});
app.put('/api/*', requireAdmin);
app.delete('/api/*', requireAdmin);

// API Routes

// Categories
app.get('/api/categories', (req, res) => {
  const categories = db.prepare('SELECT * FROM categories').all();
  res.json(categories);
});

// Projects
app.get('/api/projects', (req, res) => {
  const { categorySlug } = req.query;
  if (categorySlug) {
    const projects = db.prepare(`
      SELECT p.*, c.name as categoryName, c.slug as categorySlug 
      FROM projects p 
      JOIN categories c ON p.categoryId = c.id 
      WHERE c.slug = ?
      ORDER BY p.orderIndex DESC, p.createdAt DESC
    `).all(categorySlug);
    res.json(projects);
  } else {
    const projects = db.prepare(`
      SELECT p.*, c.name as categoryName, c.slug as categorySlug 
      FROM projects p 
      JOIN categories c ON p.categoryId = c.id
      ORDER BY p.orderIndex DESC, p.createdAt DESC
    `).all();
    res.json(projects);
  }
});

app.get('/api/projects/:slug', (req, res) => {
  const project = db.prepare(`
    SELECT p.*, c.name as categoryName, c.slug as categorySlug 
    FROM projects p 
    JOIN categories c ON p.categoryId = c.id 
    WHERE p.slug = ?
  `).get(req.params.slug);
  
  if (project) {
    res.json(project);
  } else {
    res.status(404).json({ error: 'Project not found' });
  }
});

app.post('/api/projects', (req, res) => {
  try {
    const { title, slug, categoryId, description, excerpt, imageUrl, tools, mediaGallery = '[]', featured = 0, tags = '[]', externalLink = '', orderIndex = 0 } = req.body;
    const stmt = db.prepare('INSERT INTO projects (title, slug, categoryId, description, excerpt, imageUrl, tools, mediaGallery, featured, tags, externalLink, orderIndex) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const info = stmt.run(title, slug, categoryId, description, excerpt, imageUrl, tools, typeof mediaGallery === 'string' ? mediaGallery : JSON.stringify(mediaGallery), featured, typeof tags === 'string' ? tags : JSON.stringify(tags), externalLink, orderIndex);
    res.status(201).json({ id: info.lastInsertRowid, success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/projects/:id', (req, res) => {
  try {
    const { title, slug, categoryId, description, excerpt, imageUrl, tools, mediaGallery = '[]', featured = 0, tags = '[]', externalLink = '', orderIndex = 0 } = req.body;
    const stmt = db.prepare('UPDATE projects SET title=?, slug=?, categoryId=?, description=?, excerpt=?, imageUrl=?, tools=?, mediaGallery=?, featured=?, tags=?, externalLink=?, orderIndex=? WHERE id=?');
    stmt.run(title, slug, categoryId, description, excerpt, imageUrl, tools, typeof mediaGallery === 'string' ? mediaGallery : JSON.stringify(mediaGallery), featured, typeof tags === 'string' ? tags : JSON.stringify(tags), externalLink, orderIndex, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/projects/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM projects WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Contact
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER || 'meritoe74@gmail.com',
    pass: process.env.GMAIL_APP_PASSWORD || ''
  }
});

app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    const stmt = db.prepare('INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)');
    stmt.run(name, email, subject || '', message);
    
    // Attempt to send email
    let emailSent = false;
    try {
      if (process.env.GMAIL_APP_PASSWORD) {
        await transporter.sendMail({
          from: `"Emmanuel Oyeyinka" <${process.env.GMAIL_USER || 'meritoe74@gmail.com'}>`,
          to: 'meritoe74@gmail.com',
          replyTo: email,
          subject: `New Contact Form Submission: ${subject || 'No Subject'} - from ${name}`,
          html: `
            <h2>New Message from ${name}</h2>
            <p><strong>Sender Email:</strong> ${email}</p>
            <p><strong>Subject:</strong> ${subject || 'N/A'}</p>
            <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
            <hr />
            <h3>Message/Project Brief:</h3>
            <p style="white-space: pre-wrap;">${message}</p>
          `
        });
        emailSent = true;
      } else {
        console.warn('GMAIL_APP_PASSWORD is not set. Email notification skipped.');
      }
    } catch (emailErr) {
      console.error('Email delivery failed:', emailErr);
      // Fail the request if email fails to send and password was provided
      if (process.env.GMAIL_APP_PASSWORD) {
        throw new Error('Email delivery failed. Please check SMTP credentials.');
      }
    }

    res.json({ success: true, emailSent });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/messages', (req, res) => {
  const messages = db.prepare('SELECT * FROM messages ORDER BY createdAt DESC').all();
  res.json(messages);
});

app.put('/api/messages/:id/read', (req, res) => {
  try {
    db.prepare('UPDATE messages SET isRead = 1 WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/messages/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM messages WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Service Requests
app.post('/api/service_requests', async (req, res) => {
  try {
    const { name, email, projectType, message } = req.body;
    const stmt = db.prepare('INSERT INTO service_requests (name, email, projectType, message) VALUES (?, ?, ?, ?)');
    stmt.run(name, email, projectType, message);
    
    // Attempt to send email
    let emailSent = false;
    try {
      if (process.env.GMAIL_APP_PASSWORD) {
        await transporter.sendMail({
          from: `"Emmanuel Oyeyinka" <${process.env.GMAIL_USER || 'meritoe74@gmail.com'}>`,
          to: 'meritoe74@gmail.com',
          replyTo: email,
          subject: `Service Request: ${projectType} - from ${name}`,
          html: `
            <h2>New Service Request</h2>
            <p><strong>Sender Name:</strong> ${name}</p>
            <p><strong>Sender Email:</strong> ${email}</p>
            <p><strong>Service Type:</strong> ${projectType}</p>
            <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
            <hr />
            <h3>Project Brief / Message:</h3>
            <p style="white-space: pre-wrap;">${message}</p>
          `
        });
        emailSent = true;
      } else {
        console.warn('GMAIL_APP_PASSWORD is not set. Email notification skipped.');
      }
    } catch (emailErr) {
      console.error('Email delivery failed:', emailErr);
      if (process.env.GMAIL_APP_PASSWORD) {
        throw new Error('Email delivery failed. Please check SMTP credentials.');
      }
    }

    res.json({ success: true, emailSent });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/service_requests', (req, res) => {
  try {
    const requests = db.prepare('SELECT * FROM service_requests ORDER BY createdAt DESC').all();
    res.json(requests);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/service_requests/:id/read', (req, res) => {
  try {
    db.prepare('UPDATE service_requests SET isRead = 1 WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/service_requests/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM service_requests WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/service_requests/:id/status', (req, res) => {
  try {
    const { status } = req.body;
    db.prepare('UPDATE service_requests SET status = ? WHERE id = ?').run(status, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Uploads
app.get('/api/uploads', (req, res) => {
  try {
    const media = db.prepare('SELECT * FROM media ORDER BY createdAt DESC').all();
    // Also scan fs just in case some files exist but not in DB
    const files = fs.readdirSync(uploadsDir).filter(f => f !== '.gitkeep');
    // For simplicity, we just return DB records
    res.json(media);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  const url = `/uploads/${req.file.filename}`;
  const section = req.body.section || 'General';
  
  try {
    const stmt = db.prepare('INSERT INTO media (filename, originalName, url, size, section) VALUES (?, ?, ?, ?, ?)');
    const info = stmt.run(req.file.filename, req.file.originalname, url, req.file.size, section);
    
    // Return the public URL and DB info
    res.json({ 
      id: info.lastInsertRowid,
      url: url, 
      originalname: req.file.originalname, 
      size: req.file.size,
      section: section
    });
  } catch (err: any) {
     res.status(500).json({ error: err.message });
  }
});

app.put('/api/uploads/:id', (req, res) => {
  try {
    const { section } = req.body;
    const stmt = db.prepare('UPDATE media SET section = ? WHERE id = ?');
    stmt.run(section, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/uploads/:id', (req, res) => {
  try {
    const media = db.prepare('SELECT * FROM media WHERE id = ?').get(req.params.id) as any;
    if (media) {
      const filePath = path.join(uploadsDir, media.filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      db.prepare('DELETE FROM media WHERE id = ?').run(req.params.id);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'File not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Testimonials
app.get('/api/testimonials', (req, res) => {
  const testimonials = db.prepare('SELECT * FROM testimonials ORDER BY createdAt DESC').all();
  res.json(testimonials);
});

app.post('/api/testimonials', (req, res) => {
  try {
    const { name, role, content, rating, imageUrl } = req.body;
    const stmt = db.prepare('INSERT INTO testimonials (name, role, content, rating, imageUrl) VALUES (?, ?, ?, ?, ?)');
    const info = stmt.run(name, role, content, rating, imageUrl);
    res.status(201).json({ id: info.lastInsertRowid, success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/testimonials/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM testimonials WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Settings
app.get('/api/settings', (req, res) => {
  const settings = db.prepare('SELECT * FROM settings').all();
  const settingsMap = settings.reduce((acc: any, curr: any) => ({ ...acc, [curr.key]: curr.value }), {});
  res.json(settingsMap);
});

app.post('/api/settings', (req, res) => {
  try {
    const { key, value } = req.body;
    const stmt = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    stmt.run(key, value);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Services
app.get('/api/services', (req, res) => {
  try {
    const services = db.prepare('SELECT * FROM services').all();
    const formatted = services.map((s: any) => ({
      ...s,
      images: s.images ? JSON.parse(s.images) : [],
      folders: s.folders ? JSON.parse(s.folders) : []
    }));
    res.json(formatted);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/services/:slug', (req, res) => {
  try {
    const service = db.prepare('SELECT * FROM services WHERE slug = ?').get(req.params.slug) as any;
    if (service) {
      res.json({
        ...service,
        images: service.images ? JSON.parse(service.images) : [],
        folders: service.folders ? JSON.parse(service.folders) : []
      });
    } else {
      res.status(404).json({ error: 'Service not found' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/services/:id', (req, res) => {
  try {
    const { title, slug, icon, desc, longDesc, images, folders } = req.body;
    const stmt = db.prepare('UPDATE services SET title=?, slug=?, icon=?, desc=?, longDesc=?, images=?, folders=? WHERE id=?');
    stmt.run(title, slug, icon, desc, longDesc, JSON.stringify(images || []), JSON.stringify(folders || []), req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/services', (req, res) => {
  try {
    const { title, slug, icon, desc, longDesc, images, folders } = req.body;
    const stmt = db.prepare('INSERT INTO services (title, slug, icon, desc, longDesc, images, folders) VALUES (?, ?, ?, ?, ?, ?, ?)');
    const info = stmt.run(title, slug, icon, desc, longDesc, JSON.stringify(images || []), JSON.stringify(folders || []));
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/services/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM services WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Vite middleware & SPA fallback
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
