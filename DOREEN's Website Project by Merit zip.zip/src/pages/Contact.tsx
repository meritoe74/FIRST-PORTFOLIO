import { useState, ChangeEvent, FormEvent } from 'react';
import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const accessKey = import.meta.env.VITE_WEB3FORMS_ACCESS_KEY;
    
    if (!accessKey || accessKey === "YOUR_WEB3FORMS_ACCESS_KEY") {
      alert("Email sending is not fully configured yet. Please configure VITE_WEB3FORMS_ACCESS_KEY in the environment variables, or use the WhatsApp option or Email link directly.");
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          access_key: accessKey,
          subject: `New Contact Request from ${formData.name}`,
          from_name: "Peculiar Lifestyle Limited Website",
          name: formData.name,
          email: formData.email,
          phone: formData.phone || "Not provided",
          message: formData.message,
        })
      });

      const result = await response.json();
      
      if (result.success) {
        setIsSubmitted(true);
        setFormData({ name: '', email: '', phone: '', message: '' });
      } else {
        alert("Something went wrong while sending your request. Please try again.");
      }
    } catch (error) {
      console.error(error);
      alert("A network error occurred. Please try again or use our direct email.");
    } finally {
      setIsSubmitting(false);
    }
  };
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Contact Us" 
        description="Get in touch with Peculiar Lifestyle Limited for premium home management services in Lagos, Nigeria." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Get In Touch
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            We are here to help you reclaim your balance. Let us know how we can serve you.
          </motion.p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white p-6 md:p-10 rounded-2xl shadow-sm border border-gray-100 text-center"
            >
              <div className="w-12 h-12 md:w-16 md:h-16 bg-emerald/5 rounded-full flex items-center justify-center mx-auto mb-4 md:mb-6 text-emerald">
                <Phone className="w-6 h-6 md:w-8 md:h-8" />
              </div>
              <h3 className="font-serif font-bold text-xl md:text-2xl text-gray-900 mb-3 md:mb-4">Phone</h3>
              <p className="text-sm md:text-base text-gray-600 mb-6">Available Monday - Saturday<br/>8:00 AM - 6:00 PM</p>
              <a href="tel:+2347084639368" className="inline-block bg-cream text-emerald font-semibold py-3 px-6 rounded-full hover:bg-emerald hover:text-white transition-all w-full text-sm md:text-base">
                +2347084639368
              </a>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white p-6 md:p-10 rounded-2xl shadow-sm border border-gray-100 text-center"
            >
              <div className="w-12 h-12 md:w-16 md:h-16 bg-emerald/5 rounded-full flex items-center justify-center mx-auto mb-4 md:mb-6 text-emerald">
                <Mail className="w-6 h-6 md:w-8 md:h-8" />
              </div>
              <h3 className="font-serif font-bold text-xl md:text-2xl text-gray-900 mb-3 md:mb-4">Email</h3>
              <p className="text-sm md:text-base text-gray-600 mb-6">Send us a message anytime.<br/>We usually reply within 2 hours.</p>
              <a href="mailto:peculiardee247@gmail.com" className="inline-block bg-cream text-emerald font-semibold py-3 px-6 rounded-full hover:bg-emerald hover:text-white transition-all w-full text-sm md:text-base">
                Email Us
              </a>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white p-6 md:p-10 rounded-2xl shadow-sm border border-gray-100 text-center"
            >
              <div className="w-12 h-12 md:w-16 md:h-16 bg-emerald/5 rounded-full flex items-center justify-center mx-auto mb-4 md:mb-6 text-emerald">
                <MapPin className="w-6 h-6 md:w-8 md:h-8" />
              </div>
              <h3 className="font-serif font-bold text-xl md:text-2xl text-gray-900 mb-3 md:mb-4">Location</h3>
              <p className="text-sm md:text-base text-gray-600 mb-6">Proudly serving premium residences across Lagos and environments.</p>
              <div className="inline-block bg-cream text-gray-700 font-semibold py-3 px-6 rounded-full w-full text-sm md:text-base">
                Lagos, Nigeria
              </div>
            </motion.div>
          </div>

          {/* Contact Form Section */}
          <div className="mt-16 md:mt-24 max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
            <div className="p-6 md:p-12">
              <div className="text-center mb-8 md:mb-10">
                <h2 className="text-2xl md:text-3xl font-serif font-bold text-gray-900 mb-3 md:mb-4">Send Us a Message</h2>
                <p className="text-gray-600">Have a question or specific request? Fill out the form below and our team will get back to you promptly.</p>
              </div>

              {isSubmitted ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-cream rounded-2xl p-8 py-16 text-center border border-emerald/10"
                >
                  <div className="w-20 h-20 bg-emerald/10 text-emerald rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-gray-900 mb-2">Message Sent Successfully!</h3>
                  <p className="text-gray-600 mb-6 max-w-md mx-auto">
                    Thank you for reaching out to Peculiar Lifestyle Limited. We have received your message and will be in touch shortly.
                  </p>
                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="bg-emerald text-white px-8 py-3 rounded-full hover:bg-emerald-light transition-colors font-semibold"
                  >
                    Send Another Message
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">Your Name *</label>
                      <input 
                        type="text" 
                        id="name" 
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">Email Address *</label>
                      <input 
                        type="email" 
                        id="email" 
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
                    <input 
                      type="tel" 
                      id="phone" 
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                      placeholder="Optional"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">Your Message *</label>
                    <textarea 
                      id="message" 
                      name="message"
                      rows={5}
                      required
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors resize-none"
                      placeholder="How can we help you today?"
                    ></textarea>
                  </div>

                  <div className="pt-4 text-center">
                    <button 
                      type="submit" 
                      disabled={isSubmitting}
                      className={`inline-flex items-center justify-center bg-emerald hover:bg-emerald-light text-white px-10 py-4 rounded-full font-semibold transition-all shadow-md hover:shadow-lg w-full md:w-auto ${isSubmitting ? 'opacity-75 cursor-not-allowed' : ''}`}
                    >
                      {isSubmitting ? 'Sending...' : (
                        <>
                          Send Message <Send className="ml-2 w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
