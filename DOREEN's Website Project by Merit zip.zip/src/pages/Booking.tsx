import { useState, ChangeEvent, FormEvent } from 'react';
import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { useSearchParams } from 'react-router-dom';

export default function Booking() {
  const [searchParams] = useSearchParams();
  const preselectedService = searchParams.get('service') || '';

  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    service: preselectedService,
    date: '',
    time: '',
    address: '',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const servicesList = [
    "Residential Deep Cleaning",
    "Recurring Home Upkeep",
    "Move-In/Move-Out Cleaning",
    "Specialized Floor Care",
    "Post-Construction Cleanup",
    "Special Event Cleaning",
    "Custom Grocery Sourcing",
    "Specialist Food Items",
    "Bulk Purchase Handling",
    "Other/Custom Service"
  ];

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Check if the Web3Forms access key is configured in the environment
    const accessKey = import.meta.env.VITE_WEB3FORMS_ACCESS_KEY;
    
    if (!accessKey || accessKey === "YOUR_WEB3FORMS_ACCESS_KEY") {
      alert("Email sending is not fully configured yet. Please configure VITE_WEB3FORMS_ACCESS_KEY in the environment variables, or use the WhatsApp option below.");
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          access_key: accessKey,
          subject: `New Booking Request from ${formData.fullName}`,
          from_name: "Peculiar Lifestyle Limited Website",
          name: formData.fullName,
          phone: formData.phone,
          email: formData.email,
          service: formData.service,
          date: formData.date || "Not specified",
          time: formData.time || "Not specified",
          address: formData.address,
          message: `Notes: ${formData.notes || 'None'}`, // Web3Forms looks for a "message" field
        })
      });

      const result = await response.json();
      
      if (result.success) {
        setIsSubmitted(true);
      } else {
        alert("Something went wrong while sending your request. Please try the WhatsApp option.");
      }
    } catch (error) {
      console.error(error);
      alert("A network error occurred. Please try again or use the WhatsApp option.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const generateWhatsAppLink = () => {
    const text = `Hello Peculiar Lifestyle! I would like to book a service.%0A%0A*Name:* ${formData.fullName || '[Your Name]'}%0A*Service:* ${formData.service || '[Selected Service]'}%0A*Phone:* ${formData.phone}%0A*Date:* ${formData.date}%0A*Time:* ${formData.time}%0A*Address:* ${formData.address}%0A*Notes:* ${formData.notes}`;
    return `https://wa.me/2347084639368?text=${text}`;
  };

  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Book A Service" 
        description="Book premium cleaning and home management services with Peculiar Lifestyle Limited." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Book A Service
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            Take the first step towards reclaiming your time.
          </motion.p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {isSubmitted ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-3xl p-12 text-center shadow-xl border border-gray-100"
            >
              <div className="w-24 h-24 bg-emerald/10 text-emerald rounded-full flex items-center justify-center mx-auto mb-8">
                <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
              </div>
              <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">Request Received</h2>
              <p className="text-xl text-gray-600 mb-8 max-w-lg mx-auto">
                Thank you for choosing Peculiar Lifestyle Limited. Our team will contact you shortly to confirm your booking details.
              </p>
              <button 
                onClick={() => setIsSubmitted(false)}
                className="bg-emerald text-white px-8 py-3 rounded-full hover:bg-emerald-light transition-colors font-semibold"
              >
                Book Another Service
              </button>
            </motion.div>
          ) : (
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
              <div className="p-8 md:p-12">
                <h2 className="text-2xl font-serif font-bold text-gray-900 mb-8 border-b border-gray-100 pb-4">Booking Details</h2>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-semibold text-gray-700 mb-2">Full Name *</label>
                      <input 
                        type="text" 
                        id="fullName" 
                        name="fullName"
                        required
                        value={formData.fullName}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                        placeholder="e.g. Adebayo Johnson"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">Phone Number *</label>
                      <input 
                        type="tel" 
                        id="phone" 
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                        placeholder="e.g. 08012345678"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">Email Address *</label>
                      <input 
                        type="email" 
                        id="email" 
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                        placeholder="your@email.com"
                      />
                    </div>
                    <div>
                      <label htmlFor="service" className="block text-sm font-semibold text-gray-700 mb-2">Service Needed *</label>
                      <select 
                        id="service" 
                        name="service"
                        required
                        value={formData.service}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                      >
                        <option value="" disabled>Select a service</option>
                        {servicesList.map((srv, idx) => (
                          <option key={idx} value={srv}>{srv}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="date" className="block text-sm font-semibold text-gray-700 mb-2">Preferred Date</label>
                      <input 
                        type="date" 
                        id="date" 
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                      />
                    </div>
                    <div>
                      <label htmlFor="time" className="block text-sm font-semibold text-gray-700 mb-2">Preferred Time</label>
                      <input 
                        type="time" 
                        id="time" 
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="address" className="block text-sm font-semibold text-gray-700 mb-2">Service Address *</label>
                    <input 
                      type="text" 
                      id="address" 
                      name="address"
                      required
                      value={formData.address}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors"
                      placeholder="Full street address in Lagos"
                    />
                  </div>

                  <div>
                    <label htmlFor="notes" className="block text-sm font-semibold text-gray-700 mb-2">Additional Notes</label>
                    <textarea 
                      id="notes" 
                      name="notes"
                      rows={4}
                      value={formData.notes}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald/50 focus:border-emerald transition-colors resize-none"
                      placeholder="Any specific requests, home access details, or allergies we should know about?"
                    ></textarea>
                  </div>

                  <div className="pt-4 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <p className="text-sm text-gray-500">* Required fields</p>
                    <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                      <a 
                        href={generateWhatsAppLink()}
                        target="_blank"
                        rel="noreferrer"
                        className="bg-[#25D366]/10 text-[#25D366] hover:bg-[#25D366] hover:text-white px-8 py-4 rounded-full font-semibold transition-all border border-[#25D366]/30 text-center flex-1 sm:flex-none"
                      >
                        Book via WhatsApp
                      </a>
                      <button 
                        type="submit" 
                        disabled={isSubmitting}
                        className={`bg-emerald hover:bg-emerald-light text-white px-10 py-4 rounded-full font-semibold transition-all shadow-md hover:shadow-lg flex items-center justify-center flex-1 sm:flex-none ${isSubmitting ? 'opacity-75 cursor-not-allowed' : ''}`}
                      >
                        {isSubmitting ? 'Submitting...' : 'Submit Request'}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
