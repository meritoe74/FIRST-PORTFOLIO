export function Footer() {
  return (
    <footer className="bg-emerald border-t border-emerald-light/20 text-white pt-16 pb-8 overflow-hidden relative">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[5%] w-64 h-64 bg-emerald-light/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[20%] -right-[5%] w-80 h-80 bg-gold/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-12 lg:col-span-4 flex flex-col items-start text-left space-y-6">
            <div className="inline-block p-1 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 shadow-lg">
              <img 
                src="https://i.ibb.co/C5BLXPQs/Chat-GPT-Image-Jun-22-2026-09-02-16-PM.png" 
                alt="Peculiar Lifestyle Limited" 
                className="h-12 w-auto bg-white p-2 rounded-lg" 
              />
            </div>
            <p className="text-emerald-100/90 text-[15px] leading-relaxed max-w-sm font-medium">
              All-In-One Home Management.<br/>
              Your Balance, Restored.<br/>
              We master the chores so you can reclaim your time.
            </p>
            <div className="flex space-x-3 pt-2 text-emerald-900">
              {/* Social placeholders with styling */}
              {['FB', 'IG', 'TK', 'IN', 'X'].map((social) => (
                <a key={social} href="#" className="w-9 h-9 rounded-full bg-gold hover:bg-white hover:-translate-y-1 flex items-center justify-center font-bold text-[11px] transition-all duration-300 shadow-md">
                  {social}
                </a>
              ))}
            </div>
          </div>

          {/* Links Grid */}
          <div className="md:col-span-12 lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 border-t border-emerald-light/30 pt-10 lg:border-none lg:pt-0">
            {/* Quick Links */}
            <div className="space-y-6">
              <h3 className="font-serif font-semibold text-lg text-gold flex items-center gap-3">
                <span className="w-8 h-[2px] bg-gold/50 rounded-full"></span> Quick Links
              </h3>
              <ul className="space-y-4">
                {['Home', 'About Us', 'Services', 'Pricing', 'Gallery', 'Testimonials', 'FAQ'].map((link) => (
                  <li key={link}>
                    <a href={link === 'Home' ? '/' : `/${link.toLowerCase().replace(' ', '-')}`} className="text-emerald-50 hover:text-white hover:translate-x-1.5 inline-flex transition-all duration-300 text-sm font-medium">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div className="space-y-6">
              <h3 className="font-serif font-semibold text-lg text-gold flex items-center gap-3">
                <span className="w-8 h-[2px] bg-gold/50 rounded-full"></span> Services
              </h3>
              <ul className="space-y-4 shadow-sm pb-1">
                {['Premium Cleaning', 'Efficient Market Runs', 'Move-In/Move-Out', 'Special Events', 'Post-Construction'].map((service) => (
                  <li key={service}>
                    <span className="text-emerald-50 text-sm font-medium cursor-default hover:text-white transition-colors duration-300">{service}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div className="space-y-6 sm:col-span-2 md:col-span-1 pt-4 sm:pt-0 border-t border-emerald-light/20 sm:border-none">
              <h3 className="font-serif font-semibold text-lg text-gold flex items-center gap-3 mt-4 sm:mt-0">
                <span className="w-8 h-[2px] bg-gold/50 rounded-full"></span> Contact
              </h3>
              <address className="not-italic space-y-5 text-[15px] text-emerald-50">
                <p className="flex items-start gap-3 group">
                  <span className="text-gold mt-0.5 text-lg leading-none">📍</span> 
                  <span className="group-hover:text-white transition-colors leading-snug">Lagos, Nigeria</span>
                </p>
                <p className="flex items-start gap-3 group">
                  <span className="text-gold mt-0.5 text-lg leading-none">📞</span> 
                  <a href="tel:+2347084639368" className="group-hover:text-white font-medium transition-colors leading-snug">+234 708 463 9368</a>
                </p>
                <p className="flex items-start gap-3 group">
                  <span className="text-gold mt-0.5 text-lg leading-none">✉️</span> 
                  <a href="mailto:peculiardee247@gmail.com" className="group-hover:text-white font-medium transition-colors break-all leading-snug">peculiardee247@gmail.com</a>
                </p>
              </address>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-emerald-light/30 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-emerald-200">
          <p className="text-center md:text-left font-medium tracking-wide">&copy; {new Date().getFullYear()} Peculiar Lifestyle Limited. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white font-medium transition-colors relative after:content-[''] after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-[1px] after:bg-white hover:after:w-full after:transition-all">Privacy Policy</a>
            <a href="#" className="hover:text-white font-medium transition-colors relative after:content-[''] after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-[1px] after:bg-white hover:after:w-full after:transition-all">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
