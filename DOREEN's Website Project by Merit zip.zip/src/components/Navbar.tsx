import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const desktopNavLinks = [
  { name: 'Home', path: '/' },
  { name: 'About Us', path: '/about' },
  { name: 'Services', path: '/services' },
  { name: 'Pricing', path: '/pricing' },
  { name: 'Gallery', path: '/gallery' },
  { name: 'Testimonials', path: '/testimonials' },
  { name: 'FAQ', path: '/faq' },
  { name: 'Contact Us', path: '/contact' },
];

const mobileVisibleLinks = [
  { name: 'Home', path: '/' },
  { name: 'About Us', path: '/about' },
  { name: 'Services', path: '/services' },
  { name: 'Pricing', path: '/pricing' },
];

const mobileMenuLinks = [
  { name: 'Gallery', path: '/gallery' },
  { name: 'Testimonials', path: '/testimonials' },
  { name: 'FAQ', path: '/faq' },
  { name: 'Contact Us', path: '/contact' },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <nav className="fixed w-full z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-row justify-between items-center h-16 md:h-20">
          
          {/* Logo and Nav Links Container */}
          <div className="flex items-center flex-1 overflow-x-auto hide-scrollbar py-2 md:py-0 pr-4">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 md:gap-3 flex-shrink-0 mr-6 md:mr-8">
              <img src="https://i.ibb.co/C5BLXPQs/Chat-GPT-Image-Jun-22-2026-09-02-16-PM.png" alt="Peculiar Lifestyle Limited" className="h-9 md:h-12 w-auto" />
              <span className="font-serif font-bold text-[15px] md:text-xl text-emerald leading-tight">
                Peculiar<br />Lifestyle
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-5 lg:space-x-6 flex-shrink-0 align-middle">
              {desktopNavLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`text-sm font-medium transition-colors hover:text-gold ${
                    location.pathname === link.path ? 'text-gold' : 'text-gray-600'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Mobile Visible Navigation */}
            <div className="flex md:hidden items-center space-x-4 flex-shrink-0 align-middle">
              {mobileVisibleLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`text-[13.5px] font-medium whitespace-nowrap transition-colors ${
                    location.pathname === link.path ? 'text-gold' : 'text-gray-600'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-3 flex-shrink-0 pl-2">
            {/* Book Now Button (Desktop) */}
            <Link
              to="/book"
              className="hidden md:flex bg-emerald hover:bg-emerald-light text-white px-5 py-2 rounded-full text-sm font-medium transition-all shadow-md hover:shadow-lg shrink-0"
            >
              Book Now
            </Link>
            
            {/* Book Button (Mobile) */}
            <Link
              to="/book"
              className="md:hidden bg-emerald hover:bg-emerald-light text-white px-4 py-1.5 rounded-full text-[13px] font-medium transition-all shadow-sm shrink-0"
            >
              Book
            </Link>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden text-gray-600 hover:text-emerald focus:outline-none p-1"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Hamburger Menu Form */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-100 overflow-hidden"
          >
            <div className="px-4 py-3 space-y-1">
              {mobileMenuLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`block px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'text-gold bg-cream/50'
                      : 'text-gray-600 hover:text-emerald hover:bg-gray-50'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
