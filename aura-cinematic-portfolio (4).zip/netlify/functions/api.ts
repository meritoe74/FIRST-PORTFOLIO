import serverless from 'serverless-http';
import { app } from '../../dist/server.cjs'; // the new API backend

export const handler = serverless(app);
