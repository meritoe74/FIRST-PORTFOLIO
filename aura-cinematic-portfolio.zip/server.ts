import express from 'express';
import path from 'path';
import multer from 'multer';
import Database from 'better-sqlite3';
import fs from 'fs';
import nodemailer from 'nodemailer';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Set up uploads directory
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer config for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// Provide uploads folder as static
app.use('/uploads', express.static(uploadsDir));

// Initialize SQLite DB
const dbFile = path.join(process.cwd(), 'portfolio.db');
const db = new Database(dbFile);

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    categoryId INTEGER NOT NULL,
    description TEXT,
    excerpt TEXT,
    imageUrl TEXT,
    tools TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(categoryId) REFERENCES categories(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT DEFAULT '',
    message TEXT NOT NULL,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS service_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    projectType TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

// Seed data if empty
try {
  db.exec('ALTER TABLE messages ADD COLUMN subject TEXT DEFAULT ""');
} catch (e) {
  // Ignore if column already exists
}

const countCats = db.prepare('SELECT COUNT(*) as count FROM categories').get() as { count: number };
if (countCats.count === 0) {
  const insertCat = db.prepare('INSERT INTO categories (name, slug) VALUES (?, ?)');
  insertCat.run('Branding', 'branding');
  insertCat.run('UI/UX Concepts', 'ui-ux-concepts');
  insertCat.run('Social Media', 'social-media');
  insertCat.run('Logos', 'logos');

  const insertProj = db.prepare('INSERT INTO projects (title, slug, categoryId, description, excerpt, imageUrl, tools) VALUES (?, ?, ?, ?, ?, ?, ?)');
  insertProj.run(
    'Cosmic Brand Identity', 'cosmic-brand', 1, 
    'A complete brand overhaul for a futuristic tech startup.', 
    'Futuristic aesthetic branding', 
    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop', 
    'Illustrator, Photoshop, Figma'
  );
  insertProj.run(
    'Oasis UI Concept', 'oasis-ui', 2, 
    'Minimalist and clean UI kit for a wellness application.', 
    'Wellness app UI Concept', 
    'https://images.unsplash.com/photo-1541462608143-67571c6738dd?q=80&w=2000&auto=format&fit=crop', 
    'Figma, Framer'
  );
  insertProj.run(
    'Neon Social Kit', 'neon-social', 3, 
    'Vibrant social media templates for an emerging music label.', 
    'Music label social media graphics', 
    'https://images.unsplash.com/photo-1557672172-298e090bd0f1?q=80&w=2000&auto=format&fit=crop', 
    'Photoshop, After Effects'
  );
}

// API Routes

// Categories
app.get('/api/categories', (req, res) => {
  const categories = db.prepare('SELECT * FROM categories').all();
  res.json(categories);
});

// Projects
app.get('/api/projects', (req, res) => {
  const { categorySlug } = req.query;
  if (categorySlug) {
    const projects = db.prepare(`
      SELECT p.*, c.name as categoryName, c.slug as categorySlug 
      FROM projects p 
      JOIN categories c ON p.categoryId = c.id 
      WHERE c.slug = ?
      ORDER BY p.createdAt DESC
    `).all(categorySlug);
    res.json(projects);
  } else {
    const projects = db.prepare(`
      SELECT p.*, c.name as categoryName, c.slug as categorySlug 
      FROM projects p 
      JOIN categories c ON p.categoryId = c.id
      ORDER BY p.createdAt DESC
    `).all();
    res.json(projects);
  }
});

app.get('/api/projects/:slug', (req, res) => {
  const project = db.prepare(`
    SELECT p.*, c.name as categoryName, c.slug as categorySlug 
    FROM projects p 
    JOIN categories c ON p.categoryId = c.id 
    WHERE p.slug = ?
  `).get(req.params.slug);
  
  if (project) {
    res.json(project);
  } else {
    res.status(404).json({ error: 'Project not found' });
  }
});

app.post('/api/projects', (req, res) => {
  try {
    const { title, slug, categoryId, description, excerpt, imageUrl, tools } = req.body;
    const stmt = db.prepare('INSERT INTO projects (title, slug, categoryId, description, excerpt, imageUrl, tools) VALUES (?, ?, ?, ?, ?, ?, ?)');
    const info = stmt.run(title, slug, categoryId, description, excerpt, imageUrl, tools);
    res.status(201).json({ id: info.lastInsertRowid, success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/projects/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM projects WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Contact
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER || 'meritoe74@gmail.com',
    pass: process.env.GMAIL_APP_PASSWORD || ''
  }
});

app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    const stmt = db.prepare('INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)');
    stmt.run(name, email, subject || '', message);
    
    // Attempt to send email
    try {
      if (process.env.GMAIL_APP_PASSWORD) {
        await transporter.sendMail({
          from: process.env.GMAIL_USER || 'meritoe74@gmail.com',
          to: 'meritoe74@gmail.com',
          subject: `New Contact Form Submission: ${subject || 'No Subject'} - from ${name}`,
          html: `
            <h3>New Message from ${name}</h3>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Subject:</strong> ${subject || 'N/A'}</p>
            <hr />
            <p>${message}</p>
          `
        });
      }
    } catch (emailErr) {
      console.error('Email delivery failed:', emailErr);
      // We still return success as the message is saved in the database
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/messages', (req, res) => {
  const messages = db.prepare('SELECT * FROM messages ORDER BY createdAt DESC').all();
  res.json(messages);
});

app.delete('/api/messages/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM messages WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Service Requests
app.post('/api/service_requests', async (req, res) => {
  try {
    const { name, email, projectType, message } = req.body;
    const stmt = db.prepare('INSERT INTO service_requests (name, email, projectType, message) VALUES (?, ?, ?, ?)');
    stmt.run(name, email, projectType, message);
    
    // Attempt to send email
    try {
      if (process.env.GMAIL_APP_PASSWORD) {
        await transporter.sendMail({
          from: process.env.GMAIL_USER || 'meritoe74@gmail.com',
          to: 'meritoe74@gmail.com',
          subject: `Service Request: ${projectType} - from ${name}`,
          html: `
            <h3>New Service Request from ${name}</h3>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Service Type:</strong> ${projectType}</p>
            <hr />
            <p>${message}</p>
          `
        });
      }
    } catch (emailErr) {
      console.error('Email delivery failed:', emailErr);
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/service_requests', (req, res) => {
  try {
    const requests = db.prepare('SELECT * FROM service_requests ORDER BY createdAt DESC').all();
    res.json(requests);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/service_requests/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM service_requests WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/service_requests/:id/status', (req, res) => {
  try {
    const { status } = req.body;
    db.prepare('UPDATE service_requests SET status = ? WHERE id = ?').run(status, req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Uploads
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  // Return the public URL for the file
  res.json({ url: `/uploads/${req.file.filename}`, originalname: req.file.originalname });
});

// Settings
app.get('/api/settings', (req, res) => {
  const settings = db.prepare('SELECT * FROM settings').all();
  const settingsMap = settings.reduce((acc: any, curr: any) => ({ ...acc, [curr.key]: curr.value }), {});
  res.json(settingsMap);
});

app.post('/api/settings', (req, res) => {
  try {
    const { key, value } = req.body;
    const stmt = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    stmt.run(key, value);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Vite middleware & SPA fallback
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
