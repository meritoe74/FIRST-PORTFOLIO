export interface Project {
  id: number;
  title: string;
  slug: string;
  categoryId: number;
  categoryName?: string;
  categorySlug?: string;
  description: string;
  excerpt: string;
  imageUrl: string;
  tools: string;
  createdAt: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
}

export interface Message {
  id: number;
  name: string;
  email: string;
  message: string;
  createdAt: string;
}
