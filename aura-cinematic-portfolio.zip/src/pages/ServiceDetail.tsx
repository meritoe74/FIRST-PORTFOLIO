import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { servicesData } from '../data/servicesData';
import { ArrowLeft } from 'lucide-react';

const LogoGallery = ({ folders, images }: { folders?: any[], images?: string[] }) => {
  return (
    <div className="flex flex-col gap-16 w-full overflow-hidden -mx-6 px-6 lg:-mx-12 lg:px-12 py-10 rounded-3xl bg-black/20 backdrop-blur-sm border border-white/5 relative">
      <div className="absolute inset-0 bg-accent/5 rounded-3xl mix-blend-overlay pointer-events-none" />
      
      {folders?.map((folder, fIdx) => {
         const items = [...folder.images, ...folder.images, ...folder.images, ...folder.images];
         
         return (
         <div key={fIdx} className="w-full relative">
            <h3 className="text-xl font-poppins font-medium text-gray-200 mb-8 flex items-center gap-3">
               <span className="w-12 h-px bg-accent"></span> {folder.name}
            </h3>
            
            <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-primary to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-primary to-transparent z-10 pointer-events-none" />

            <div className="flex w-[400vw] sm:w-[300vw] md:w-[200vw]">
                <div className={`flex w-full ${fIdx % 2 === 0 ? 'animate-marquee' : 'animate-marquee-reverse'} gap-8 hover:[animation-play-state:paused]`}>
                  {items.map((img, i) => (
                    <div key={i} className="flex-shrink-0 w-64 md:w-80 h-64 md:h-80 glass-card rounded-2xl p-6 group relative overflow-hidden flex items-center justify-center transition-all duration-500 hover:shadow-[0_0_50px_rgba(124,77,255,0.4)] hover:-translate-y-2 cursor-pointer border border-white/10 hover:border-accent/50 bg-white/[0.03]">
                       <div className="absolute inset-0 bg-gradient-to-b from-accent/20 to-transparent mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                       <img src={img} alt="Logo" className="w-full h-full object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] group-hover:scale-110 transition-transform duration-700 ease-out z-10" />
                    </div>
                  ))}
                </div>
            </div>
         </div>
       )})}

      {(!folders || folders.length === 0) && images && images.length > 0 && (
         <div className="w-full relative">
            <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-primary to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-primary to-transparent z-10 pointer-events-none" />

            <div className="flex w-[400vw] sm:w-[300vw] md:w-[200vw]">
                <div className="flex w-full animate-marquee gap-8 hover:[animation-play-state:paused]">
                  {[...images, ...images, ...images, ...images].map((img, i) => (
                    <div key={i} className="flex-shrink-0 w-64 md:w-80 h-64 md:h-80 glass-card rounded-2xl p-6 group relative overflow-hidden flex items-center justify-center transition-all duration-500 hover:shadow-[0_0_50px_rgba(124,77,255,0.4)] hover:-translate-y-2 cursor-pointer border border-white/10 hover:border-accent/50 bg-white/[0.03]">
                       <div className="absolute inset-0 bg-gradient-to-b from-accent/20 to-transparent mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                       <img src={img} alt="Logo" className="w-full h-full object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] group-hover:scale-110 transition-transform duration-700 ease-out z-10" />
                    </div>
                  ))}
                </div>
            </div>
         </div>
      )}
    </div>
  )
}

const PhotographyGallery = ({ images }: { images?: string[] }) => {
  const items = images ? [...images, ...images, ...images, ...images] : [];
  
  return (
    <div className="w-full relative overflow-hidden py-16 -mx-6 px-6 lg:-mx-12 lg:px-12 bg-[#050A15]">
       <div className="absolute left-0 top-0 bottom-0 w-32 md:w-64 bg-gradient-to-r from-primary to-transparent z-20 pointer-events-none" />
       <div className="absolute right-0 top-0 bottom-0 w-32 md:w-64 bg-gradient-to-l from-primary to-transparent z-20 pointer-events-none" />
       
       <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
       <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-accent/30 to-transparent" />

       <div className="flex w-[600vw] md:w-[400vw]">
         <div className="flex w-full animate-marquee-slow gap-12 sm:gap-24 items-center">
            {items.map((img, i) => {
              const yOffset = i % 2 === 0 ? '-translate-y-8' : 'translate-y-8';
              
              return (
              <div key={i} className={`flex-shrink-0 w-[40vw] sm:w-[500px] md:w-[700px] aspect-[16/10] rounded-sm group relative overflow-hidden ${yOffset} transition-all duration-1000 shadow-[0_20px_40px_rgba(0,0,0,0.4)]`}>
                 <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent transition-colors duration-1000 z-10" />
                 <img src={img} alt="Photography" className="w-[110%] h-full object-cover group-hover:scale-105 transition-transform duration-[1500ms] ease-[cubic-bezier(0.25,1,0.5,1)]" />
                 <div className="absolute inset-0 border border-white/10 z-20 pointer-events-none group-hover:border-white/30 transition-colors duration-1000" />
              </div>
            )})}
         </div>
       </div>
    </div>
  );
}

export default function ServiceDetail() {
  const { slug } = useParams();
  const service = servicesData.find(s => s.slug === slug);
  const [form, setForm] = useState({ name: '', email: '', projectType: service?.title || '', message: '' });
  const [status, setStatus] = useState('');

  if (!service) {
    return <div className="min-h-screen pt-32 px-6 text-center text-white">Service not found</div>;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('Sending...');
    try {
      const res = await fetch('/api/service_requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          projectType: form.projectType,
          message: form.message
        })
      });
      if (res.ok) {
        setStatus('Request sent successfully!');
        setForm({ ...form, name: '', email: '', message: '' });
      } else {
        setStatus('Failed to send. Try again.');
      }
    } catch (err) {
      setStatus('Failed to send. Try again.');
    }
  };

  return (
    <div className="w-full min-h-screen pt-32 pb-32 px-6 md:px-24 relative overflow-hidden bg-[#020617]">
      <div className="absolute inset-0 z-0 pointer-events-none opacity-40">
        <div className="absolute top-0 left-0 w-[40vw] h-[40vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-20 animate-[pulse_10s_ease-in-out_infinite]" />
        <div className="absolute bottom-0 right-0 w-[40vw] h-[40vw] bg-accent rounded-full mix-blend-screen filter blur-[250px] opacity-20 animate-[pulse_12s_ease-in-out_infinite_reverse]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <Link to="/services" className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-12 uppercase tracking-[0.2em] text-xs font-medium">
          <ArrowLeft size={16} /> Back to Services
        </Link>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-accent mb-8 shadow-[0_0_30px_rgba(124,77,255,0.2)]">
            {service.icon}
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-poppins font-bold tracking-tight mb-8 text-white">
            {service.title}
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light leading-relaxed max-w-4xl mb-16">
            {service.longDesc}
          </p>
        </motion.div>

        {/* Portfolio / Samples Section */}
        <div className="mb-24">
          <h2 className="text-2xl font-poppins font-semibold text-white mb-10">Showcase</h2>

          {service.slug === 'logo-design' ? (
             <LogoGallery folders={(service as any).folders} images={service.images} />
          ) : service.slug === 'photography' ? (
             <PhotographyGallery images={service.images} />
          ) : (
             <>
                {/* Render defined folders */}
                {(service as any).folders && (service as any).folders.map((folder: any, folderIdx: number) => (
                  <div key={`folder-${folderIdx}`} className="mb-16">
                    <h3 className="text-xl font-poppins font-medium text-gray-300 mb-6 flex items-center gap-3">
                      <span className="w-8 h-px bg-accent/50"></span> {folder.name}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                      {folder.images.map((img: string, idx: number) => (
                        <motion.div 
                          key={idx}
                          initial={{ opacity: 0, scale: 0.95 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8, delay: idx * 0.1 }}
                          className="rounded-3xl overflow-hidden border border-white/10 h-80 relative group"
                        >
                          <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 transition-opacity z-10 mix-blend-overlay" />
                          <img src={img} alt={`${folder.name} sample`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                        </motion.div>
                      ))}
                    </div>
                  </div>
                ))}

                {/* Render individual un-foldered images if any exist */}
                {service.images && service.images.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {service.images.map((img, idx) => (
                      <motion.div 
                        key={idx}
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8, delay: idx * 0.2 }}
                        className="rounded-3xl overflow-hidden border border-white/10 h-80 relative group"
                      >
                        <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 transition-opacity z-10 mix-blend-overlay" />
                        <img src={img} alt={`${service.title} sample`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                      </motion.div>
                    ))}
                  </div>
                )}
             </>
          )}
        </div>

        {/* Dedicated Request Form */}
        <motion.div
           initial={{ opacity: 0, y: 40 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           transition={{ duration: 0.8 }}
           className="bg-white/[0.02] border border-white/10 rounded-[2.5rem] p-10 backdrop-blur-2xl shadow-[0_16px_48px_rgba(0,0,0,0.2)] relative overflow-hidden max-w-4xl"
        >
          <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-accent/10 rounded-full blur-[100px] pointer-events-none" />
          
          <h2 className="text-3xl font-poppins font-semibold text-white mb-4 relative z-10">Request this Service</h2>
          <p className="text-gray-400 mb-10 relative z-10">Fill out the form below to inquire about our {service.title} services. We'll get back to you shortly.</p>
          
          <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Full Name</label>
                <input 
                  required
                  type="text" 
                  value={form.name}
                  onChange={e => setForm({...form, name: e.target.value})}
                  className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-3">
                <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Email Address</label>
                <input 
                  required
                  type="email" 
                  value={form.email}
                  onChange={e => setForm({...form, email: e.target.value})}
                  className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700"
                  placeholder="hello@example.com"
                />
              </div>
            </div>
            
            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Project Type</label>
              <input 
                readOnly
                type="text" 
                value={form.projectType}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-gray-500 cursor-not-allowed"
              />
            </div>

            <div className="space-y-3">
              <label className="text-xs tracking-[0.2em] uppercase text-gray-400 font-medium">Message / Brief Description</label>
              <textarea 
                required
                rows={4}
                value={form.message}
                onChange={e => setForm({...form, message: e.target.value})}
                className="w-full bg-transparent border-b border-white/20 pb-4 text-xl text-white focus:outline-none focus:border-accent transition-colors placeholder:text-gray-700 resize-none"
                placeholder="Tell us about your project goals..."
              />
            </div>

            <button 
              type="submit"
              className="group relative inline-flex items-center justify-center bg-white text-black px-10 py-5 rounded-full overflow-hidden w-full sm:w-auto"
            >
              <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-[0.16,1,0.3,1]" />
              <span className="relative z-10 text-xs font-bold uppercase tracking-[0.2em] group-hover:text-white transition-colors duration-500 delay-100 flex items-center gap-3">
                Submit Request <span className="text-lg leading-none">&rarr;</span>
              </span>
            </button>
            {status && <p className={`mt-4 text-sm ${status.includes('success') ? 'text-green-400' : 'text-accent'}`}>{status}</p>}
          </form>
        </motion.div>
      </div>
    </div>
  );
}
