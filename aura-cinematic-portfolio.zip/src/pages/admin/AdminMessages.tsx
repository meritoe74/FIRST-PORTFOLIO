import React, { useEffect, useState } from 'react';
import { Trash2, Mail, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}

export default function AdminMessages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = () => {
    setLoading(true);
    fetch('/api/messages')
      .then(res => res.json())
      .then(data => {
        setMessages(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  const deleteMessage = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this message?')) return;
    try {
      await fetch(`/api/messages/${id}`, { method: 'DELETE' });
      fetchMessages();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-10">
        <h1 className="text-3xl font-poppins font-medium tracking-tight mb-2">Messages</h1>
        <p className="text-gray-400">View and manage contact form submissions.</p>
      </div>

      <div className="bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden backdrop-blur-xl">
        {loading ? (
          <div className="p-10 text-center text-gray-400">Loading messages...</div>
        ) : messages.length === 0 ? (
          <div className="p-10 text-center flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-gray-500 mb-4">
              <Mail size={24} />
            </div>
            <p className="text-gray-400">No messages yet.</p>
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div 
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="p-6 md:p-8 hover:bg-white/[0.02] transition-colors group"
                >
                  <div className="flex flex-col md:flex-row gap-6 justify-between items-start">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-center gap-4 flex-wrap">
                        <h3 className="text-lg font-medium text-white">{msg.name}</h3>
                        <a href={`mailto:${msg.email}`} className="text-accent text-sm hover:underline">
                          {msg.email}
                        </a>
                        <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-white/5 px-2.5 py-1 rounded-md">
                          <Clock size={12} />
                          {new Date(msg.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      {msg.subject && (
                        <div className="text-sm font-medium text-gray-300">
                          Subject: {msg.subject}
                        </div>
                      )}
                      
                      <div className="bg-black/20 p-4 rounded-xl border border-white/5 text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
                        {msg.message}
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => deleteMessage(msg.id)}
                      className="w-10 h-10 rounded-full flex items-center justify-center text-gray-500 hover:text-red-400 hover:bg-red-400/10 transition-colors shrink-0 opacity-100 md:opacity-0 group-hover:opacity-100"
                      title="Delete Message"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
