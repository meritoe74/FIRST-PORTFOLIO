import React, { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, Image, Settings, LogOut, MessageSquare, Menu, Bell, Search, Plus, User, FileText, UploadCloud, BarChart2, Briefcase, Star, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminLayout() {
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="flex h-screen bg-[#070D18] text-white font-sans overflow-hidden">
      
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleSidebar}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside 
        className={`fixed lg:static inset-y-0 left-0 w-72 bg-[#0A1220]/80 backdrop-blur-2xl border-r border-white/5 flex flex-col z-50 transform transition-transform duration-500 ease-in-out lg:transform-none ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="p-8 flex justify-between items-center">
          <Link to="/" className="text-2xl font-display font-medium tracking-tighter uppercase relative group">
            <span className="text-white">STUDIO</span>
            <span className="text-accent drop-shadow-[0_0_8px_rgba(124,77,255,0.4)]">HQ</span>
          </Link>
          <button onClick={toggleSidebar} className="lg:hidden text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto px-6 pb-6 space-y-8 scrollbar-hide">
          <div className="space-y-2">
            <div className="text-[10px] tracking-[0.2em] uppercase text-gray-500 font-medium mb-4 px-2">Main Menu</div>
            <nav className="flex flex-col gap-1.5">
              <NavLink to="/admin" icon={<LayoutDashboard size={18} />} label="Dashboard" current={location.pathname} />
              <NavLink to="/admin/projects" icon={<Briefcase size={18} />} label="Projects" current={location.pathname} />
              <NavLink to="/admin/uploads" icon={<UploadCloud size={18} />} label="Uploads" current={location.pathname} />
              <NavLink to="/admin/messages" icon={<MessageSquare size={18} />} label="Messages" current={location.pathname} />
              <NavLink to="/admin/service-requests" icon={<FileText size={18} />} label="Service Requests" current={location.pathname} />
              <NavLink to="/admin/analytics" icon={<BarChart2 size={18} />} label="Analytics" current={location.pathname} />
            </nav>
          </div>

          <div className="space-y-2">
            <div className="text-[10px] tracking-[0.2em] uppercase text-gray-500 font-medium mb-4 px-2">Content</div>
            <nav className="flex flex-col gap-1.5">
              <NavLink to="/admin/services" icon={<FileText size={18} />} label="Services" current={location.pathname} />
              <NavLink to="/admin/testimonials" icon={<Star size={18} />} label="Testimonials" current={location.pathname} />
            </nav>
          </div>
        </div>
        
        <div className="p-6 border-t border-white/5 space-y-2 bg-white/[0.01]">
          <NavLink to="/admin/settings" icon={<Settings size={18} />} label="Settings" current={location.pathname} />
          <button 
            onClick={() => navigate('/')} 
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-gray-400 hover:text-white hover:bg-white/5 transition-all duration-300 text-sm font-medium group"
          >
            <LogOut size={18} className="group-hover:text-red-400 transition-colors" /> Exit to Site
          </button>
        </div>
      </motion.aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay"></div>
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent/10 rounded-full mix-blend-screen filter blur-[120px] opacity-20 pointer-events-none transform translate-x-1/2 -translate-y-1/2"></div>
        
        {/* Top Navbar */}
        <header className="h-20 border-b border-white/5 bg-[#09101C]/60 backdrop-blur-xl flex items-center justify-between px-8 z-30">
          <div className="flex items-center gap-6 flex-1">
            <button onClick={toggleSidebar} className="lg:hidden text-gray-400 hover:text-white transition-colors">
              <Menu size={24} />
            </button>
            <div className="hidden md:flex items-center w-full max-w-md bg-white/[0.03] border border-white/10 rounded-full px-4 py-2.5 transition-all focus-within:bg-white/[0.05] focus-within:border-accent/40 shadow-inner">
              <Search size={18} className="text-gray-400 mr-3" />
              <input 
                type="text" 
                placeholder="Search projects, messages, analytics..." 
                className="bg-transparent border-none text-sm text-white placeholder:text-gray-500 w-full focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button className="hidden md:flex items-center gap-2 bg-accent/20 hover:bg-accent/30 text-accent border border-accent/20 hover:border-accent/40 px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-300">
              <Plus size={16} /> New Draft
            </button>
            
            <button className="relative w-10 h-10 flex items-center justify-center rounded-full bg-white/[0.03] border border-white/10 hover:bg-white/10 transition-all text-gray-300 hover:text-white">
              <Bell size={18} />
              <span className="absolute top-2 right-2.5 w-2 h-2 bg-accent rounded-full border border-[#09101C]"></span>
            </button>
            
            <div className="w-px h-8 bg-white/10 hidden md:block"></div>
            
            <button className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-full overflow-hidden border border-white/20 group-hover:border-accent transition-colors">
                <img src="https://images.unsplash.com/photo-1555169062-01246bedf4d4?q=80&w=200&auto=format&fit=crop" alt="User" className="w-full h-full object-cover" />
              </div>
              <div className="hidden md:block text-left">
                <div className="text-sm font-medium text-white">Emmanuel O.</div>
                <div className="text-[10px] text-gray-400 uppercase tracking-widest">Admin</div>
              </div>
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto relative z-20">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="p-8 lg:p-12 pb-32 min-h-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

function NavLink({ to, icon, label, current }: { to: string, icon: React.ReactNode, label: string, current: string }) {
  const active = current === to || (to !== '/admin' && current.startsWith(to));
  
  // Note: For placeholder links like Uploads/Analytics that don't change the path exactly, active will be false unless requested.
  // We'll let normal exact matching or stars work. You can refine matching in future if exact matching is needed for mocked routes.
  return (
    <Link 
      to={to} 
      className={`relative flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-300 text-sm font-medium group overflow-hidden ${active ? 'bg-accent/10 border-accent/20' : 'bg-transparent border-transparent hover:bg-white/[0.04]'}`}
      style={{ border: '1px solid', borderColor: active ? 'rgba(124,77,255,0.2)' : 'transparent' }}
    >
      {active && (
        <motion.div 
          layoutId="sidebar-active"
          className="absolute inset-0 bg-gradient-to-r from-accent/10 to-transparent opacity-50"
        />
      )}
      <div className={`relative z-10 p-1.5 rounded-lg transition-colors ${active ? 'text-accent bg-accent/10' : 'text-gray-400 group-hover:text-white group-hover:bg-white/10'}`}>
        {icon}
      </div>
      <span className={`relative z-10 transition-colors ${active ? 'text-white' : 'text-gray-400 group-hover:text-white'}`}>
        {label}
      </span>
      {active && (
        <div className="absolute right-3 w-1.5 h-1.5 rounded-full bg-accent shadow-[0_0_8px_rgba(124,77,255,0.8)]"></div>
      )}
    </Link>
  );
}
