import React, { useEffect, useState, useRef } from 'react';
import { Project, Category } from '../../types';
import { Plus, Edit2, Trash2, X, Upload } from 'lucide-react';

export default function AdminProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [form, setForm] = useState({ title: '', slug: '', categoryId: 1, excerpt: '', description: '', tools: '', imageUrl: '' });
  const [uploadProgress, setUploadProgress] = useState(0);

  useEffect(() => {
    fetchProjects();
    fetch('/api/categories').then(res => res.json()).then(setCategories);
  }, []);

  const fetchProjects = () => {
    fetch('/api/projects').then(res => res.json()).then(setProjects);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    
    setUploadProgress(10);
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      setForm(prev => ({ ...prev, imageUrl: data.url }));
      setUploadProgress(100);
      setTimeout(() => setUploadProgress(0), 1000);
    } catch (err) {
      console.error(err);
      setUploadProgress(0);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      setIsModalOpen(false);
      setForm({ title: '', slug: '', categoryId: 1, excerpt: '', description: '', tools: '', imageUrl: '' });
      fetchProjects();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this project?')) return;
    await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    fetchProjects();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-display font-medium mb-1">Portfolio Projects</h1>
          <p className="text-gray-400">Manage your works and case studies.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-accent hover:bg-accent/80 text-white px-6 py-3 rounded-lg flex items-center gap-2 font-medium transition-colors"
        >
          <Plus size={18} /> Add Project
        </button>
      </div>

      <div className="bg-secondary-bg/30 border border-white/5 rounded-xl overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-white/5 text-sm uppercase tracking-widest text-gray-500 bg-secondary-bg">
              <th className="p-6 font-medium">Project</th>
              <th className="p-6 font-medium hidden md:table-cell">Category</th>
              <th className="p-6 font-medium hidden md:table-cell">Date</th>
              <th className="p-6 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {projects.map(project => (
              <tr key={project.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="p-6">
                  <div className="flex items-center gap-4">
                    <img src={project.imageUrl || 'https://via.placeholder.com/150'} alt="" className="w-16 h-12 object-cover rounded-md border border-white/10" />
                    <div>
                      <div className="font-medium text-lg font-display">{project.title}</div>
                      <div className="text-xs text-gray-500">{project.slug}</div>
                    </div>
                  </div>
                </td>
                <td className="p-6 hidden md:table-cell">
                  <span className="bg-white/10 text-white px-3 py-1 rounded-full text-xs">{project.categoryName}</span>
                </td>
                <td className="p-6 text-gray-400 text-sm hidden md:table-cell">
                  {new Date(project.createdAt).toLocaleDateString()}
                </td>
                <td className="p-6 text-right">
                  <div className="flex items-center justify-end gap-3">
                    <button className="p-2 text-gray-400 hover:text-white bg-white/5 rounded-md hover:bg-white/10 transition-colors">
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => handleDelete(project.id)}
                      className="p-2 text-red-400 hover:text-red-300 bg-red-400/10 rounded-md hover:bg-red-400/20 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {projects.length === 0 && (
              <tr>
                <td colSpan={4} className="p-12 text-center text-gray-500">No projects found. Create one.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#0B1524] border border-white/10 rounded-2xl w-full max-w-2xl mt-24 mb-12 shadow-2xl relative">
            <button onClick={() => setIsModalOpen(false)} className="absolute top-6 right-6 text-gray-400 hover:text-white">
              <X size={24} />
            </button>
            <div className="p-8">
              <h2 className="text-2xl font-display font-medium mb-6">Create New Project</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Upload Area */}
                <div 
                  className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center hover:border-accent/50 hover:bg-accent/5 transition-all cursor-pointer relative"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {form.imageUrl ? (
                    <img src={form.imageUrl} alt="Preview" className="h-48 w-full object-cover rounded-lg" />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-48 space-y-4">
                      <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center text-accent">
                        <Upload size={24} />
                      </div>
                      <div>
                        <p className="font-medium">Click or drag image to upload</p>
                        <p className="text-sm text-gray-500 mt-1">High resolution works best</p>
                      </div>
                    </div>
                  )}
                  {uploadProgress > 0 && uploadProgress < 100 && (
                    <div className="absolute inset-0 bg-primary-bg/80 flex items-center justify-center">
                      Uploading... {uploadProgress}%
                    </div>
                  )}
                  <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} accept="image/*" />
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Title</label>
                    <input required type="text" className="w-full bg-secondary-bg border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent" value={form.title} onChange={e => {
                        const t = e.target.value;
                        setForm({...form, title: t, slug: t.toLowerCase().replace(/[^a-z0-9]+/g, '-')});
                      }} 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Slug</label>
                    <input required type="text" className="w-full bg-secondary-bg border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent" value={form.slug} onChange={e => setForm({...form, slug: e.target.value})} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Category</label>
                    <select className="w-full bg-secondary-bg border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent" value={form.categoryId} onChange={e => setForm({...form, categoryId: parseInt(e.target.value)})}>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Tools Used</label>
                    <input type="text" className="w-full bg-secondary-bg border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent" placeholder="e.g. Figma, React, Framer" value={form.tools} onChange={e => setForm({...form, tools: e.target.value})} />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Short Excerpt</label>
                  <input required type="text" className="w-full bg-secondary-bg border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent" value={form.excerpt} onChange={e => setForm({...form, excerpt: e.target.value})} />
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Full Description</label>
                  <textarea required rows={5} className="w-full bg-secondary-bg border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent resize-none" value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
                </div>

                <div className="flex justify-end gap-4 pt-4 border-t border-white/10">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-3 font-medium text-gray-400 hover:text-white">Cancel</button>
                  <button type="submit" disabled={loading} className="px-8 py-3 bg-accent hover:bg-accent/80 text-white rounded-lg font-medium transition-colors">
                    {loading ? 'Saving...' : 'Save Project'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
