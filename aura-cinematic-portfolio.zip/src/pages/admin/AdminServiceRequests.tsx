import React, { useEffect, useState } from 'react';
import { Trash2, Briefcase, Clock, CheckCircle, Circle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ServiceRequest {
  id: number;
  name: string;
  email: string;
  projectType: string;
  message: string;
  status: string;
  createdAt: string;
}

export default function AdminServiceRequests() {
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = () => {
    setLoading(true);
    fetch('/api/service_requests')
      .then(res => res.json())
      .then(data => {
        setRequests(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  const deleteRequest = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this service request?')) return;
    try {
      await fetch(`/api/service_requests/${id}`, { method: 'DELETE' });
      fetchRequests();
    } catch (err) {
      console.error(err);
    }
  };

  const toggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'pending' ? 'completed' : 'pending';
    try {
      await fetch(`/api/service_requests/${id}/status`, { 
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      fetchRequests();
    } catch (err) {
      console.error(err);
    }
  };

  const filteredRequests = filter === 'All' 
    ? requests 
    : requests.filter(r => r.projectType === filter);

  // Get unique service types for the filter dropdown
  const serviceTypes = ['All', ...Array.from(new Set(requests.map(r => r.projectType)))];

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-poppins font-medium tracking-tight mb-2">Service Requests</h1>
          <p className="text-gray-400">View and manage inquiries for specific services.</p>
        </div>
        
        {requests.length > 0 && (
          <select 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-white/5 border border-white/10 px-4 py-2 rounded-xl text-white focus:outline-none focus:border-accent text-sm"
          >
            {serviceTypes.map(type => (
              <option key={type} value={type} className="bg-[#020617]">{type}</option>
            ))}
          </select>
        )}
      </div>

      <div className="bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden backdrop-blur-xl">
        {loading ? (
          <div className="p-10 text-center text-gray-400">Loading requests...</div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-10 text-center flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-gray-500 mb-4">
              <Briefcase size={24} />
            </div>
            <p className="text-gray-400">No service requests found.</p>
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            <AnimatePresence>
              {filteredRequests.map((req) => (
                <motion.div 
                  key={req.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className={`p-6 md:p-8 hover:bg-white/[0.02] transition-colors group ${req.status === 'completed' ? 'opacity-60' : ''}`}
                >
                  <div className="flex flex-col md:flex-row gap-6 justify-between items-start">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-center gap-4 flex-wrap">
                        <button 
                          onClick={() => toggleStatus(req.id, req.status)}
                          className={`flex items-center gap-2 text-xs font-medium uppercase tracking-wider px-3 py-1.5 rounded-full border transition-all ${
                            req.status === 'completed' 
                              ? 'border-green-500/30 text-green-400 bg-green-500/10' 
                              : 'border-yellow-500/30 text-yellow-400 bg-yellow-500/10'
                          }`}
                        >
                          {req.status === 'completed' ? <CheckCircle size={14} /> : <Circle size={14} />}
                          {req.status}
                        </button>
                        
                        <div className="text-xs font-medium text-accent bg-accent/10 px-3 py-1.5 rounded-full border border-accent/20">
                          {req.projectType}
                        </div>
                        
                        <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-white/5 px-2.5 py-1.5 rounded-md">
                          <Clock size={12} />
                          {new Date(req.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      <div className="flex items-baseline gap-3">
                        <h3 className="text-xl font-medium text-white">{req.name}</h3>
                        <a href={`mailto:${req.email}`} className="text-gray-400 text-sm hover:text-white transition-colors">
                          {req.email}
                        </a>
                      </div>
                      
                      <div className="bg-black/20 p-4 rounded-xl border border-white/5 text-gray-300 text-sm leading-relaxed whitespace-pre-wrap mt-2">
                        {req.message}
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => deleteRequest(req.id)}
                      className="w-10 h-10 rounded-full flex items-center justify-center text-gray-500 hover:text-red-400 hover:bg-red-400/10 transition-colors shrink-0 opacity-100 md:opacity-0 group-hover:opacity-100"
                      title="Delete Request"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
