import React, { useState, useEffect } from 'react';
import { UploadCloud, Image as ImageIcon } from 'lucide-react';

export default function AdminSettings() {
  const [portraitUrl, setPortraitUrl] = useState('');
  const [cvUrl, setCvUrl] = useState('');
  const [cvName, setCvName] = useState('');
  const [location, setLocation] = useState('Lad/Lak, Bariga');
  const [uploading, setUploading] = useState(false);
  const [cvUploading, setCvUploading] = useState(false);
  const [cvDeleting, setCvDeleting] = useState(false);
  const [message, setMessage] = useState('');
  const [cvMessage, setCvMessage] = useState('');
  const [savingLocation, setSavingLocation] = useState(false);

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.portraitUrl) {
          setPortraitUrl(data.portraitUrl);
        }
        if (data.cvUrl) {
          setCvUrl(data.cvUrl);
        }
        if (data.cvName) {
          setCvName(data.cvName);
        }
        if (data.location) {
          setLocation(data.location);
        }
      });
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('file', file);
    
    setUploading(true);
    setMessage('');
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setPortraitUrl(data.url);
        // Save to settings
        await fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key: 'portraitUrl', value: data.url }),
        });
        setMessage('Portrait updated successfully');
      }
    } catch (err) {
      console.error(err);
      setMessage('Failed to upload image');
    }
    setUploading(false);
  };

  const handleCvUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('file', file);
    
    setCvUploading(true);
    setCvMessage('');
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (data.url) {
        setCvUrl(data.url);
        if (data.originalname) {
          setCvName(data.originalname);
        }
        // Save to settings
        await fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key: 'cvUrl', value: data.url }),
        });
        await fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key: 'cvName', value: data.originalname || file.name }),
        });
        setCvMessage('CV uploaded successfully');
      }
    } catch (err) {
      console.error(err);
      setCvMessage('Failed to upload CV');
    }
    setCvUploading(false);
  };

  const handleDeleteCv = async () => {
    setCvDeleting(true);
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'cvUrl', value: '' }),
      });
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'cvName', value: '' }),
      });
      setCvUrl('');
      setCvName('');
      setCvMessage('CV removed successfully');
    } catch (err) {
      console.error(err);
      setCvMessage('Failed to remove CV');
    }
    setCvDeleting(false);
  };

  const handleSaveLocation = async () => {
    setSavingLocation(true);
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'location', value: location }),
      });
    } catch (err) {
      console.error(err);
    }
    setSavingLocation(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-display font-medium mb-2 text-white">Settings</h1>
        <p className="text-gray-400 text-sm tracking-wide">Manage your studio preferences and personal information.</p>
      </div>

      <div className="bg-white/[0.02] border border-white/5 p-8 rounded-[2rem] backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.2)]">
        <h2 className="text-xl font-medium mb-6 text-white tracking-wide">Personal Details</h2>
        
        <div className="space-y-6">
          <div>
            <label className="block text-xs uppercase tracking-[0.2em] font-medium text-gray-400 mb-3">About Page Portrait</label>
            <div className="flex items-start gap-6">
              <div className="w-32 h-40 rounded-2xl overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                {portraitUrl ? (
                  <img src={portraitUrl} alt="Portrait" className="w-full h-full object-cover" />
                ) : (
                  <ImageIcon className="text-gray-500" size={32} />
                )}
              </div>
              
              <div className="flex-1 space-y-4">
                <p className="text-sm text-gray-400">Upload a portrait image for the "DESIGN WITH PURPOSE" section on the About page. Recommended aspect ratio 3:4.</p>
                <div className="relative inline-block">
                  <input 
                    type="file" 
                    onChange={handleUpload} 
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
                    accept="image/*"
                    disabled={uploading}
                  />
                  <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-5 py-2.5 rounded-lg text-sm text-white hover:bg-white/10 transition-colors">
                    <UploadCloud size={18} /> {uploading ? 'Uploading...' : 'Choose Image'}
                  </div>
                </div>
                {message && <p className="text-sm text-accent">{message}</p>}
              </div>
            </div>
          </div>
          
          <div className="pt-6 border-t border-white/5">
            <label className="block text-xs uppercase tracking-[0.2em] font-medium text-gray-400 mb-3">Resume / CV</label>
            <div className="flex flex-col space-y-4">
              <p className="text-sm text-gray-400">Upload your latest CV in PDF or DOCX format. This will be available for download on the homepage hero section.</p>
              
              {cvUrl ? (
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-4 bg-white/5 border border-white/10 p-4 rounded-xl max-w-sm">
                    <div className="w-10 h-10 rounded-lg bg-green-500/20 text-green-400 flex items-center justify-center shrink-0">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><path d="M14 3v5h5M16 13H8M16 17H8M10 9H8"/></svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{cvName || 'Resume.pdf'}</p>
                      <p className="text-xs text-green-400">Active online</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="relative inline-block">
                      <input 
                        type="file" 
                        onChange={handleCvUpload} 
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
                        accept="application/pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        disabled={cvUploading}
                      />
                      <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2 rounded-lg text-sm text-white hover:bg-white/10 transition-colors">
                        {cvUploading ? 'Replacing...' : 'Replace File'}
                      </div>
                    </div>
                    <button 
                      onClick={handleDeleteCv}
                      disabled={cvDeleting}
                      className="inline-flex items-center gap-2 bg-red-500/10 text-red-400 border border-red-500/20 px-4 py-2 rounded-lg text-sm hover:bg-red-500/20 transition-colors"
                    >
                      {cvDeleting ? 'Removing...' : 'Remove CV'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="relative inline-block w-max">
                  <input 
                    type="file" 
                    onChange={handleCvUpload} 
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
                    accept="application/pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    disabled={cvUploading}
                  />
                  <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-5 py-2.5 rounded-lg text-sm text-white hover:bg-white/10 transition-colors">
                    <UploadCloud size={18} /> {cvUploading ? 'Uploading...' : 'Upload Document'}
                  </div>
                </div>
              )}
              {cvMessage && <p className={`text-sm ${cvMessage.includes('Failed') ? 'text-red-400' : 'text-green-400'}`}>{cvMessage}</p>}
            </div>
          </div>
          
          <div className="pt-6 border-t border-white/5">
            <label className="block text-xs uppercase tracking-[0.2em] font-medium text-gray-400 mb-3">Location & Region</label>
            <div className="flex flex-col space-y-4 max-w-sm">
              <p className="text-sm text-gray-400">Update your current location to appear across the hero, footer, and contact sections.</p>
              <input 
                type="text" 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-white/5 border border-white/10 px-4 py-3 rounded-lg text-white focus:outline-none focus:border-accent transition-colors"
                placeholder="Lad/Lak, Bariga"
              />
              <button 
                onClick={handleSaveLocation}
                disabled={savingLocation}
                className="bg-accent/20 text-accent font-medium tracking-wide uppercase text-xs px-5 py-2.5 rounded-lg border border-accent/30 hover:bg-accent/30 transition-all self-start"
              >
                {savingLocation ? 'Saving...' : 'Save Location'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
