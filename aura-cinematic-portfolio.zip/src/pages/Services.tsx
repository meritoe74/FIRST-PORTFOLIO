import React from 'react';
import { motion } from 'motion/react';
import { Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import { servicesData } from '../data/servicesData';

export default function Services() {
  return (
    <div className="w-full min-h-screen pt-32 pb-32 px-6 md:px-24 relative overflow-hidden bg-[#020617]">
      {/* Deep Blue Cinematic Background Effects */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-40">
        <div className="absolute top-0 right-0 w-[50vw] h-[50vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-30 animate-[pulse_10s_ease-in-out_infinite]" />
        <div className="absolute bottom-0 left-0 w-[40vw] h-[40vw] bg-accent rounded-full mix-blend-screen filter blur-[250px] opacity-20 animate-[pulse_12s_ease-in-out_infinite_reverse]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-4xl mb-24"
        >
          <div className="inline-flex items-center gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-6 py-3 rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.2)] mb-8">
            <Award size={18} className="text-accent" />
            <span className="text-[10px] sm:text-xs tracking-[0.2em] uppercase text-gray-300 font-medium whitespace-nowrap">NSQ Certified Professional</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-poppins font-bold tracking-tight mb-8 text-white">
            Digital Expertise &<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 to-gray-500">Creative Services.</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light leading-relaxed max-w-3xl">
            I deliver end-to-end creative solutions that span across brand identity, digital marketing, and immersive web experiences. As an NSQ Certified professional, every service is executed with industry-standard precision, strategic intent, and a commitment to visual excellence.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesData.map((service, i) => (
            <motion.div 
              key={service.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.15, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="group p-10 bg-white/[0.02] border border-white/10 rounded-[2.5rem] hover:bg-white/[0.05] hover:border-accent/30 transition-all duration-700 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.15)] hover:shadow-[0_16px_48px_rgba(124,77,255,0.15)] relative overflow-hidden flex flex-col h-full"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-blue-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
              
              <div className="relative z-10 flex-1 flex flex-col">
                <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-300 group-hover:text-accent mb-8 group-hover:scale-110 group-hover:-translate-y-2 group-hover:shadow-[0_0_20px_rgba(124,77,255,0.4)] group-hover:border-accent/40 transition-all duration-500 shadow-inner">
                  {service.icon}
                </div>
                
                <h3 className="text-2xl font-poppins font-semibold mb-4 text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-300 transition-all duration-300">
                  {service.title}
                </h3>
                
                <p className="text-gray-400 leading-relaxed text-sm mb-10 font-light flex-1">
                  {service.desc}
                </p>
                
                <Link to={`/services/${service.slug}`} className="inline-flex items-center gap-3 text-xs font-medium uppercase tracking-[0.2em] text-gray-400 hover:text-white transition-colors mt-auto w-max group/link">
                  <span>Explore Service</span>
                  <div className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center group-hover/link:border-accent group-hover/link:bg-accent/10 transition-all duration-300">
                    <span className="text-sm leading-none group-hover/link:text-accent group-hover/link:translate-x-0.5 transition-all">&rarr;</span>
                  </div>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
