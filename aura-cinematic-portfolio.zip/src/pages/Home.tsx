import React, { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ArrowRight, Download, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [cvUrl, setCvUrl] = useState('');
  const [location, setLocation] = useState('Lad/Lak, Bariga');
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.cvUrl) {
          setCvUrl(data.cvUrl);
        }
        if (data.location) {
          setLocation(data.location);
        }
      })
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="w-full" ref={containerRef}>
      {/* Hero Section */}
      <section className="relative min-h-[95vh] flex flex-col justify-center pt-24 lg:pt-32 pb-16 lg:pb-32 px-6 md:px-24 overflow-hidden">
        {/* Cinematic Deep Blue Background Visual */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#020617] via-[#07101E] to-transparent z-0 opacity-80" />
        <motion.div 
          className="absolute inset-0 z-0 opacity-60 pointer-events-none"
          style={{ y, opacity }}
        >
          <div className="absolute top-[10%] right-[5%] w-[60vw] h-[60vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[250px] opacity-30 animate-[pulse_10s_ease-in-out_infinite]" />
          <div className="absolute bottom-[-20%] left-[5%] w-[50vw] h-[50vw] bg-accent rounded-full mix-blend-screen filter blur-[220px] opacity-20 animate-[pulse_12s_ease-in-out_infinite_reverse]" />
        </motion.div>

        {/* Premium Floating Bubbles */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {[
            { size: 180, left: '10%', top: '15%', delay: 0, duration: 18, color: 'rgba(124,77,255,0.03)' },
            { size: 320, left: '75%', top: '10%', delay: 2, duration: 25, color: 'rgba(30,58,138,0.04)' },
            { size: 120, left: '45%', top: '60%', delay: 5, duration: 15, color: 'rgba(124,77,255,0.05)' },
            { size: 260, left: '80%', top: '65%', delay: 1, duration: 22, color: 'rgba(30,58,138,0.03)' },
            { size: 220, left: '5%', top: '70%', delay: 4, duration: 20, color: 'rgba(124,77,255,0.02)' },
            { size: 90, left: '55%', top: '25%', delay: 3, duration: 16, color: 'rgba(255,255,255,0.02)' },
          ].map((bubble, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full border border-white/10 backdrop-blur-[12px] shadow-[inset_0_0_30px_rgba(255,255,255,0.05),0_8px_32px_rgba(0,0,0,0.3)]"
              style={{
                width: bubble.size,
                height: bubble.size,
                left: bubble.left,
                top: bubble.top,
                background: `linear-gradient(135deg, ${bubble.color}, transparent)`,
                boxShadow: `0 0 40px ${bubble.color}, inset 0 0 20px rgba(255,255,255,0.05)`
              }}
              animate={{
                y: [0, -40, 0, 40, 0],
                x: [0, 30, 0, -30, 0],
                rotate: [0, 90, 180, 270, 360],
              }}
              transition={{
                duration: bubble.duration,
                repeat: Infinity,
                ease: "linear",
                delay: bubble.delay,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-7xl mx-auto flex flex-col gap-16 md:gap-20">
          <div className="flex flex-col-reverse md:grid md:grid-cols-2 gap-12 md:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="w-full flex-1 flex flex-col items-center justify-center gap-6 md:order-none"
            >
              <div className="w-full max-w-md md:max-w-none relative aspect-[4/5] rounded-[3rem] overflow-hidden border border-white/10 bg-white/[0.02] backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.3)] group">
                <div className="absolute inset-0 bg-gradient-to-t from-[#07111F] via-transparent to-transparent opacity-80 z-10 pointer-events-none" />
                <img 
                  src="https://i.ibb.co/1Ywy4fyB/Whats-App-Image-2026-05-27-at-7-10-36-AM.jpg" 
                  alt="Emmanuel Oyeyinka Portrait" 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000 ease-[0.25,1,0.5,1] grayscale-[30%] group-hover:grayscale-0"
                />
              </div>
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
                className="text-center"
              >
                <h2 className="text-2xl md:text-3xl font-poppins font-medium text-white tracking-widest shadow-accent drop-shadow-[0_0_15px_rgba(124,77,255,0.4)] relative z-20">
                  Emmanuel Oyeyinka
                </h2>
                <div className="w-12 h-px bg-accent/60 mx-auto mt-4 shadow-[0_0_12px_rgba(124,77,255,0.8)]"></div>
              </motion.div>
            </motion.div>
            
            <div className="flex flex-col relative z-20">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
              >
                <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-[4.5rem] font-poppins font-bold leading-[1.1] tracking-tight mb-8 text-white drop-shadow-2xl">
                  Social Media Creativity &<br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 to-gray-500">Digital Branding.</span>
                </h1>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
              >
                <p className="text-lg md:text-xl text-gray-300 font-light leading-relaxed drop-shadow-lg mb-12 max-w-2xl">
                  I craft visuals that stop the scroll and spark engagement. Every design, caption, and campaign is created with strategy, creativity, and audience connection in mind. My journey in the creative space is driven by a passion for visual storytelling, content creation, and digital branding. From social media designs to photography, cinematography, and content strategy, I transform ideas into impactful digital experiences that build attention, engagement, and lasting brand identity.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, filter: 'blur(10px)' }}
                animate={{ opacity: 1, filter: 'blur(0px)' }}
                transition={{ duration: 1.2, delay: 0.8 }}
                className="flex flex-col w-full sm:w-auto sm:flex-row items-center gap-6 mt-4"
              >
                {cvUrl ? (
                  <a 
                    href={cvUrl} 
                    download 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="group relative flex items-center justify-between sm:justify-start gap-6 bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-accent/50 px-8 py-4 sm:py-5 rounded-2xl backdrop-blur-2xl transition-all duration-500 shadow-[0_8px_32px_rgba(0,0,0,0.2)] hover:shadow-[0_0_40px_rgba(124,77,255,0.3)] w-full sm:w-max active:scale-[0.98] overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-accent/0 via-accent/10 to-accent/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out pointer-events-none" />
                    <span className="text-sm font-poppins font-medium text-white uppercase tracking-[0.15em] relative z-10 w-full text-center sm:text-left">Download CV</span>
                    <div className="w-10 h-10 rounded-full bg-accent/20 text-accent flex items-center justify-center group-hover:bg-accent group-hover:text-white transition-all duration-500 shadow-[inset_0_0_10px_rgba(124,77,255,0.2)] group-hover:shadow-[0_0_20px_rgba(124,77,255,0.6)] shrink-0 relative z-10 group-hover:-translate-y-1">
                      <Download size={18} />
                    </div>
                  </a>
                ) : (
                  <div className="group relative flex items-center justify-between sm:justify-start gap-6 bg-white/[0.02] border border-white/5 px-8 py-4 sm:py-5 rounded-2xl backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.2)] w-full sm:w-max opacity-50">
                    <span className="text-sm font-poppins font-medium text-gray-400 uppercase tracking-[0.15em] w-full text-center sm:text-left">Resume / CV</span>
                    <div className="w-10 h-10 rounded-full bg-white/5 text-gray-500 flex items-center justify-center shrink-0">
                      <Download size={18} />
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center gap-10 lg:gap-12 w-full pt-16 mt-8 border-t border-white/5 relative z-20">
            <motion.div
              variants={{
                hidden: { opacity: 0 },
                show: { opacity: 1, transition: { staggerChildren: 0.08, delayChildren: 0.4 } }
              }}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              className="flex flex-wrap gap-4 justify-center max-w-5xl mx-auto"
            >
              {[
                'Graphic Designer', 'Cinematographer', 'Visual Storyteller', 
                'Photoshop Expert', 'Content Creator', 'Scriptwriter', 
                'Social Media Manager', 'Creative Director', 'Photographer', 
                'Brand Creative'
              ].map((role) => (
                <motion.div
                  key={role}
                  variants={{
                    hidden: { opacity: 0, scale: 0.9, y: 15 },
                    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring", stiffness: 80, damping: 15 } }
                  }}
                  whileHover={{ scale: 1.05, backgroundColor: 'rgba(124,77,255,0.15)', borderColor: 'rgba(124,77,255,0.4)', boxShadow: '0 8px 24px rgba(124,77,255,0.2)' }}
                  className="px-6 py-3.5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-2xl text-[11px] sm:text-xs font-medium tracking-[0.15em] uppercase text-gray-300 cursor-default transition-all duration-300 shadow-[0_4px_24px_rgba(0,0,0,0.1)] hover:-translate-y-1"
                >
                  {role}
                </motion.div>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, filter: 'blur(10px)', y: 20 }}
              whileInView={{ opacity: 1, filter: 'blur(0px)', y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-6 mt-4"
            >
              <div className="inline-flex items-center justify-center sm:justify-start gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-8 py-4 rounded-[1.5rem] shadow-[0_8px_32px_rgba(0,0,0,0.2)] w-full sm:w-auto">
                <div className="relative flex items-center justify-center w-8 h-8 shrink-0">
                  <div className="absolute inset-0 bg-accent rounded-full opacity-20 animate-ping" />
                  <div className="relative w-3 h-3 rounded-full bg-accent shadow-[0_0_12px_rgba(124,77,255,0.8)]" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-gray-400 font-medium whitespace-nowrap">NSQ Certified Creative</span>
                  <span className="text-sm font-medium text-white tracking-wide whitespace-nowrap">Professional Credentials</span>
                </div>
              </div>

              <a href={`https://maps.google.com/?q=${encodeURIComponent(location)}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center sm:justify-start gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-8 py-4 rounded-[1.5rem] shadow-[0_8px_32px_rgba(0,0,0,0.2)] group hover:bg-white/[0.04] hover:border-accent/30 transition-all duration-300 w-full sm:w-auto">
                <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 group-hover:text-accent group-hover:scale-110 transition-all shrink-0">
                  <MapPin size={16} />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-gray-400 font-medium whitespace-nowrap">Based In</span>
                  <span className="text-sm font-medium text-white tracking-wide whitespace-nowrap group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-300 transition-colors">{location}</span>
                </div>
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Works Preview */}
      <section className="py-32 px-6 md:px-24">
        <div className="flex justify-between items-end mb-24">
          <h2 className="text-4xl md:text-6xl font-display font-medium tracking-tight">SELECTED <span className="text-gray-500">WORKS</span></h2>
          <Link to="/portfolio" className="hidden md:flex gap-2 items-center text-accent hover:text-white transition-colors">
            View All <ArrowRight size={20} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24">
          {/* Mock Featured Projects */}
          {[
            { id: 1, title: 'Cosmic Brand Identity', category: 'Branding', img: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop' },
            { id: 2, title: 'Oasis UI Concept', category: 'Digital', img: 'https://images.unsplash.com/photo-1541462608143-67571c6738dd?q=80&w=2000&auto=format&fit=crop' }
          ].map((item, i) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, y: 100 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: i * 0.2 }}
              className="group cursor-pointer flex flex-col gap-8 bg-white/[0.02] border border-white/5 p-6 rounded-[2rem] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-700 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]"
            >
              <div className="relative overflow-hidden rounded-2xl aspect-[4/3] bg-primary-bg shadow-inner">
                <img 
                  src={item.img} 
                  alt={item.title} 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000 ease-[0.25,1,0.5,1] opacity-90 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-bg/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity duration-500" />
              </div>
              <div className="flex justify-between items-center px-2">
                <div>
                  <h3 className="text-3xl font-display mb-2 tracking-tight group-hover:text-white transition-colors">{item.title}</h3>
                  <p className="text-accent tracking-[0.15em] uppercase text-xs font-medium">{item.category}</p>
                </div>
                <div className="opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-500 bg-white/10 p-4 rounded-full border border-white/10 text-white backdrop-blur-md">
                  <ArrowRight size={20} className="transform -rotate-45 group-hover:rotate-0 transition-transform duration-500" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Services Snippet */}
      <section className="py-32 px-6 md:px-24 bg-[#020617] border-y border-white/5 relative overflow-hidden">
        {/* Subtle Background Glows */}
        <div className="absolute top-0 right-0 w-[40vw] h-[40vw] bg-[#1E3A8A] rounded-full mix-blend-screen filter blur-[200px] opacity-20 animate-[pulse_10s_ease-in-out_infinite]" />
        
        <div className="mb-16 relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div>
            <div className="inline-flex items-center gap-4 border border-white/10 bg-white/[0.02] backdrop-blur-2xl px-5 py-2 rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.1)] mb-6">
              <span className="text-[10px] tracking-[0.2em] uppercase text-accent font-medium whitespace-nowrap">NSQ Certified</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-poppins font-bold tracking-tight text-white mb-4">
              Creative <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 to-gray-500">Expertise.</span>
            </h2>
            <p className="text-gray-400 font-light max-w-xl">Elevating brands and digital experiences through strategic content, visual storytelling, and premium design.</p>
          </div>
          <Link to="/services" className="inline-flex items-center gap-3 group text-sm font-medium tracking-[0.1em] uppercase text-white hover:text-accent transition-colors pb-2 border-b border-white/20 hover:border-accent">
            View All Services <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
          {[
            { title: 'Social Media Management', desc: 'Strategic content and engaged digital presence.' },
            { title: 'Cinematography & Video', desc: 'Premium narratives and compelling edits.' },
            { title: 'Website Development', desc: 'Responsive portfolios and premium UI/UX.' }
          ].map((service, index) => (
            <motion.div 
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-10 border border-white/5 rounded-[2rem] bg-white/[0.02] backdrop-blur-2xl hover:bg-white/[0.04] hover:border-accent/30 transition-all duration-500 shadow-[0_8px_32px_rgba(0,0,0,0.2)] group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative z-10">
                <div className="text-4xl text-white/10 font-poppins font-bold mb-6 group-hover:text-accent/40 transition-colors duration-500">0{index + 1}</div>
                <h3 className="text-2xl font-poppins font-semibold mb-4 text-white">{service.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed font-light">
                  {service.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
