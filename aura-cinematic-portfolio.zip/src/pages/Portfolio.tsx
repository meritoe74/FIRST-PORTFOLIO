import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Project, Category } from '../types';

export default function Portfolio() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => setCategories(data));
      
    fetchProjects('all');
  }, []);

  const fetchProjects = (slug: string) => {
    setLoading(true);
    const url = slug === 'all' ? '/api/projects' : `/api/projects?categorySlug=${slug}`;
    fetch(url)
      .then(res => res.json())
      .then(data => {
        setProjects(data);
        setLoading(false);
      });
  };

  const handleFilter = (slug: string) => {
    setActiveCategory(slug);
    fetchProjects(slug);
  };

  return (
    <div className="min-h-screen px-6 md:px-24 pb-32">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="pt-24 pb-16"
      >
        <h1 className="text-6xl md:text-8xl font-display font-medium tracking-tighter mb-8">
          THE <span className="text-gray-500">ARCHIVE</span>
        </h1>
        
        {/* Filters */}
        <div className="flex flex-wrap gap-4 mt-12 border-b border-white/10 pb-8">
          <button 
            onClick={() => handleFilter('all')}
            className={`px-6 py-2 rounded-full border text-sm tracking-wide uppercase transition-all ${activeCategory === 'all' ? 'border-accent bg-accent text-white' : 'border-white/20 text-gray-400 hover:border-white'}`}
          >
            All Works
          </button>
          {categories.map(cat => (
            <button 
              key={cat.id}
              onClick={() => handleFilter(cat.slug)}
              className={`px-6 py-2 rounded-full border text-sm tracking-wide uppercase transition-all ${activeCategory === cat.slug ? 'border-accent bg-accent text-white' : 'border-white/20 text-gray-400 hover:border-white'}`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Grid */}
      {loading ? (
        <div className="h-[50vh] flex items-center justify-center">
          <div className="w-12 h-12 rounded-full border-4 border-white/10 border-t-accent animate-spin" />
        </div>
      ) : (
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-24 mt-12"
        >
          {projects.map((project, i) => (
            <motion.div
              layout
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              key={project.id}
              className="group cursor-pointer flex flex-col gap-6 bg-white/[0.02] border border-white/5 p-4 rounded-[2rem] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-700 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.15)]"
            >
              <div className="relative overflow-hidden rounded-2xl aspect-[4/3] bg-primary-bg shadow-inner">
                <img 
                  src={project.imageUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564'} 
                  alt={project.title} 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000 ease-[0.25,1,0.5,1] opacity-90 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-bg/70 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity duration-500" />
              </div>
              <div className="flex justify-between items-center px-4 pb-2">
                <div>
                  <h3 className="text-3xl font-display mb-2 group-hover:text-white transition-colors tracking-tight">{project.title}</h3>
                  <div className="flex gap-3 text-xs text-accent font-medium tracking-[0.15em] uppercase">
                    <span>{project.categoryName}</span>
                    <span>&bull;</span>
                    <span>{new Date(project.createdAt).getFullYear()}</span>
                  </div>
                </div>
                <Link to={`/portfolio/${project.slug}`} className="w-14 h-14 rounded-full bg-white/10 border border-white/10 flex items-center justify-center group-hover:bg-accent group-hover:border-accent transition-all duration-500 text-white backdrop-blur-md">
                  <ArrowRight size={24} className="transform -rotate-45 group-hover:rotate-0 transition-transform duration-500" />
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
