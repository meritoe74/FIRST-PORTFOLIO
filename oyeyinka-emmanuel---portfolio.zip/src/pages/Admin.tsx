import React, { useState } from 'react';
import { useStore } from '../store';
import { Button } from '../components/ui/Button';
import { LogOut, Plus, Image as ImageIcon } from 'lucide-react';
import { Project } from '../types';
import { ProjectGrid } from '../components/admin/ProjectGrid';
import { ProjectEditor } from '../components/admin/ProjectEditor';
import { ContentManager } from '../components/admin/ContentManager';

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'projects' | 'content'>('projects');
  
  const [editingProject, setEditingProject] = useState<Project | null | undefined>(undefined);

  const { projects, deleteProject, addProject, updateProject } = useStore();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin') {
      setIsAuthenticated(true);
    } else {
      alert('Default dev password is "admin"');
    }
  };

  const handleSaveProject = (project: Project) => {
    const isNew = !projects.find(p => p.id === project.id);
    if (isNew) {
      addProject(project);
    } else {
      updateProject(project);
    }
    setEditingProject(undefined);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center py-24 px-6 relative bg-[#020B1D]">
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#8B5CF6]/20 rounded-full blur-[150px]" />
        </div>
        <div className="glass-dark p-10 md:p-14 rounded-[3rem] border border-white/10 shadow-[0_0_50px_rgba(139,92,246,0.15)] max-w-md w-full relative z-10 text-white">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-[#8B5CF6] rounded-2xl mb-8 flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.4)]">
             <ImageIcon className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-display font-bold mb-2">Studio Portal</h1>
          <p className="text-[#A78BFA] mb-10 font-medium">Authenticate to access CMS.</p>
          <form onSubmit={handleLogin} className="space-y-8">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-3 ml-2">Access Key</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full glass-input px-6 py-4 rounded-2xl text-lg backdrop-blur-xl"
                placeholder="••••••••"
              />
              <p className="text-xs text-slate-500 mt-3 ml-2">Hint: 'admin' during development</p>
            </div>
            <Button size="lg" className="w-full text-lg shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_30px_rgba(139,92,246,0.5)]">Authenticate</Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <main className="pt-32 pb-24 min-h-screen bg-[#020B1D] relative">
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-1/4 w-[800px] h-[800px] bg-[#8B5CF6]/5 rounded-full blur-[150px]" />
      </div>
      
      <div className="max-w-[90rem] mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-16 gap-6 bg-[#07142E]/70 p-6 md:p-8 rounded-[2rem] border border-white/5 backdrop-blur-xl shadow-2xl">
          <div className="flex items-center gap-6">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-[#8B5CF6] rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.4)]">
               <ImageIcon className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-display font-bold text-white tracking-tight drop-shadow-md">Creative Studio CMS</h1>
              <p className="text-[#A78BFA] font-medium">Manage portfolio, media, and site content.</p>
            </div>
          </div>
          <Button variant="ghost" onClick={() => setIsAuthenticated(false)} className="gap-2 text-slate-400 hover:text-white bg-white/5 rounded-xl border border-white/5 hover:border-white/10">
            <LogOut className="w-4 h-4" /> Disconnect Session
          </Button>
        </div>

        <div className="flex items-center gap-2 border-b border-white/5 mb-12 overflow-x-auto hide-scrollbar pb-1">
          <button 
            onClick={() => setActiveTab('projects')}
            className={`pb-4 px-6 text-sm uppercase tracking-wider font-bold transition-all border-b-2 whitespace-nowrap ${activeTab === 'projects' ? 'border-[#8B5CF6] text-white drop-shadow-[0_0_10px_rgba(139,92,246,0.5)]' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
          >
            Media & Projects
          </button>
          <button 
            onClick={() => setActiveTab('content')}
            className={`pb-4 px-6 text-sm uppercase tracking-wider font-bold transition-all border-b-2 whitespace-nowrap ${activeTab === 'content' ? 'border-[#8B5CF6] text-white drop-shadow-[0_0_10px_rgba(139,92,246,0.5)]' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
          >
            Site Content & Config
          </button>
        </div>

        {activeTab === 'projects' && (
          <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
              <h2 className="text-2xl font-display font-bold text-white drop-shadow-sm">Media Catalog</h2>
              <Button onClick={() => setEditingProject(null)} className="gap-2 shadow-[0_0_15px_rgba(139,92,246,0.3)]"><Plus className="w-5 h-5" /> Add Project / Media</Button>
            </div>
            <ProjectGrid projects={projects} onEdit={setEditingProject} onDelete={deleteProject} />
          </div>
        )}

        {activeTab === 'content' && (
          <ContentManager />
        )}

      </div>

      {editingProject !== undefined && (
        <ProjectEditor 
          project={editingProject} 
          onClose={() => setEditingProject(undefined)} 
          onSave={handleSaveProject} 
        />
      )}
    </main>
  );
}
