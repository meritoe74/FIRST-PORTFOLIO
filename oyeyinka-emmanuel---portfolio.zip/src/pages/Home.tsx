import React from 'react';
import { HeroSlider } from '../components/sections/HeroSlider';
import { CaseStudyShowcase } from '../components/sections/CaseStudyShowcase';
import { Services } from '../components/sections/Services';
import { About } from '../components/sections/About';
import { Testimonials } from '../components/sections/Testimonials';
import { Contact } from '../components/sections/Contact';
import { AmbientBackground } from '../components/ui/AmbientBackground';

export default function Home() {
  return (
    <main className="min-h-screen bg-[#020B1D] font-body overflow-hidden relative">
      <AmbientBackground />
      <HeroSlider />
      <CaseStudyShowcase />
      <Services />
      <Testimonials />
      <About />
      <Contact />
    </main>
  );
}
