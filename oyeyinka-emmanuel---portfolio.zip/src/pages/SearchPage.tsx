import React, { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useStore } from '../store';
import { ProjectCard } from '../components/ui/ProjectCard';
import { Search } from 'lucide-react';
import { motion } from 'motion/react';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const categoryId = searchParams.get('c') || '';
  const { projects, categories } = useStore();

  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      let matches = true;
      if (query) {
        const q = query.toLowerCase();
        matches = 
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tags.some(t => t.toLowerCase().includes(q)) ||
          p.servicesRendered.some(s => s.toLowerCase().includes(q)) ||
          p.toolsUsed.some(t => t.toLowerCase().includes(q));
      }
      if (categoryId && matches) {
        matches = p.categoryIds.includes(categoryId);
      }
      return matches;
    });
  }, [projects, query, categoryId]);

  return (
    <main className="pt-32 pb-24 px-6 min-h-screen relative overflow-hidden">
      <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-[#8B5CF6]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="mb-12">
          <div className="relative max-w-2xl mx-auto mb-16">
             <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 w-6 h-6" />
             <input 
               type="text" 
               defaultValue={query}
               placeholder="Search inspiration, tools, projects..."
               onChange={(e) => {
                 const newParams = new URLSearchParams(searchParams);
                 if (e.target.value) {
                   newParams.set('q', e.target.value);
                 } else {
                   newParams.delete('q');
                 }
                 setSearchParams(newParams);
               }}
               className="w-full h-16 pl-16 pr-6 glass text-white rounded-full text-lg shadow-[0_0_20px_rgba(139,92,246,0.15)] focus:border-[#8B5CF6]/50 focus:shadow-[0_0_30px_rgba(139,92,246,0.3)] outline-none transition-all placeholder:text-slate-500"
             />
          </div>
          
          <div className="flex items-center gap-3 overflow-x-auto hide-scrollbar pb-4 max-w-full">
             <button 
               onClick={() => {
                 const newParams = new URLSearchParams(searchParams);
                 newParams.delete('c');
                 setSearchParams(newParams);
               }}
               className={`px-5 py-2.5 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${!categoryId ? 'bg-gradient-to-r from-blue-600 to-[#8B5CF6] text-white shadow-[0_0_15px_rgba(139,92,246,0.4)] border border-transparent' : 'glass text-slate-300 hover:text-white border-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_0_15px_rgba(139,92,246,0.2)]'}`}
             >
               All Categories
             </button>
             {categories.map(cat => (
               <button 
                 key={cat.id}
                 onClick={() => {
                   const newParams = new URLSearchParams(searchParams);
                   newParams.set('c', cat.id);
                   setSearchParams(newParams);
                 }}
                 className={`px-5 py-2.5 rounded-full whitespace-nowrap text-sm font-medium transition-all ${categoryId === cat.id ? 'bg-gradient-to-r from-blue-600 to-[#8B5CF6] text-white shadow-[0_0_15px_rgba(139,92,246,0.4)] border border-transparent' : 'glass text-slate-300 hover:text-white border-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_0_15px_rgba(139,92,246,0.2)]'}`}
               >
                 {cat.name}
               </button>
             ))}
          </div>
        </div>

        <div className="mb-8">
          {categoryId ? (
            <div>
              <h1 className="text-4xl md:text-5xl font-display font-black text-white mb-4">
                {categories.find(c => c.id === categoryId)?.name || 'Category'} Projects
              </h1>
              <p className="text-lg text-slate-400">
                {filteredProjects.length} result{filteredProjects.length !== 1 && 's'} 
                {query && <span> for "{query}"</span>}
              </p>
            </div>
          ) : (
            <h2 className="text-xl font-medium text-white">
              {filteredProjects.length} result{filteredProjects.length !== 1 && 's'} 
              {query && <span> for "{query}"</span>}
            </h2>
          )}
        </div>

        {filteredProjects.length > 0 ? (
          <div className="masonry">
            {filteredProjects.map((project, idx) => (
              <motion.div 
                key={project.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.05 }}
              >
                <ProjectCard project={project} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-32 glass border border-white/10 rounded-3xl">
            <h3 className="text-2xl font-bold text-white mb-3">No projects found</h3>
            <p className="text-slate-400">Try adjusting your search terms or filters.</p>
          </div>
        )}
      </div>
    </main>
  );
}
