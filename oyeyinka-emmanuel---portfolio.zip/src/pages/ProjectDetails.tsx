import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { Button } from '../components/ui/Button';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function ProjectDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { projects, categories } = useStore();
  
  const project = projects.find(p => p.id === id);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-24 relative">
        <div className="text-center relative z-10 glass p-12 rounded-3xl border border-white/10 shadow-[0_0_50px_rgba(139,92,246,0.15)]">
          <h1 className="text-3xl font-display font-bold mb-6 text-white drop-shadow-md">Project Not Found</h1>
          <Button onClick={() => navigate(-1)}>Go Back</Button>
        </div>
      </div>
    );
  }

  const projectCategories = project.categoryIds
    .map(cid => categories.find(c => c.id === cid)?.name)
    .filter(Boolean);

  return (
    <main className="pt-32 pb-24 min-h-screen relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-[#8B5CF6]/10 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <button 
          onClick={() => navigate(-1)} 
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-10 transition-colors group font-medium hover:text-shadow-[0_0_8px_rgba(255,255,255,0.5)]"
        >
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" /> Back to projects
        </button>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="w-full h-[50vh] md:h-[70vh] rounded-[2rem] overflow-hidden mb-16 shadow-[0_30px_60px_rgba(0,0,0,0.5)] border border-white/10 relative group"
        >
          <img 
            src={project.heroImage} 
            alt={project.title} 
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-[2s] ease-out" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#020B1D] via-transparent to-transparent opacity-60" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 xl:gap-24">
          <div className="lg:col-span-2 space-y-16">
            <div>
              <div className="flex flex-wrap gap-3 mb-8">
                {projectCategories.map(cat => (
                  <span key={cat} className="px-4 py-1.5 glass text-[#A78BFA] border-[#8B5CF6]/30 shadow-[0_0_10px_rgba(139,92,246,0.2)] rounded-full text-sm font-semibold">{cat}</span>
                ))}
              </div>
              <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-8 drop-shadow-lg tracking-tight">{project.title}</h1>
              <p className="text-xl md:text-2xl text-slate-300 leading-relaxed font-body">{project.description}</p>
            </div>

            {project.objective && (
              <div className="glass p-10 md:p-12 rounded-[2.5rem] border border-white/5 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-[#8B5CF6]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <h3 className="text-2xl font-bold font-display text-white mb-6 relative z-10 flex items-center gap-3">
                  Objective
                </h3>
                <p className="text-lg text-slate-300 leading-relaxed relative z-10">{project.objective}</p>
              </div>
            )}

            {project.gallery.length > 0 && (
              <div className="space-y-10">
                <h3 className="text-3xl font-bold font-display text-white drop-shadow-md">Project Gallery</h3>
                {project.gallery.map((img, idx) => (
                  <div key={idx} className="rounded-3xl overflow-hidden border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.3)]">
                    <img src={img} alt={`Gallery ${idx + 1}`} className="w-full h-auto hover:scale-105 transition-transform duration-[1.5s]" />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-8">
            <div className="glass p-10 rounded-[2.5rem] sticky top-32 border border-white/10 shadow-[0_20px_40px_rgba(0,0,0,0.3)]">
              <div className="mb-10">
                <h4 className="font-bold text-white uppercase tracking-wider text-sm mb-6 flex items-center gap-2">
                  <span className="w-8 h-px bg-[#8B5CF6]"></span> Services Rendered
                </h4>
                <ul className="space-y-4">
                  {project.servicesRendered.map(service => (
                    <li key={service} className="flex items-start gap-3 text-slate-300">
                      <CheckCircle2 className="w-5 h-5 text-[#A78BFA] shrink-0 mt-0.5 drop-shadow-[0_0_5px_rgba(139,92,246,0.5)]" />
                      <span className="text-[1.05rem]">{service}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-10">
                <h4 className="font-bold text-white uppercase tracking-wider text-sm mb-6 flex items-center gap-2">
                   <span className="w-8 h-px bg-[#8B5CF6]"></span> Tools & Software
                </h4>
                <div className="flex flex-wrap gap-2.5">
                  {project.toolsUsed.map(tool => (
                    <span key={tool} className="px-3.5 py-1.5 glass text-slate-300 rounded-lg text-sm border-white/5 hover:border-[#8B5CF6]/50 transition-colors shadow-[0_0_10px_rgba(0,0,0,0.2)]">{tool}</span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-white uppercase tracking-wider text-sm mb-6 flex items-center gap-2">
                   <span className="w-8 h-px bg-[#8B5CF6]"></span> Tags
                </h4>
                <div className="flex flex-wrap gap-2.5">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-slate-400 text-sm hover:text-[#A78BFA] transition-colors cursor-pointer">#{tag}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
