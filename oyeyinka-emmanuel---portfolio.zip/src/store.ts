import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Category, ProfileData, Project, Testimonial } from './types';
import { mockCategories, mockProfile, mockProjects, mockTestimonials } from './data/mockData';

type StoreState = {
  profile: ProfileData;
  categories: Category[];
  projects: Project[];
  testimonials: Testimonial[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  // Admin mock functions
  updateProfile: (profile: ProfileData) => void;
  addProject: (project: Project) => void;
  updateProject: (project: Project) => void;
  deleteProject: (id: string) => void;
  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  addTestimonial: (t: Testimonial) => void;
  updateTestimonial: (t: Testimonial) => void;
  deleteTestimonial: (id: string) => void;
};

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      profile: mockProfile,
      categories: mockCategories,
      projects: mockProjects,
      testimonials: mockTestimonials,
      searchQuery: '',
      setSearchQuery: (query) => set({ searchQuery: query }),
      
      updateProfile: (newProfile) => set({ profile: newProfile }),
      addProject: (project) => set((state) => ({ projects: [project, ...state.projects] })),
      updateProject: (updatedProj) => set((state) => ({
        projects: state.projects.map((p) => p.id === updatedProj.id ? updatedProj : p)
      })),
      deleteProject: (id) => set((state) => ({
        projects: state.projects.filter((p) => p.id !== id)
      })),
      addCategory: (cat) => set((state) => ({ categories: [...state.categories, cat] })),
      updateCategory: (updatedCat) => set((state) => ({
        categories: state.categories.map((c) => c.id === updatedCat.id ? updatedCat : c)
      })),
      deleteCategory: (id) => set((state) => ({
        categories: state.categories.filter((c) => c.id !== id)
      })),
      addTestimonial: (t) => set((state) => ({ testimonials: [...state.testimonials, t] })),
      updateTestimonial: (updated) => set((state) => ({
        testimonials: state.testimonials.map((t) => t.id === updated.id ? updated : t)
      })),
      deleteTestimonial: (id) => set((state) => ({
        testimonials: state.testimonials.filter((t) => t.id !== id)
      })),
    }),
    {
      name: 'portfolio-storage',
    }
  )
);
