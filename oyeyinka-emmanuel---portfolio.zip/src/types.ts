export type Category = {
  id: string;
  name: string;
  order: number;
};

export type Project = {
  id: string;
  title: string;
  description: string;
  objective?: string;
  servicesRendered: string[];
  toolsUsed: string[];
  categoryIds: string[];
  tags: string[];
  heroImage: string;
  gallery: string[];
  featured?: boolean;
  dateCreated: string;
};

export type Testimonial = {
  id: string;
  clientName: string;
  company: string;
  message: string;
  avatar?: string;
};

export type ProfileData = {
  name: string;
  title: string;
  summary: string;
  bio: string;
  location: string;
  email: string;
  whatsapp: string;
  socials: {
    instagram: string;
    facebook: string;
    tiktok: string;
    youtube: string;
  };
  services: { name: string; description?: string }[];
  tools: {
    design: string[];
    video: string[];
    social: string[];
    productivity: string[];
  };
  cameraExpertise: {
    systems: string[];
    description: string;
  };
};
