import { Category, ProfileData, Project, Testimonial } from "../types";

export const mockProfile: ProfileData = {
  name: "Oyeyinka Emmanuel",
  title: "Creative Media Specialist",
  summary: "I create compelling visual stories that help brands, businesses, churches, organizations, startups, and individuals grow their online presence and connect with their audience.",
  bio: "I am a Creative Media Specialist, Social Media Manager, Content Creator, Graphic Designer, Photographer, Cinematographer, Script Writer, Creative Strategist, Photo Editor, and Photo Retoucher. I specialize in helping clients create meaningful digital experiences through strategic management and compelling visual storytelling. I am also a proud graduate of the NSQ Creative Program sponsored by the World Bank in conjunction with the Federal Ministry of Education.",
  location: "Lagos, Nigeria",
  email: "meritoe74@gmail.com",
  whatsapp: "+2348111777805",
  socials: {
    instagram: "https://instagram.com/",
    facebook: "https://facebook.com/",
    tiktok: "https://tiktok.com/",
    youtube: "https://youtube.com/"
  },
  services: [
    { name: "Social Media Management" },
    { name: "Photography" },
    { name: "Cinematography" },
    { name: "Script Writing" },
    { name: "Graphic Design" },
    { name: "Content Creation" },
    { name: "Photo Editing" },
    { name: "Photo Retouching" },
    { name: "Brand Strategy" },
    { name: "Creative Consulting" }
  ],
  tools: {
    design: ["Adobe Photoshop", "Adobe Illustrator", "CorelDRAW", "Canva"],
    video: ["Adobe Premiere Pro", "CapCut"],
    social: ["Meta Business Suite", "TikTok Studio"],
    productivity: ["Google Workspace"]
  },
  cameraExpertise: {
    systems: ["Sony Camera Systems", "Canon Camera Systems", "Nikon Camera Systems"],
    description: "Experienced in operating Sony, Canon, and Nikon camera systems for photography and cinematography including event coverage, portrait sessions, promotional shoots, and content production."
  }
};

export const mockCategories: Category[] = [
  { id: "Social Media Campaigns", name: "Social Media Campaigns", order: 1 },
  { id: "Church Campaigns", name: "Church Campaigns", order: 2 },
  { id: "Birthday Campaigns", name: "Birthday Campaigns", order: 3 },
  { id: "Funeral Campaigns", name: "Funeral Campaigns", order: 4 },
  { id: "Event Promotions", name: "Event Promotions", order: 5 },
  { id: "Branding Projects", name: "Branding Projects", order: 6 },
  { id: "Photography", name: "Photography", order: 7 },
  { id: "Cinematography", name: "Cinematography", order: 8 },
  { id: "Photo Editing & Retouching", name: "Photo Editing & Retouching", order: 9 },
  { id: "Video Editing", name: "Video Editing", order: 10 },
];

export const mockProjects: Project[] = [
  {
    id: "proj-1",
    title: "Vibrant Summer Collection Campaign",
    description: "A complete social media rollout for a fashion brand's summer line.",
    objective: "Increase brand awareness and drive sales for the new summer collection.",
    servicesRendered: ["Social Media Management", "Content Creation", "Graphic Design"],
    toolsUsed: ["Adobe Photoshop", "Canva", "Meta Business Suite"],
    categoryIds: ["Social Media Management", "Content Creation", "Branding"],
    tags: ["fashion", "summer", "instagram", "facebook"],
    heroImage: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80"
    ],
    featured: true,
    dateCreated: "2023-08-15"
  },
  {
    id: "proj-2",
    title: "Annual Praise Night Coverage",
    description: "Full-scale photography and cinematography coverage for a mega church event.",
    objective: "Document the event and create highlight reels for future promotions.",
    servicesRendered: ["Photography", "Cinematography", "Photo Retouching"],
    toolsUsed: ["Sony Camera Systems", "Adobe Premiere Pro", "Adobe Photoshop"],
    categoryIds: ["Photography", "Cinematography", "Photo Retouching"],
    tags: ["church", "event", "video", "photos", "praise"],
    heroImage: "https://images.unsplash.com/photo-1438232992991-995b7058bbb3?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1478147424096-f65bcf44c5c2?auto=format&fit=crop&w=800&q=80"
    ],
    featured: true,
    dateCreated: "2023-11-20"
  },
  {
    id: "proj-3",
    title: "Elegant 50th Birthday Branding",
    description: "Designed invitations, banners, and digital graphics for a luxury 50th birthday celebration.",
    objective: "Create a cohesive and luxurious visual identity for the milestone event.",
    servicesRendered: ["Graphic Design", "Event Promotion"],
    toolsUsed: ["CorelDRAW", "Adobe Photoshop"],
    categoryIds: ["Graphic Design", "Branding"],
    tags: ["birthday", "luxury", "flyer", "banner"],
    heroImage: "https://images.unsplash.com/photo-1530103862676-de3c9de59f9e?auto=format&fit=crop&w=800&q=80",
    gallery: [],
    featured: false,
    dateCreated: "2024-02-10"
  },
  {
    id: "proj-4",
    title: "Corporate Brand Identity Revamp",
    description: "Complete redesign of a local logistics company's brand identity and social media templates.",
    objective: "Modernize the brand's look to attract premium clients.",
    servicesRendered: ["Brand Identity Design", "Graphic Design", "Social Media Consultation"],
    toolsUsed: ["Adobe Illustrator", "Adobe Photoshop"],
    categoryIds: ["Branding", "Graphic Design"],
    tags: ["branding", "corporate", "logistics", "identity"],
    heroImage: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80"
    ],
    featured: true,
    dateCreated: "2024-01-05"
  },
  {
    id: "proj-5",
    title: "Cinematic Wedding Highlights",
    description: "Shot and edited a premium cinematic wedding video in Lagos.",
    objective: "Capture the emotion and narrative of the couple's special day.",
    servicesRendered: ["Cinematography", "Video Editing"],
    toolsUsed: ["Canon Camera Systems", "CapCut", "Adobe Premiere Pro"],
    categoryIds: ["Cinematography"],
    tags: ["wedding", "cinematography", "video", "love"],
    heroImage: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80",
    gallery: [],
    featured: true,
    dateCreated: "2023-12-12"
  }
];

export const mockTestimonials: Testimonial[] = [
  {
    id: "test-1",
    clientName: "Sarah Johnson",
    company: "Lumiere Fashion",
    message: "Emmanuel completely transformed our social media presence. His creative direction and high-quality graphics helped us double our engagement in just 3 months."
  },
  {
    id: "test-2",
    clientName: "David O.",
    company: "Grace Events",
    message: "The cinematography for our annual conference was top-notch. He managed the whole process seamlessly and delivered a stunning highlight video ahead of schedule."
  }
];
