import React from 'react';
import { motion } from 'motion/react';

export function AmbientBackground() {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden mix-blend-screen">
      <motion.div
        animate={{
          x: [0, 100, -50, 0],
          y: [0, -100, 50, 0],
          scale: [1, 1.2, 0.9, 1],
        }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        className="absolute top-[10%] left-[10%] w-[500px] h-[500px] bg-[#8B5CF6]/15 rounded-full blur-[140px]"
      />
      <motion.div
        animate={{
          x: [0, -100, 100, 0],
          y: [0, 100, -100, 0],
          scale: [1, 1.5, 0.9, 1],
        }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        className="absolute top-[40%] right-[10%] w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[160px]"
      />
      <motion.div
        animate={{
          x: [0, 80, -80, 0],
          y: [0, 80, 100, 0],
          scale: [1, 0.8, 1.1, 1],
        }}
        transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-[-10%] left-[20%] w-[700px] h-[700px] bg-[#A78BFA]/10 rounded-full blur-[150px]"
      />
    </div>
  );
}
