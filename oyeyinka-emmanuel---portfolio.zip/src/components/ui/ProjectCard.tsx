import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Project } from '../../types';
import { cn } from './Button';

interface ProjectCardProps {
  project: Project;
  className?: string;
  featured?: boolean;
}

export function ProjectCard({ project, className, featured = false }: ProjectCardProps) {
  return (
    <Link to={`/project/${project.id}`} className="block group">
      <motion.div 
        whileHover={{ y: -5 }}
        className={cn(
          "glass-dark rounded-3xl overflow-hidden flex flex-col h-full relative group-hover:shadow-[0_0_30px_rgba(139,92,246,0.3)] group-hover:border-[#8B5CF6]/40 transition-all duration-500",
          className
        )}
      >
        <div className={cn("overflow-hidden w-full", featured ? "h-[400px]" : "h-64")}>
          <img 
            src={project.heroImage} 
            alt={project.title} 
            loading="lazy"
            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#020B1D] via-[#020B1D]/20 to-transparent opacity-80" />
        </div>
        
        <div className="absolute top-4 left-4 flex gap-2 flex-wrap max-w-[80%]">
          {project.tags.slice(0, 2).map((tag, idx) => (
            <span key={idx} className="glass px-3 py-1 rounded-full text-xs font-semibold text-white shadow-[0_0_10px_rgba(139,92,246,0.2)] backdrop-blur-md">
              {tag}
            </span>
          ))}
        </div>

        <div className="p-6 md:p-8 flex-1 flex flex-col justify-end absolute inset-x-0 bottom-0 translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
          <h3 className="font-display font-bold text-xl md:text-2xl text-white mb-2 leading-tight">
            {project.title}
          </h3>
          <p className="text-sm text-slate-300 line-clamp-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
            {project.description}
          </p>
        </div>
      </motion.div>
    </Link>
  );
}
