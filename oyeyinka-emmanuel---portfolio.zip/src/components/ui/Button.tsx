import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'glass' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center font-medium transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue disabled:pointer-events-none disabled:opacity-50",
          {
            'bg-gradient-to-r from-blue-600 to-[#8B5CF6] text-white hover:from-blue-500 hover:to-[#A78BFA] shadow-[0_0_20px_rgba(139,92,246,0.4)] hover:shadow-[0_0_30px_rgba(139,92,246,0.6)]': variant === 'primary',
            'glass bg-[#07142E]/80 text-white hover:bg-[#0A1635] hover:border-[#8B5CF6]/50 shadow-[0_0_10px_rgba(139,92,246,0.1)] hover:shadow-[0_0_20px_rgba(139,92,246,0.3)]': variant === 'secondary',
            'glass hover:bg-white/10 text-white hover:border-[#8B5CF6]/30 hover:shadow-[0_0_15px_rgba(139,92,246,0.2)]': variant === 'glass',
            'hover:bg-white/10 hover:text-white text-slate-300': variant === 'ghost',
            'h-9 px-4 text-sm rounded-full': size === 'sm',
            'h-11 px-6 text-base rounded-full': size === 'md',
            'h-14 px-8 text-lg rounded-full hover:scale-105': size === 'lg',
          },
          className
        )}
        {...props}
      >
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";
