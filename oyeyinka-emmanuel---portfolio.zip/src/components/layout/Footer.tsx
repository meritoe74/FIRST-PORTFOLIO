import React from 'react';
import { useStore } from '../../store';
import { Link } from 'react-router-dom';
import { Settings, Instagram, Facebook, Youtube, Music } from 'lucide-react';

export default function Footer() {
  const { profile } = useStore();

  return (
    <footer className="bg-[#020B1D] text-slate-400 py-16 px-6 mt-32 border-t border-white/5 relative overflow-hidden">
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#8B5CF6]/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-12 relative z-10">
        <div className="max-w-sm">
          <h3 className="font-display text-2xl font-bold text-white mb-4">Oyeyinka Emmanuel</h3>
          <p className="text-slate-400 mb-6 leading-relaxed">
            Helping brands tell compelling stories through strategy, design, photography, video production, and social media management.
          </p>
          <div className="flex items-center gap-4">
              <a href={profile.socials.instagram} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_0_15px_rgba(139,92,246,0.5)] transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href={profile.socials.facebook} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_0_15px_rgba(139,92,246,0.5)] transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href={profile.socials.youtube} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_0_15px_rgba(139,92,246,0.5)] transition-all">
                <Youtube className="w-5 h-5" />
              </a>
              <a href={profile.socials.tiktok} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_0_15px_rgba(139,92,246,0.5)] transition-all">
                <Music className="w-5 h-5" />
              </a>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-12">
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="/#portfolio" className="hover:text-[#A78BFA] transition-colors">Portfolio</a></li>
              <li><a href="/#services" className="hover:text-[#A78BFA] transition-colors">Services</a></li>
              <li><a href="/#about" className="hover:text-[#A78BFA] transition-colors">About</a></li>
              <li><a href="/#contact" className="hover:text-[#A78BFA] transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li><a href={`mailto:${profile.email}`} className="hover:text-[#A78BFA] transition-colors">{profile.email}</a></li>
              <li><a href={`https://wa.me/${profile.whatsapp.replace('+', '')}`} className="hover:text-[#A78BFA] transition-colors">{profile.whatsapp}</a></li>
              <li>{profile.location}</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between text-sm text-slate-500 relative z-10 gap-4">
        <p>© {new Date().getFullYear()} Oyeyinka Emmanuel. All rights reserved.</p>
        <Link to="/admin" className="opacity-20 hover:opacity-100 text-slate-500 hover:text-[#A78BFA] transition-all duration-300 p-2 rounded-full hover:shadow-[0_0_15px_rgba(139,92,246,0.5)]">
          <Settings className="w-4 h-4" />
          <span className="sr-only">Admin Dashboard</span>
        </Link>
      </div>
    </footer>
  );
}
