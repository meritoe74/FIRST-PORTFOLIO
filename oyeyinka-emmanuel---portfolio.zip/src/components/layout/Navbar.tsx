import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Search, Menu, X, ArrowRight, Instagram, Facebook, Youtube, Music } from 'lucide-react';
import { Button, cn } from '../ui/Button';
import { useStore } from '../../store';
import { motion, AnimatePresence } from 'motion/react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [localSearch, setLocalSearch] = useState('');
  
  const { profile, projects } = useStore();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Handle visibility (hide on scroll down, show on scroll up)
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
      
      // Handle styling (scrolled or not)
      setIsScrolled(currentScrollY > 20);
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  useEffect(() => {
    setIsMobileMenuOpen(false);
    setSearchFocused(false);
  }, [location.pathname]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearch.trim()) {
      navigate(`/search?q=${encodeURIComponent(localSearch)}`);
      setSearchFocused(false);
    }
  };

  const navLinks = [
    { name: 'Portfolio', href: '/#portfolio' },
    { name: 'Services', href: '/#services' },
    { name: 'About', href: '/#about' },
  ];

  // Search suggestions logic
  const suggestions = localSearch.length > 1 
    ? projects.filter(p => 
        p.title.toLowerCase().includes(localSearch.toLowerCase()) ||
        p.tags.some(t => t.toLowerCase().includes(localSearch.toLowerCase()))
      ).slice(0, 3)
    : [];

  return (
    <>
      <header 
        className={cn(
          "fixed left-0 right-0 z-50 flex justify-center w-full px-4 transition-all duration-500",
          isVisible ? "top-4 translate-y-0 opacity-100" : "-top-20 -translate-y-full opacity-0"
        )}
      >
        <div className={cn(
          "flex items-center justify-between px-6 py-3 rounded-full transition-all duration-300 w-full max-w-5xl",
          isScrolled ? "glass-nav" : "bg-[#0A1635]/50 backdrop-blur-md border border-white/10"
        )}>
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <span className="font-display font-bold text-xl tracking-tight text-white group-hover:text-brand-blue transition-colors shadow-brand-blue/50 drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]">
              OE.
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <div className="flex items-center gap-6">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  className="text-sm font-medium text-slate-300 hover:text-white hover:text-shadow-[0_0_8px_rgba(139,92,246,0.8)] transition-all cursor-pointer relative group"
                >
                  {link.name}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-brand-blue group-hover:w-full transition-all duration-300 shadow-[0_0_8px_rgba(139,92,246,0.8)]" />
                </a>
              ))}
            </div>

            <div className="h-4 w-px bg-white/20 mx-2" />

            {/* Search Bar */}
            <div className="relative">
              <form onSubmit={handleSearchSubmit} className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-brand-blue transition-colors" />
                <input
                  type="text"
                  placeholder="Search works, tools..."
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  onFocus={() => setSearchFocused(true)}
                  onBlur={() => setTimeout(() => setSearchFocused(false), 200)}
                  className="glass-input pl-10 pr-4 py-2 rounded-full text-sm w-48 lg:w-56 focus:w-72 transition-all placeholder:text-slate-400"
                />
              </form>

              {/* Suggestions Dropdown */}
              <AnimatePresence>
                {searchFocused && localSearch.length > 1 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full mt-3 w-full min-w-[300px] right-0 glass-dark rounded-2xl p-4 overflow-hidden border border-[#8B5CF6]/30 shadow-[0_10px_40px_rgba(139,92,246,0.2)]"
                  >
                    <p className="text-xs font-semibold text-[#A78BFA] uppercase tracking-wider mb-3">Suggestions</p>
                    {suggestions.length > 0 ? (
                      <div className="space-y-2">
                        {suggestions.map(proj => (
                          <Link 
                            key={proj.id} 
                            to={`/project/${proj.id}`}
                            className="flex items-center gap-3 p-2 rounded-xl hover:bg-[#8B5CF6]/20 transition-colors group"
                          >
                            <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0">
                              <img src={proj.heroImage} alt={proj.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-white truncate">{proj.title}</p>
                              <p className="text-xs text-[#A78BFA] truncate">{proj.tags.join(', ')}</p>
                            </div>
                          </Link>
                        ))}
                        <Link to={`/search?q=${encodeURIComponent(localSearch)}`} className="text-brand-blue text-sm font-medium hover:text-[#A78BFA] inline-flex items-center gap-1 mt-2">
                          View all results <ArrowRight className="w-4 h-4" />
                        </Link>
                      </div>
                    ) : (
                      <p className="text-sm text-slate-300">No results found for "{localSearch}"</p>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Button size="sm" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
              Contact Me
            </Button>
          </nav>

          {/* Mobile Toggle */}
          <div className="flex md:hidden items-center gap-4">
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 text-slate-300">
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="fixed inset-x-0 top-20 z-40 px-4 md:hidden"
          >
            <div className="glass-dark rounded-3xl p-6 flex flex-col gap-6 border border-[#8B5CF6]/30 shadow-[0_10px_40px_rgba(139,92,246,0.2)]">
              <form onSubmit={handleSearchSubmit} className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  className="glass-input pl-10 pr-4 py-3 rounded-xl text-sm w-full"
                />
              </form>
              <div className="flex flex-col gap-4">
                {navLinks.map((link) => (
                  <a 
                    key={link.name} 
                    href={link.href}
                    className="text-lg font-medium text-white hover:text-brand-blue"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.name}
                  </a>
                ))}
              </div>
              <div className="flex items-center gap-4 justify-center py-2">
                 <a href={profile.socials.instagram} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors p-2 glass rounded-full"><Instagram className="w-5 h-5"/></a>
                 <a href={profile.socials.facebook} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors p-2 glass rounded-full"><Facebook className="w-5 h-5"/></a>
                 <a href={profile.socials.youtube} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors p-2 glass rounded-full"><Youtube className="w-5 h-5"/></a>
                 <a href={profile.socials.tiktok} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-white transition-colors p-2 glass rounded-full"><Music className="w-5 h-5"/></a>
              </div>
              <Button onClick={() => window.open(`https://wa.me/${profile.whatsapp.replace('+', '')}?text=Hello Oyeyinka Emmanuel, I came across your portfolio and would like to discuss a creative opportunity with you.`, '_blank')} className="w-full bg-gradient-to-r from-blue-600 to-[#8B5CF6]">
                Hire Me on WhatsApp
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
