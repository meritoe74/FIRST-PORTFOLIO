import React, { useState } from 'react';
import { useStore } from '../../store';
import { Button } from '../ui/Button';
import { Settings, Save, LayoutTemplate, MessageSquare, Plus, Trash2 } from 'lucide-react';

export function ContentManager() {
  const { profile, updateProfile, testimonials, addTestimonial, updateTestimonial, deleteTestimonial, categories, addCategory, deleteCategory } = useStore();
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'categories' | 'testimonials'>('profile');
  
  const [formData, setFormData] = useState(profile);
  const [newCatName, setNewCatName] = useState('');

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleProfileSave = () => {
    updateProfile(formData);
    alert('Profile saved successfully!');
  };

  const handleAddCategory = () => {
    if (newCatName.trim()) {
      addCategory({
        id: `cat-${Date.now()}`,
        name: newCatName.trim(),
        order: categories.length + 1
      });
      setNewCatName('');
    }
  };

  return (
    <div className="flex flex-col md:flex-row gap-8">
      <div className="w-full md:w-64 shrink-0 space-y-2">
        <button onClick={() => setActiveSubTab('profile')} className={`w-full text-left px-4 py-3 rounded-xl font-medium transition-all flex items-center gap-3 ${activeSubTab === 'profile' ? 'bg-[#8B5CF6]/20 text-white border border-[#8B5CF6]/50' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
          <LayoutTemplate className="w-5 h-5"/> Profile & Identity
        </button>
        <button onClick={() => setActiveSubTab('categories')} className={`w-full text-left px-4 py-3 rounded-xl font-medium transition-all flex items-center gap-3 ${activeSubTab === 'categories' ? 'bg-[#8B5CF6]/20 text-white border border-[#8B5CF6]/50' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
          <Settings className="w-5 h-5"/> Taxonomy (Categories)
        </button>
        <button onClick={() => setActiveSubTab('testimonials')} className={`w-full text-left px-4 py-3 rounded-xl font-medium transition-all flex items-center gap-3 ${activeSubTab === 'testimonials' ? 'bg-[#8B5CF6]/20 text-white border border-[#8B5CF6]/50' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}>
          <MessageSquare className="w-5 h-5"/> Client Feedback
        </button>
      </div>

      <div className="flex-1 glass-dark rounded-[2rem] p-8 border border-white/10 shadow-[0_20px_40px_rgba(0,0,0,0.3)]">
        
        {activeSubTab === 'profile' && (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6 font-display">Professional Identity</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Full Name</label>
                <input type="text" name="name" value={formData.name} onChange={handleProfileChange} className="w-full glass-input px-4 py-3 rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Professional Title</label>
                <input type="text" name="title" value={formData.title} onChange={handleProfileChange} className="w-full glass-input px-4 py-3 rounded-xl" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm text-slate-300 font-medium mb-2">Hero Summary</label>
                <textarea name="summary" value={formData.summary} onChange={handleProfileChange} rows={2} className="w-full glass-input px-4 py-3 rounded-xl resize-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm text-slate-300 font-medium mb-2">Full Bio (About Section)</label>
                <textarea name="bio" value={formData.bio} onChange={handleProfileChange} rows={4} className="w-full glass-input px-4 py-3 rounded-xl resize-none" />
              </div>
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Location</label>
                <input type="text" name="location" value={formData.location} onChange={handleProfileChange} className="w-full glass-input px-4 py-3 rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Email Address</label>
                <input type="email" name="email" value={formData.email} onChange={handleProfileChange} className="w-full glass-input px-4 py-3 rounded-xl" />
              </div>
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">WhatsApp Number</label>
                <input type="text" name="whatsapp" value={formData.whatsapp} onChange={handleProfileChange} className="w-full glass-input px-4 py-3 rounded-xl" />
              </div>
            </div>
            <div className="pt-6">
              <Button onClick={handleProfileSave} className="gap-2"><Save className="w-4 h-4"/> Save Profile Changes</Button>
            </div>
          </div>
        )}

        {activeSubTab === 'categories' && (
          <div>
            <h3 className="text-2xl font-bold text-white mb-6 font-display">Manage Categories</h3>
            <div className="flex gap-4 mb-8">
              <input type="text" value={newCatName} onChange={(e) => setNewCatName(e.target.value)} placeholder="New category name..." onKeyDown={(e)=>e.key==='Enter' && handleAddCategory()} className="flex-1 glass-input px-4 py-3 rounded-xl" />
              <Button onClick={handleAddCategory} className="gap-2"><Plus className="w-4 h-4"/> Create</Button>
            </div>
            
            <div className="space-y-3">
              {categories.map((cat) => (
                <div key={cat.id} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[#8B5CF6]/50 transition-colors">
                  <span className="font-medium text-white">{cat.name}</span>
                  <button onClick={() => { if(window.confirm('Delete category?')) deleteCategory(cat.id); }} className="p-2 text-slate-400 hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Testimonials truncated for brevity, but functional structure remains */}
        {activeSubTab === 'testimonials' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white font-display">Client Feedback</h3>
              <Button size="sm" onClick={() => addTestimonial({ id: `t-${Date.now()}`, clientName: 'New Client', company: 'Company', message: 'Testimonial text...' })}><Plus className="w-4 h-4 mr-2"/> Add New</Button>
            </div>
            <div className="grid grid-cols-1 gap-6">
              {testimonials.map((t) => (
                <div key={t.id} className="bg-white/5 border border-white/10 p-6 rounded-2xl relative group">
                   <button onClick={() => deleteTestimonial(t.id)} className="absolute top-4 right-4 p-2 text-slate-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 className="w-4 h-4"/></button>
                   <input type="text" value={t.clientName} onChange={(e) => updateTestimonial({...t, clientName: e.target.value})} className="bg-transparent border-b border-white/10 text-white font-bold w-full mb-2 outline-none focus:border-[#8B5CF6]" />
                   <input type="text" value={t.company} onChange={(e) => updateTestimonial({...t, company: e.target.value})} className="bg-transparent border-b border-white/10 text-[#A78BFA] text-sm w-full mb-4 outline-none focus:border-[#8B5CF6]" />
                   <textarea value={t.message} onChange={(e) => updateTestimonial({...t, message: e.target.value})} className="bg-transparent w-full resize-none text-slate-300 outline-none" rows={3} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
