import React, { useState } from 'react';
import { Project } from '../../types';
import { Button } from '../ui/Button';
import { X, Upload, Plus, Trash2 } from 'lucide-react';
import { useStore } from '../../store';

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

interface ProjectEditorProps {
  project?: Project | null;
  onClose: () => void;
  onSave: (project: Project) => void;
}

export function ProjectEditor({ project, onClose, onSave }: ProjectEditorProps) {
  const { categories } = useStore();
  const [formData, setFormData] = useState<Project>(
    project || {
      id: `proj-${Date.now()}`,
      title: '',
      description: '',
      objective: '',
      servicesRendered: [],
      toolsUsed: [],
      categoryIds: [],
      tags: [],
      heroImage: '',
      gallery: [],
      featured: false,
      dateCreated: new Date().toISOString().split('T')[0],
    }
  );

  const [tagInput, setTagInput] = useState('');
  const [serviceInput, setServiceInput] = useState('');
  const [toolInput, setToolInput] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleHeroImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = e.target.files[0];
      const base64 = await fileToBase64(file);
      setFormData((prev) => ({ ...prev, heroImage: base64 }));
    }
  };

  const handleGalleryAdd = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const base64Images = await Promise.all(files.map(fileToBase64));
      setFormData((prev) => ({ ...prev, gallery: [...prev.gallery, ...base64Images] }));
    }
  };

  const handleRemoveGalleryImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      gallery: prev.gallery.filter((_, i) => i !== index)
    }));
  };

  const addArrayItem = (key: 'tags' | 'servicesRendered' | 'toolsUsed', value: string, setter: React.Dispatch<React.SetStateAction<string>>) => {
    if (value.trim() && !formData[key].includes(value.trim())) {
      setFormData((prev) => ({ ...prev, [key]: [...prev[key], value.trim()] }));
      setter('');
    }
  };

  const removeArrayItem = (key: 'tags' | 'servicesRendered' | 'toolsUsed', value: string) => {
    setFormData((prev) => ({
      ...prev,
      [key]: (prev[key] as string[]).filter((item: string) => item !== value)
    }));
  };

  const toggleCategory = (catId: string) => {
    setFormData((prev) => ({
      ...prev,
      categoryIds: prev.categoryIds.includes(catId) 
        ? prev.categoryIds.filter(id => id !== catId)
        : [...prev.categoryIds, catId]
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#020B1D]/80 backdrop-blur-xl overflow-y-auto">
      <div className="bg-[#0A1635] border border-white/10 rounded-[2.5rem] w-full max-w-4xl max-h-[90vh] flex flex-col shadow-[0_20px_60px_rgba(0,0,0,0.5)]">
        <div className="flex items-center justify-between p-6 border-b border-white/5">
          <h2 className="text-2xl font-bold font-display text-white">{project ? 'Edit Project' : 'New Project'}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 md:p-10 hide-scrollbar">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Project Title</label>
                <input required type="text" name="title" value={formData.title} onChange={handleChange} className="w-full glass-input px-4 py-3 rounded-xl" placeholder="E.g., Summer Campaign" />
              </div>

              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Description</label>
                <textarea required name="description" value={formData.description} onChange={handleChange} rows={3} className="w-full glass-input px-4 py-3 rounded-xl resize-none" placeholder="Short description..." />
              </div>

              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Objective (Optional)</label>
                <textarea name="objective" value={formData.objective} onChange={handleChange} rows={2} className="w-full glass-input px-4 py-3 rounded-xl resize-none" placeholder="Project goals..." />
              </div>

              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2 opacity-80">Categories</label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => toggleCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all border ${formData.categoryIds.includes(cat.id) ? 'bg-[#8B5CF6]/20 border-[#8B5CF6] text-white shadow-[0_0_10px_rgba(139,92,246,0.3)]' : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'}`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 mt-4">
                <input type="checkbox" id="featured" checked={formData.featured} onChange={(e) => setFormData(prev => ({...prev, featured: e.target.checked}))} className="w-5 h-5 rounded border-white/10 bg-white/5 text-brand-blue accent-brand-blue" />
                <label htmlFor="featured" className="text-white font-medium">Feature this project on the homepage</label>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Hero Image</label>
                <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-white/10 rounded-2xl hover:border-[#8B5CF6]/50 transition-colors cursor-pointer bg-white/5 overflow-hidden relative group">
                  {formData.heroImage ? (
                    <>
                      <img src={formData.heroImage} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt="Hero Preview" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-white font-medium flex items-center gap-2"><Upload className="w-4 h-4"/> Change Image</span>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400 group-hover:text-white transition-colors">
                      <Upload className="w-8 h-8 mb-2" />
                      <span className="text-sm">Click or drag image</span>
                    </div>
                  )}
                  <input type="file" className="hidden" accept="image/*" onChange={handleHeroImageChange} />
                </label>
              </div>

              <div>
                <label className="block text-sm text-slate-300 font-medium mb-2">Gallery Images</label>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {formData.gallery.map((img, i) => (
                    <div key={i} className="relative aspect-square rounded-xl overflow-hidden group">
                      <img src={img} className="w-full h-full object-cover" alt="" />
                      <button type="button" onClick={() => handleRemoveGalleryImage(i)} className="absolute top-1 right-1 p-1 bg-red-500/80 rounded-lg text-white opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 className="w-3 h-3"/></button>
                    </div>
                  ))}
                  <label className="flex items-center justify-center aspect-square border-2 border-dashed border-white/10 rounded-xl hover:border-[#8B5CF6]/50 transition-colors cursor-pointer bg-white/5 text-slate-400 hover:text-white">
                    <Plus className="w-6 h-6" />
                    <input type="file" multiple className="hidden" accept="image/*" onChange={handleGalleryAdd} />
                  </label>
                </div>
              </div>

              {/* Tags, Services, Tools */}
              {(['servicesRendered', 'toolsUsed', 'tags'] as const).map((key) => {
                const stateMap = {
                  servicesRendered: { val: serviceInput, set: setServiceInput, label: 'Services Rendered' },
                  toolsUsed: { val: toolInput, set: setToolInput, label: 'Tools Used' },
                  tags: { val: tagInput, set: setTagInput, label: 'Tags' },
                };
                return (
                  <div key={key}>
                    <label className="block text-sm text-slate-300 font-medium mb-2">{stateMap[key].label}</label>
                    <div className="flex gap-2 mb-2">
                      <input 
                        type="text" 
                        value={stateMap[key].val} 
                        onChange={(e) => stateMap[key].set(e.target.value)}
                        onKeyDown={(e) => { if(e.key === 'Enter') { e.preventDefault(); addArrayItem(key, stateMap[key].val, stateMap[key].set); } }}
                        className="flex-1 glass-input px-3 py-2 rounded-lg text-sm" 
                        placeholder={`Add ${stateMap[key].label.toLowerCase()}...`}
                      />
                      <Button type="button" size="sm" onClick={() => addArrayItem(key, stateMap[key].val, stateMap[key].set)}>Add</Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {formData[key].map(item => (
                        <span key={item} className="px-2 py-1 bg-white/10 text-white rounded text-xs flex items-center gap-1 group">
                          {item}
                          <button type="button" onClick={() => removeArrayItem(key, item)} className="text-slate-400 group-hover:text-red-400"><X className="w-3 h-3"/></button>
                        </span>
                      ))}
                    </div>
                  </div>
                )
              })}

            </div>
          </div>
        </div>

        <div className="p-6 border-t border-white/5 flex justify-end gap-4 bg-[#0A1635]/50 rounded-b-[2.5rem]">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSave(formData)} className="bg-gradient-to-r from-blue-600 to-[#8B5CF6]">Save Project</Button>
        </div>
      </div>
    </div>
  );
}
