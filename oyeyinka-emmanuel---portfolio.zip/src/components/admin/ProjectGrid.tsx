import React from 'react';
import { Camera, Image as ImageIcon, Video, FileEdit, Trash2 } from 'lucide-react';
import { Project } from '../../types';

interface ProjectGridProps {
  projects: Project[];
  onEdit: (project: Project) => void;
  onDelete: (id: string) => void;
}

export function ProjectGrid({ projects, onEdit, onDelete }: ProjectGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {projects.map((project) => (
        <div key={project.id} className="glass border border-white/10 rounded-[2rem] overflow-hidden group hover:border-[#8B5CF6]/50 transition-all duration-500 shadow-[0_10px_30px_rgba(0,0,0,0.3)]">
          <div className="h-48 relative overflow-hidden">
            <img src={project.heroImage} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A1635] via-transparent to-transparent opacity-80" />
            <div className="absolute top-4 right-4 flex gap-2">
              <button onClick={() => onEdit(project)} className="w-8 h-8 rounded-full glass flex items-center justify-center text-white hover:bg-[#8B5CF6] hover:text-white transition-colors duration-300">
                <FileEdit className="w-4 h-4" />
              </button>
              <button onClick={() => {
                if(window.confirm('Are you sure you want to permanently delete this project?')) onDelete(project.id);
              }} className="w-8 h-8 rounded-full glass flex items-center justify-center text-white hover:bg-red-500 hover:text-white transition-colors duration-300">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            {project.featured && (
              <div className="absolute top-4 left-4 px-3 py-1 bg-brand-blue/90 text-white rounded-full text-xs font-bold shadow-[0_0_10px_rgba(139,92,246,0.5)]">
                Featured
              </div>
            )}
          </div>
          <div className="p-6 relative z-10 bg-[#0A1635]/80 backdrop-blur-md">
            <h3 className="text-xl font-display font-bold text-white mb-2 truncate">{project.title}</h3>
            <p className="text-sm text-slate-400 line-clamp-2 mb-4">{project.description}</p>
            <div className="flex gap-2 flex-wrap">
              {project.categoryIds.slice(0, 2).map((cid, i) => (
                <span key={i} className="text-xs px-2 py-1 rounded bg-white/5 text-slate-300 border border-white/10">{cid}</span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
