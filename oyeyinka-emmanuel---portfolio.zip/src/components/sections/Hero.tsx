import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { useStore } from '../../store';
import { Button } from '../ui/Button';

export function Hero() {
  const { profile, projects } = useStore();
  const heroImages = projects.slice(0, 8).map(p => p.heroImage).filter(Boolean);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y3 = useTransform(scrollYProgress, [0, 1], [0, 100]);

  return (
    <section ref={containerRef} className="relative min-h-screen pt-24 pb-12 flex flex-col justify-center overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-[#8B5CF6]/10 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-[90rem] mx-auto px-6 w-full flex-1 flex flex-col xl:flex-row items-center gap-12 xl:gap-20 relative z-10">
        
        {/* Mobile: Swipeable Carousel BEFORE Text */}
        <div className="w-full xl:hidden mb-8 mt-8">
          <div className="flex overflow-x-auto hide-scrollbar gap-4 snap-x pl-2 pb-8">
            {heroImages.map((img, idx) => (
              <motion.div 
                key={idx}
                className="shrink-0 w-64 h-80 rounded-2xl overflow-hidden snap-center relative shadow-[0_20px_40px_rgba(0,0,0,0.5)] border border-white/10"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                 <img src={img} alt="Portfolio Work" className="w-full h-full object-cover" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Left Side: Typography & Info */}
        <div className="w-full xl:w-5/12 flex flex-col justify-center text-center xl:text-left z-10">
           <motion.div
             initial={{ opacity: 0, y: 30 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8 }}
           >
             <h1 className="text-6xl sm:text-7xl lg:text-8xl font-display font-black text-white leading-[0.9] tracking-tighter mb-8 uppercase drop-shadow-2xl">
               Create.<br/>
               Capture.<br/>
               <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#A78BFA] to-blue-400">Inspire.</span>
             </h1>
             <p className="text-lg sm:text-xl text-slate-300 font-medium mb-10 max-w-xl mx-auto xl:mx-0 leading-relaxed drop-shadow-md">
               {profile.summary}
             </p>
             <div className="flex flex-col sm:flex-row items-center justify-center xl:justify-start gap-4">
               <Button 
                size="lg" 
                className="w-full sm:w-auto text-lg px-8 py-4 bg-white text-black hover:bg-slate-200 border-none shadow-[0_0_30px_rgba(255,255,255,0.3)] transition-all font-bold"
                onClick={() => window.open(`https://wa.me/${profile.whatsapp.replace('+', '')}?text=Let's create something remarkable.`, '_blank')}
               >
                 Start a Project
               </Button>
               <Button 
                variant="secondary" 
                size="lg" 
                className="w-full sm:w-auto text-lg px-8 py-4 glass border-white/20 text-white font-semibold"
                onClick={() => document.getElementById('featured')?.scrollIntoView({ behavior: 'smooth'})}
               >
                 View Selected Works
               </Button>
             </div>
           </motion.div>
        </div>

        {/* Right Side: Desktop Parallax Collage */}
        <div className="hidden xl:flex w-7/12 h-[800px] relative justify-center items-center gap-6">
           {/* Column 1 */}
           <motion.div style={{ y: y1 }} className="flex flex-col gap-6 w-1/3">
             {heroImages.slice(0, 2).map((img, idx) => (
                <div key={idx} className="w-full rounded-[2rem] overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.4)] border border-white/5 relative group h-96">
                   <img src={img} alt="Portfolio Work" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                   <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                </div>
             ))}
           </motion.div>
           {/* Column 2 */}
           <motion.div style={{ y: y2 }} className="flex flex-col gap-6 w-1/3 mt-32">
             {heroImages.slice(2, 4).map((img, idx) => (
                <div key={idx} className="w-full rounded-[2rem] overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.4)] border border-white/5 relative group h-[450px]">
                   <img src={img} alt="Portfolio Work" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                   <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                </div>
             ))}
           </motion.div>
           {/* Column 3 */}
           <motion.div style={{ y: y3 }} className="flex flex-col gap-6 w-1/3 -mt-20">
             {heroImages.slice(4, 6).map((img, idx) => (
                <div key={idx} className="w-full rounded-[2rem] overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.4)] border border-white/5 relative group h-80">
                   <img src={img} alt="Portfolio Work" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                   <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                </div>
             ))}
           </motion.div>
        </div>

      </div>
    </section>
  );
}
