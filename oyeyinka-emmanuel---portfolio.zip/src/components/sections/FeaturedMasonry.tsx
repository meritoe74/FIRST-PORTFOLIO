import React from 'react';
import { useStore } from '../../store';
import { useNavigate } from 'react-router-dom';

export function FeaturedMasonry({ title = "Select Works" }: { title?: string }) {
  const { categories } = useStore();
  const navigate = useNavigate();

  return (
    <section className="pt-24 pb-12 px-4 sm:px-6 max-w-[100rem] mx-auto relative z-10" id="featured">
      <div className="text-center">
        <h2 className="text-4xl md:text-6xl font-display font-black text-white mb-6 uppercase tracking-tight drop-shadow-xl">{title}</h2>
        <p className="text-slate-400 max-w-2xl mx-auto text-lg mb-10">A curated showcase of visual storytelling, creative strategy, and digital production.</p>
        
        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-3">
          <button 
            onClick={() => navigate('/search')}
            className={`px-6 py-2.5 rounded-full text-sm font-bold tracking-wider uppercase transition-all duration-300 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white border border-white/5`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button 
              key={cat.id}
              onClick={() => navigate(`/search?c=${encodeURIComponent(cat.id)}`)}
              className={`px-6 py-2.5 rounded-full text-sm font-bold tracking-wider uppercase transition-all duration-300 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white border border-white/5`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
