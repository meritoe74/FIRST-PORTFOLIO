import React from 'react';
import { useStore } from '../../store';
import { Button } from '../ui/Button';
import { Mail, MessageCircle, ArrowRight, Instagram, Linkedin } from 'lucide-react';

export function Contact() {
  const { profile } = useStore();

  return (
    <section className="py-32 px-4 sm:px-6 relative z-10" id="contact">
       <div className="max-w-[80rem] mx-auto bg-white/5 backdrop-blur-3xl rounded-[3rem] p-10 md:p-24 border border-white/10 relative overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.5)]">
         
         <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-16 md:gap-20">
            <div className="w-full md:w-[55%] text-center md:text-left">
               <h2 className="text-5xl md:text-7xl lg:text-8xl font-display font-black text-white mb-8 leading-[1.1] tracking-tighter drop-shadow-xl">
                 Let's Create<br/>
                 Something<br/>
                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#A78BFA] to-blue-400">Remarkable.</span>
               </h2>
               <p className="text-xl md:text-2xl text-slate-300 font-medium mb-12 max-w-lg mx-auto md:mx-0 leading-relaxed">
                 Connect with me to discuss creative strategies, high-end visual content, and brand growth.
               </p>
               <div className="flex items-center justify-center md:justify-start gap-5">
                  <a href={profile.socials.instagram} target="_blank" rel="noreferrer" className="w-14 h-14 rounded-full bg-white/5 backdrop-blur-lg border border-white/10 flex items-center justify-center text-[#A78BFA] hover:bg-[#8B5CF6] hover:text-white hover:border-transparent hover:shadow-[0_0_20px_rgba(139,92,246,0.4)] transition-all duration-300 hover:scale-110">
                     <Instagram className="w-6 h-6" />
                  </a>
                  <a href="#" target="_blank" rel="noreferrer" className="w-14 h-14 rounded-full bg-white/5 backdrop-blur-lg border border-white/10 flex items-center justify-center text-[#A78BFA] hover:bg-[#8B5CF6] hover:text-white hover:border-transparent hover:shadow-[0_0_20px_rgba(139,92,246,0.4)] transition-all duration-300 hover:scale-110">
                     <Linkedin className="w-6 h-6" />
                  </a>
               </div>
            </div>

            <div className="w-full md:w-[45%] flex flex-col gap-6">
               <Button 
                 onClick={() => window.open(`https://wa.me/${profile.whatsapp.replace('+', '')}?text=Let's create something remarkable together.`, '_blank')}
                 className="w-full py-8 rounded-[2rem] bg-gradient-to-r from-[#25D366] to-[#128C7E] flex items-center justify-between px-10 text-2xl font-bold shadow-[0_20px_40px_rgba(37,211,102,0.2)] hover:shadow-[0_30px_60px_rgba(37,211,102,0.4)] border-none hover:-translate-y-2 transition-all duration-500 group"
               >
                 <span className="flex items-center gap-4"><MessageCircle className="w-8 h-8" /> WhatsApp Me</span>
                 <ArrowRight className="w-7 h-7 group-hover:translate-x-2 transition-transform duration-500" />
               </Button>

               <Button 
                 variant="secondary"
                 onClick={() => window.location.href = `mailto:${profile.email}`}
                 className="w-full py-8 rounded-[2rem] bg-white/5 backdrop-blur-lg border border-white/10 flex items-center justify-between px-10 text-2xl font-bold hover:bg-white/10 hover:border-white/30 hover:shadow-[0_20px_40px_rgba(0,0,0,0.3)] transition-all duration-500 text-white group hover:-translate-y-2"
               >
                 <span className="flex items-center gap-4"><Mail className="w-8 h-8 text-[#A78BFA]" /> Email Studio</span>
                 <ArrowRight className="w-7 h-7 group-hover:translate-x-2 transition-transform duration-500" />
               </Button>
            </div>
         </div>
       </div>
    </section>
  );
}
