import React from 'react';
import { motion } from 'motion/react';
import { useStore } from '../../store';
import { Camera, Video, PenTool, Layout, MonitorPlay, Image as ImageIcon, Wand2, Megaphone, Lightbulb, Compass } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  "Social Media Management": <Megaphone className="w-8 h-8 text-[#A78BFA]" />,
  "Photography": <Camera className="w-8 h-8 text-[#A78BFA]" />,
  "Cinematography": <Video className="w-8 h-8 text-[#A78BFA]" />,
  "Script Writing": <PenTool className="w-8 h-8 text-[#A78BFA]" />,
  "Graphic Design": <Layout className="w-8 h-8 text-[#A78BFA]" />,
  "Content Creation": <MonitorPlay className="w-8 h-8 text-[#A78BFA]" />,
  "Photo Editing": <ImageIcon className="w-8 h-8 text-[#A78BFA]" />,
  "Photo Retouching": <Wand2 className="w-8 h-8 text-[#A78BFA]" />,
  "Brand Strategy": <Compass className="w-8 h-8 text-[#A78BFA]" />,
  "Creative Consulting": <Lightbulb className="w-8 h-8 text-[#A78BFA]" />
};

export function Services() {
  const { profile } = useStore();

  return (
    <section className="py-32 px-4 sm:px-6 relative z-10" id="services">
      <div className="max-w-[90rem] mx-auto relative">
        <div className="text-center mb-20 max-w-3xl mx-auto">
           <h2 className="text-5xl md:text-7xl font-display font-black mb-6 tracking-tight text-white drop-shadow-xl">Expertise.</h2>
           <p className="text-xl md:text-2xl text-slate-300 font-medium leading-relaxed">Transforming profound ideas into high-converting visual assets and strategic content.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {profile.services.map((service, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: (idx % 4) * 0.1, duration: 0.8, ease: "easeOut" }}
              className="p-8 md:p-10 rounded-[2.5rem] bg-white/5 backdrop-blur-2xl border border-white/10 hover:border-[#8B5CF6]/50 hover:shadow-[0_30px_60px_rgba(139,92,246,0.15)] transition-all duration-700 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[#8B5CF6]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
              
              <div className="w-20 h-20 bg-white/5 border border-white/10 rounded-[1.5rem] mb-10 flex items-center justify-center group-hover:-translate-y-2 group-hover:scale-110 group-hover:border-[#8B5CF6]/40 shadow-[0_15px_30px_rgba(0,0,0,0.3)] transition-all duration-700 relative z-10">
                 {iconMap[service.name] || <Lightbulb className="w-8 h-8 text-[#A78BFA]" />}
              </div>
              
              <h3 className="text-2xl font-bold font-display text-white mb-4 relative z-10 leading-tight drop-shadow-md">{service.name}</h3>
              <p className="text-slate-300 text-base md:text-lg relative z-10 leading-relaxed font-body">
                 Professional execution tailored to your specific project needs, ensuring premium quality output.
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
