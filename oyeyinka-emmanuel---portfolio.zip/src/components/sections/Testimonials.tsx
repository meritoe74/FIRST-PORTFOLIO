import React from 'react';
import { useStore } from '../../store';
import { MessageSquareQuote } from 'lucide-react';

export function Testimonials() {
  const { testimonials } = useStore();

  return (
    <section className="py-32 px-4 sm:px-6 relative z-10" id="testimonials">
      <div className="max-w-[90rem] mx-auto">
        <div className="text-center mb-20 max-w-3xl mx-auto">
          <h2 className="text-5xl md:text-7xl font-display font-black text-white tracking-tight drop-shadow-xl mb-6">Client Voices.</h2>
          <p className="text-xl md:text-2xl text-slate-300 font-medium leading-relaxed">What visionary brands and individuals say about our creative collaboration.</p>
        </div>

        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 md:gap-8 space-y-6 md:space-y-8">
          {testimonials.map((test, idx) => (
             <div 
               key={test.id} 
               className="break-inside-avoid bg-white/5 backdrop-blur-2xl p-8 md:p-12 rounded-[3rem] border border-white/10 hover:border-[#8B5CF6]/40 shadow-[0_20px_40px_rgba(0,0,0,0.3)] hover:shadow-[0_30px_60px_rgba(139,92,246,0.15)] transition-all duration-700 relative group transform-gpu hover:-translate-y-2 will-change-transform"
             >
               <MessageSquareQuote className="w-12 h-12 text-[#8B5CF6]/20 absolute top-10 right-10 group-hover:text-[#8B5CF6]/50 transition-colors duration-500" />
               <p className="text-xl md:text-2xl leading-relaxed text-slate-300 italic mb-10 mt-4 relative z-10 font-body">
                 "{test.message}"
               </p>
               <div className="flex items-center gap-5">
                 <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-[#8B5CF6] flex items-center justify-center text-white font-bold text-2xl shadow-[0_0_20px_rgba(139,92,246,0.4)]">
                   {test.clientName.charAt(0)}
                 </div>
                 <div>
                   <p className="font-bold text-white text-lg tracking-wide">{test.clientName}</p>
                   <p className="text-base text-[#A78BFA] font-medium">{test.company}</p>
                 </div>
               </div>
             </div>
          ))}
        </div>
      </div>
    </section>
  );
}
