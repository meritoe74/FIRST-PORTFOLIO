import React from 'react';
import { useStore } from '../../store';
import { Button } from '../ui/Button';
import { motion } from 'motion/react';
import { Award, Briefcase, GraduationCap } from 'lucide-react';

export function About() {
  const { profile } = useStore();

  return (
    <section className="py-32 px-6 relative z-10 overflow-hidden" id="about">
       <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#8B5CF6]/10 rounded-full blur-[150px] pointer-events-none -z-10" />
       
       <div className="max-w-[80rem] mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-24">
             
             {/* Left: Images / Editorial Collage */}
             <div className="w-full lg:w-1/2 relative h-[600px] md:h-[700px] hidden sm:block">
                <motion.div 
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8 }}
                  className="absolute top-0 left-0 w-3/4 h-3/4 rounded-[3rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/10 z-10"
                >
                  <img src="https://images.unsplash.com/photo-1554046920-90dc5823ba6e?auto=format&fit=crop&w=800&q=80" alt="Creative Content" className="w-full h-full object-cover" />
                </motion.div>
                
                <motion.div 
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="absolute bottom-0 right-0 w-2/3 h-2/3 rounded-[3rem] overflow-hidden shadow-[0_30px_60px_rgba(0,0,0,0.6)] border border-[#8B5CF6]/30 z-20"
                >
                  {/* Using a placeholder for Oyeyinka if a real one isn't provided, mimicking a premium portrait */}
                  <img src="https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=800&q=80" alt={profile.name} className="w-full h-full object-cover" />
                </motion.div>
             </div>

             {/* Right: Text Content */}
             <div className="w-full lg:w-1/2 flex flex-col justify-center">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8 }}
                >
                  <h2 className="text-sm font-bold text-[#A78BFA] tracking-widest uppercase mb-4 flex items-center gap-2">
                     <span className="w-8 h-px bg-[#A78BFA]" /> Inside The Studio
                  </h2>
                  <h3 className="text-4xl md:text-6xl font-display font-black text-white mb-8 tracking-tight leading-tight">
                     Visual Storyteller.<br/>Creative Strategist.
                  </h3>
                  
                  <div className="space-y-6 text-lg text-slate-300 leading-relaxed font-body mb-12">
                     <p>
                        My name is <span className="text-white font-bold">{profile.name}</span>. {profile.bio.split('I specialize')[0]}
                     </p>
                     <p>
                        I specialize in helping brands, businesses, churches, organizations, and startups create meaningful digital experiences through strategic management and compelling visual storytelling.
                     </p>
                  </div>

                  {/* Certifications & Achievements */}
                  <div className="bg-white/5 border border-white/10 p-8 rounded-[2rem] backdrop-blur-2xl mb-12 shadow-[0_20px_40px_rgba(0,0,0,0.2)]">
                     <div className="flex items-start gap-5">
                        <div className="w-16 h-16 rounded-[1.5rem] bg-gradient-to-br from-blue-600 to-[#8B5CF6] flex items-center justify-center shrink-0 shadow-[0_0_20px_rgba(139,92,246,0.4)]">
                           <GraduationCap className="w-8 h-8 text-white" />
                        </div>
                        <div className="flex flex-col justify-center">
                           <h4 className="text-white font-bold text-xl mb-1">NSQ Creative Program Graduate</h4>
                           <p className="text-base text-slate-300">Sponsored by the <span className="text-[#A78BFA] font-medium">World Bank</span> with the Ministry of Education.</p>
                        </div>
                     </div>
                  </div>

                  <Button 
                    size="lg" 
                    className="text-xl px-10 py-5 rounded-full bg-white text-[#020B1D] hover:bg-slate-200 transition-all duration-500 font-bold shadow-[0_0_30px_rgba(255,255,255,0.3)] hover:shadow-[0_0_50px_rgba(255,255,255,0.5)] border-none hover:scale-105"
                    onClick={() => window.open(`https://wa.me/${profile.whatsapp.replace('+', '')}`, '_blank')}
                  >
                    Collaborate With {profile.name.split(' ')[0]}
                  </Button>
                </motion.div>
             </div>
             
          </div>

          {/* Camera Expertise Ribbon */}
          <div className="mt-32 pt-16 border-t border-white/5 grid grid-cols-1 lg:grid-cols-4 gap-10 items-center">
             <div className="lg:col-span-1 text-center lg:text-left">
                <h4 className="text-3xl font-display font-bold text-white mb-3">Systems & Gear</h4>
                <p className="text-base text-slate-400">Professional equipment mastery.</p>
             </div>
             <div className="lg:col-span-3 flex flex-wrap justify-center lg:justify-start gap-4">
                {profile.cameraExpertise.systems.map(sys => (
                   <span key={sys} className="px-8 py-4 bg-white/5 backdrop-blur-lg border border-white/10 rounded-full text-slate-200 font-bold text-base hover:border-[#8B5CF6]/50 hover:bg-white/10 hover:shadow-[0_0_20px_rgba(139,92,246,0.2)] transition-all duration-500 cursor-default">
                      {sys}
                   </span>
                ))}
             </div>
          </div>
       </div>
    </section>
  );
}
