import React from 'react';
import { useStore } from '../../store';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Image as ImageIcon, Video, Layout, Megaphone } from 'lucide-react';

const showcases = [
  { category: 'Photography', title: 'Photography', description: 'Transforming moments into compelling visual narratives. Explore curated photography featuring events, portraits, and commercial shoots.', icon: <ImageIcon className="w-8 h-8"/> },
  { category: 'Cinematography', title: 'Cinematography', description: 'Visually stunning motion pictures that tell a story. From event coverage to brand documentaries and dynamic promotional reels.', icon: <Video className="w-8 h-8"/> },
  { category: 'Graphic Design', title: 'Graphic Design', description: 'Crafting premium visual identities, expressive campaign materials, and modern editorial designs that powerfully command attention.', icon: <Layout className="w-8 h-8"/> },
  { category: 'Social Media Campaigns', title: 'Social Media', description: 'Elevating digital presence through strategic content, engaging visuals, and data-driven storytelling that drives actual results.', icon: <Megaphone className="w-8 h-8"/> },
];

export function CaseStudyShowcase() {
   const { projects } = useStore();

   const activeShowcases = showcases.map(s => {
       const project = projects.find(p => p.categoryIds.includes(s.category));
       return { ...s, project };
   }).filter(s => s.project);

   return (
       <section className="py-24 md:py-32 relative z-10 px-4 sm:px-6">
           <div className="max-w-[90rem] mx-auto space-y-32 md:space-y-48">
               {activeShowcases.map((showcase, idx) => {
                   const isEven = idx % 2 === 0;
                   const proj = showcase.project!;

                   return (
                       <motion.div 
                          key={showcase.category}
                          initial={{ opacity: 0, y: 80 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          viewport={{ once: true, margin: "-100px" }}
                          transition={{ duration: 1, ease: "easeOut" }}
                          className={`flex flex-col gap-12 lg:gap-20 items-center ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}
                       >
                           {/* Image Side */}
                           <div className="w-full lg:w-[55%] relative group perspective-[1000px]">
                               <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-[#8B5CF6] rounded-[3rem] blur-3xl opacity-20 group-hover:opacity-40 transition-opacity duration-1000 -z-10" />
                               
                               <Link to={`/project/${proj.id}`} className="block relative h-[500px] md:h-[650px] w-full rounded-[3rem] overflow-hidden bg-white/5 backdrop-blur-xl border border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.5)] transform-gpu group-hover:-translate-y-4 transition-all duration-700 hover:shadow-[0_40px_80px_rgba(139,92,246,0.3)] will-change-transform">
                                  <img src={proj.heroImage} alt={proj.title} className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-1000 ease-out will-change-transform" />
                                  <div className="absolute inset-0 bg-gradient-to-t from-[#020B1D]/90 via-[#020B1D]/20 to-transparent opacity-80" />
                                  <div className="absolute bottom-10 left-10 right-10">
                                      <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-lg border border-white/20 text-[#A78BFA] text-xs font-bold tracking-widest uppercase mb-4 shadow-lg">
                                          Featured {showcase.category}
                                      </span>
                                      <h3 className="text-3xl md:text-5xl font-display font-bold text-white leading-tight drop-shadow-xl">{proj.title}</h3>
                                  </div>
                               </Link>
                           </div>

                           {/* Content Side */}
                           <div className="w-full lg:w-[45%] flex flex-col justify-center">
                               <motion.div 
                                 className="w-20 h-20 rounded-[2rem] bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-center text-[#A78BFA] mb-10 shadow-[0_20px_40px_rgba(0,0,0,0.3)] relative overflow-hidden group-hover:border-[#8B5CF6]/50 transition-colors duration-500"
                               >
                                  <div className="absolute inset-0 bg-gradient-to-br from-[#8B5CF6]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                                  {showcase.icon}
                               </motion.div>
                               
                               <h2 className="text-5xl md:text-6xl lg:text-7xl font-display font-black text-white leading-[1.1] mb-8 tracking-tight drop-shadow-md">
                                   {showcase.title}.
                               </h2>
                               <p className="text-xl md:text-2xl text-slate-300 font-body font-medium leading-relaxed mb-12 max-w-lg">
                                   {showcase.description}
                               </p>
                               
                               <Link to={`/search?c=${encodeURIComponent(showcase.category)}`} className="inline-flex items-center justify-between px-8 py-5 rounded-full bg-white/5 backdrop-blur-lg border border-white/10 text-white font-bold text-lg hover:bg-white/10 hover:border-white/30 hover:shadow-[0_0_40px_rgba(139,92,246,0.3)] transition-all duration-500 w-fit sm:w-80 group">
                                   <span>View Portfolio</span>
                                   <span className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-[#8B5CF6] group-hover:text-white transition-all duration-500 group-hover:scale-110">
                                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                                   </span>
                               </Link>
                           </div>
                       </motion.div>
                   )
               })}
           </div>
       </section>
   )
}
