import React from 'react';
import { useStore } from '../../store';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export function CategoryShowcase({ categoryName, title }: { categoryName: string, title?: string }) {
  const { projects } = useStore();
  const categoryProjects = projects.filter(p => p.categoryIds.includes(categoryName));

  if (categoryProjects.length === 0) return null;

  return (
    <section className="py-20 relative z-10 w-full overflow-hidden">
      <div className="max-w-[100rem] mx-auto px-6 flex items-center justify-between mb-8">
        <h3 className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight drop-shadow-md">
          {title || `Latest in ${categoryName}`}
        </h3>
        <Link to={`/search?c=${categoryName}`} className="text-sm font-bold text-[#A78BFA] hover:text-white transition-colors flex items-center gap-2 group uppercase tracking-wider">
          See All 
          <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-[#8B5CF6] transition-colors">
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </span>
        </Link>
      </div>
      
      {/* Horizontal Scroll Area */}
      <div className="flex overflow-x-auto hide-scrollbar pl-6 md:pl-[calc((100vw-100rem)/2+1.5rem)] pr-6 pb-12 gap-6 snap-x group cursor-grab active:cursor-grabbing">
        {categoryProjects.map(project => (
          <Link 
            to={`/project/${project.id}`} 
            key={project.id} 
            className="min-w-[85vw] sm:min-w-[400px] w-[85vw] sm:w-[400px] aspect-[4/5] sm:aspect-[4/3] snap-start relative rounded-[2rem] overflow-hidden group/card shadow-[0_10px_30px_rgba(0,0,0,0.3)] bg-[#0A1635] border border-white/5 shrink-0"
          >
             <img 
               src={project.heroImage} 
               alt={project.title} 
               className="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-700 ease-in-out" 
             />
             <div className="absolute inset-0 bg-gradient-to-t from-[#020B1D] via-[#020B1D]/40 to-transparent opacity-80 group-hover/card:opacity-90 transition-opacity duration-300" />
             
             <div className="absolute inset-x-0 bottom-0 p-8 translate-y-4 group-hover/card:translate-y-0 transition-transform duration-500">
               <h4 className="text-2xl font-bold font-display text-white mb-2 leading-tight drop-shadow-lg">{project.title}</h4>
               <p className="text-slate-300 text-sm line-clamp-2 opacity-0 group-hover/card:opacity-100 transition-opacity duration-500 delay-100">{project.description}</p>
             </div>
          </Link>
        ))}
      </div>

      <div className="flex justify-center mt-4">
        <button 
           onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
           className="px-6 py-3 rounded-full border border-white/20 text-white font-semibold hover:bg-white/10 transition-colors"
        >
          Book a Shoot
        </button>
      </div>
    </section>
  );
}
