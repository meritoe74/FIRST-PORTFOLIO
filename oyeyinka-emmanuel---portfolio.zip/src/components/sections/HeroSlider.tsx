import React, { useCallback, useEffect, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import { useStore } from '../../store';
import { Button } from '../ui/Button';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function HeroSlider() {
  const { projects } = useStore();
  const featuredProjects = projects.filter(p => p.featured);
  
  // If no featured projects, fallback to the first 5 projects
  const displayProjects = featuredProjects.length > 0 ? featuredProjects : projects.slice(0, 5);

  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true }, [Autoplay({ delay: 4000, stopOnInteraction: false })]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  const scrollTo = useCallback((index: number) => {
    if (emblaApi) emblaApi.scrollTo(index);
  }, [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi, setSelectedIndex]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);
  }, [emblaApi, onSelect]);

  if (displayProjects.length === 0) {
    return (
      <section className="min-h-[70vh] flex flex-col items-center justify-center relative pt-24 pb-12">
        <h1 className="text-4xl text-white font-display">Add projects in Admin Dashboard</h1>
      </section>
    );
  }

  return (
    <section className="relative w-full h-[35vh] md:h-[45vh] lg:h-[55vh] min-h-[350px] overflow-hidden bg-[#020B1D]">
      <div className="absolute inset-0 z-0 overflow-hidden" ref={emblaRef}>
        <div className="flex h-full touch-pan-y">
          {displayProjects.map((project, index) => (
            <div className="relative flex-[0_0_100%] min-w-0 h-full" key={project.id || index}>
              <img 
                src={project.heroImage} 
                alt={project.title} 
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#020B1D] via-[#020B1D]/60 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#020B1D]/80 to-transparent" />
              
              <div className="absolute inset-0 flex flex-col justify-end pb-16 md:pb-20 px-6 sm:px-12 md:px-24">
                <div className="max-w-4xl">
                  {project.categoryIds && project.categoryIds.length > 0 && (
                    <span className="inline-block py-1 px-3 rounded-full bg-white/10 border border-white/20 text-[#A78BFA] text-xs font-bold tracking-widest uppercase mb-3 backdrop-blur-md">
                      {project.categoryIds.join(', ')}
                    </span>
                  )}
                  <h2 className="text-3xl sm:text-4xl md:text-6xl font-display font-black text-white leading-[1.1] mb-4 drop-shadow-2xl tracking-tight">
                    {project.title}
                  </h2>
                  <p className="text-sm sm:text-base text-slate-300 md:text-lg font-medium mb-6 max-w-2xl line-clamp-2 md:line-clamp-3">
                    {project.description}
                  </p>
                  <div className="flex items-center gap-4">
                    <Link to={`/project/${project.id}`}>
                      <Button size="lg" className="px-6 py-3 bg-white text-black hover:bg-slate-200 border-none shadow-[0_0_30px_rgba(255,255,255,0.3)] hover:shadow-[0_0_40px_rgba(255,255,255,0.5)] transition-all font-bold group">
                        View Project <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Arrows (Desktop) */}
      <button 
        onClick={scrollPrev}
        className="hidden sm:flex absolute left-6 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full glass border border-white/10 items-center justify-center text-white hover:bg-white/10 hover:scale-110 transition-all z-20"
      >
        <ChevronLeft className="w-8 h-8" />
      </button>
      <button 
        onClick={scrollNext}
        className="hidden sm:flex absolute right-6 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full glass border border-white/10 items-center justify-center text-white hover:bg-white/10 hover:scale-110 transition-all z-20"
      >
        <ChevronRight className="w-8 h-8" />
      </button>

      {/* Pagination Dots */}
      <div className="absolute bottom-10 left-0 right-0 flex justify-center gap-3 z-20">
        {displayProjects.map((_, index) => (
          <button
            key={index}
            onClick={() => scrollTo(index)}
            className={`transition-all duration-300 rounded-full ${
              index === selectedIndex 
                ? 'w-10 h-2 bg-[#A78BFA] shadow-[0_0_10px_rgba(167,139,250,0.8)]' 
                : 'w-2 h-2 bg-white/30 hover:bg-white/60'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
