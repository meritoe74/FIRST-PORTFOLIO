import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title: string;
  description: string;
  name?: string;
  type?: string;
}

export function SEO({ title, description, name = "Peculiar Lifestyle Limited", type = "website" }: SEOProps) {
  const fullTitle = `${title} | ${name}`;
  
  return (
    <Helmet>
      <title>{title ? fullTitle : name}</title>
      <meta name='description' content={description} />
      
      {/* Open Graph Tags */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:site_name" content={name} />
      
      {/* Twitter Tags */}
      <meta name="twitter:creator" content={name} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      
      {/* Content-Type */}
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      
      {/* Viewport tracking for mobile */}
      <meta name="viewport" content="width=device-width, initial-scale=1" />
    </Helmet>
  );
}
