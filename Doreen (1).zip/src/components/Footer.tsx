export function Footer() {
  return (
    <footer className="bg-emerald text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <img 
              src="https://i.ibb.co/C5BLXPQs/Chat-GPT-Image-Jun-22-2026-09-02-16-PM.png" 
              alt="Peculiar Lifestyle Limited" 
              className="h-16 w-auto bg-white p-2 rounded-lg" 
            />
            <p className="text-emerald-100 text-sm leading-relaxed max-w-sm">
              All-In-One Home Management. Your Balance, Restored. We master the chores so you can reclaim your time.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif font-semibold text-xl mb-6 text-gold">Quick Links</h3>
            <ul className="space-y-3">
              {['Home', 'About Us', 'Services', 'Pricing', 'Gallery', 'Testimonials', 'FAQ'].map((link) => (
                <li key={link}>
                  <a href={`/${link.toLowerCase().replace(' ', '-')}`} className="text-emerald-100 hover:text-gold transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-serif font-semibold text-xl mb-6 text-gold">Our Services</h3>
            <ul className="space-y-3">
              <li><span className="text-emerald-100 text-sm">Premium Cleaning</span></li>
              <li><span className="text-emerald-100 text-sm">Efficient Market Runs</span></li>
              <li><span className="text-emerald-100 text-sm">Move-In/Move-Out</span></li>
              <li><span className="text-emerald-100 text-sm">Special Events</span></li>
              <li><span className="text-emerald-100 text-sm">Post-Construction</span></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-serif font-semibold text-xl mb-6 text-gold">Contact Us</h3>
            <address className="not-italic space-y-4 text-sm text-emerald-100">
              <p className="flex items-center gap-2">
                <span className="text-gold">📍</span> Lagos, Nigeria
              </p>
              <p className="flex items-center gap-2">
                <span className="text-gold">📞</span> 
                <a href="tel:+2347084639368" className="hover:text-white transition-colors">+2347084639368</a>
              </p>
              <p className="flex items-center gap-2">
                <span className="text-gold">✉️</span> 
                <a href="mailto:peculiardee247@gmail.com" className="hover:text-white transition-colors">peculiardee247@gmail.com</a>
              </p>
            </address>
            <div className="flex space-x-4 mt-6 text-gold">
              {/* Social placeholders */}
              <a href="#" className="hover:text-white transition-colors">FB</a>
              <a href="#" className="hover:text-white transition-colors">IG</a>
              <a href="#" className="hover:text-white transition-colors">TK</a>
              <a href="#" className="hover:text-white transition-colors">IN</a>
              <a href="#" className="hover:text-white transition-colors">X</a>
            </div>
          </div>
        </div>

        <div className="border-t border-emerald-light pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-emerald-200">
          <p>&copy; {new Date().getFullYear()} Peculiar Lifestyle Limited. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
