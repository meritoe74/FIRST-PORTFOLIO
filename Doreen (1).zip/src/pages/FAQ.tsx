import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SEO } from '../components/SEO';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: "Do I need to supply my own cleaning materials?",
    answer: "No. Peculiar Lifestyle Limited arrives fully equipped with premium, industry-grade cleaning supplies and equipment. However, if you prefer we use specific products for allergy or personal reasons, we are happy to accommodate."
  },
  {
    question: "How do you vet your staff?",
    answer: "Security and trust are foundational to our brand. Every member of our team undergoes rigorous background checks, extensive reference verification, and comprehensive in-house training before they enter a client's home."
  },
  {
    question: "Can I schedule a recurring service?",
    answer: "Absolutely. Most of our clients prefer our recurring upkeep service (weekly, bi-weekly, or monthly). This ensures your sanctuary remains consistently pristine."
  },
  {
    question: "How do the customized market runs work?",
    answer: "You provide us with your grocery list, preferred brands, and dietary restrictions. We hand-select the freshest items from premium markets and stores, then deliver and organize them directly into your pantry and refrigerator."
  },
  {
    question: "Do I have to be home during the cleaning?",
    answer: "It is entirely up to you. Many of our clients prefer to provide us with access (via a key, access code, or staff) so they can return to a perfectly managed home. Complete confidentiality and security are guaranteed."
  },
  {
    question: "What happens if I need to cancel or reschedule?",
    answer: "We require a 24-hour notice for cancellations or rescheduling to avoid a fee. This allows us to reallocate our professionals efficiently."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="FAQ" 
        description="Frequently Asked Questions about our premium home management services." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Common Questions
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            Everything you need to know about how we manage your home.
          </motion.p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                  className="w-full px-6 py-6 text-left flex justify-between items-center focus:outline-none"
                >
                  <span className="font-bold text-gray-900 text-lg pr-8">{faq.question}</span>
                  <ChevronDown 
                    className={`w-6 h-6 text-emerald transition-transform duration-300 flex-shrink-0 ${openIndex === idx ? 'rotate-180' : ''}`} 
                  />
                </button>
                <AnimatePresence>
                  {openIndex === idx && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="px-6 pb-6 text-gray-600 leading-relaxed border-t border-gray-50 pt-4">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <p className="text-gray-600 mb-6">Still have questions?</p>
            <a href="https://wa.me/2347084639368" target="_blank" rel="noreferrer" className="inline-flex items-center text-emerald font-bold hover:text-emerald-light transition-colors uppercase tracking-wider text-sm">
              Contact us directly via WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
