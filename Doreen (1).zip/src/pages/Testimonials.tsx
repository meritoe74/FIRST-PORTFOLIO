import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: "Director / CEO",
    role: "Merit Wedding and Events LTD",
    content: "Partnering with Peculiar Lifestyle Limited for our event cleanups has been a game-changer. They handle the post-event chaos with incredible efficiency and professionalism, ensuring venues are always impeccable. True partners in excellence.",
    rating: 5,
    avatar: "https://i.ibb.co/1YwyF9CS/IMG-3142.jpg"
  },
  {
    id: 2,
    name: "Church Administration",
    role: "The Apostolic Church Nigeria, Akoka District",
    content: "Peculiar Lifestyle Limited has consistently maintained a pristine and welcoming environment for our congregation. Their dedication, attention to detail, and highly respectful service are deeply appreciated by our entire community.",
    rating: 5,
    avatar: ""
  },
  {
    id: 3,
    name: "Oluwaseun A.",
    role: "Corporate Executive",
    content: "Peculiar Lifestyle Limited completely transformed the way I manage my time. Returning to a spotless home after a long business trip without worrying about groceries is truly a luxury.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1bf98a?q=80&w=2670&auto=format&fit=crop"
  },
  {
    id: 4,
    name: "Ngozi E.",
    role: "Entrepreneur & Mother",
    content: "Balancing my growing business and family life left me exhausted. Their scheduled cleaning and focused market runs have given me my weekends back. Highly professional.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?q=80&w=2787&auto=format&fit=crop"
  }
];

export default function Testimonials() {
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Testimonials" 
        description="Read what our clients have to say about Peculiar Lifestyle Limited." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Client Experiences
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            Do not just take our word for it. Hear from those whose time we have restored.
          </motion.p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, idx) => (
              <motion.div 
                key={testimonial.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white rounded-2xl p-8 md:p-10 shadow-sm border border-gray-100 relative"
              >
                <div className="absolute top-8 right-8 text-emerald/10">
                  <Quote size={64} />
                </div>
                
                <div className="flex text-gold mb-6 relative z-10">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={18} fill={i < testimonial.rating ? "currentColor" : "none"} className={i >= testimonial.rating ? "text-gray-300" : ""} />
                  ))}
                </div>
                
                <p className="text-gray-700 text-lg md:text-xl leading-relaxed mb-8 relative z-10 font-medium">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center relative z-10 mt-auto">
                  {testimonial.avatar ? (
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name} 
                      className="w-14 h-14 rounded-full object-cover border-2 border-cream mr-4 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-emerald/10 text-emerald flex items-center justify-center font-bold text-xl mr-4 border-2 border-cream flex-shrink-0">
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-emerald text-sm uppercase tracking-wider font-semibold">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
