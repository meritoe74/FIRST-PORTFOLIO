import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';

export default function Pricing() {
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Pricing" 
        description="Transparent, tailored pricing for our premium home management services." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Tailored Quotes
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            Every home is unique. We provide bespoke pricing based on your specific requirements and the scale of property.
          </motion.p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 border border-gray-100 relative overflow-hidden">
             {/* Decorative element */}
             <div className="absolute top-0 right-0 w-32 h-32 bg-gold/10 rounded-bl-full"></div>
             
             <div className="relative z-10">
               <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Request a Custom Quote</h2>
               <p className="text-gray-600 mb-8 text-lg">
                 Because we provide a highly personalized service, we prefer to assess your specific needs before giving a price. Contact us today for a structured breakdown.
               </p>
               
               <ul className="space-y-4 mb-10">
                 {[
                   "Free initial consultation",
                   "Transparent pricing structure",
                   "Flexible subscription models",
                   "No hidden fees"
                 ].map((item, idx) => (
                   <li key={idx} className="flex items-center text-gray-700">
                     <span className="w-6 h-6 rounded-full bg-emerald/10 text-emerald flex items-center justify-center mr-3 flex-shrink-0">
                       <Check size={14} />
                     </span>
                     {item}
                   </li>
                 ))}
               </ul>

               <div className="flex flex-col sm:flex-row gap-4">
                 <Link to="/book" className="flex-1 bg-emerald hover:bg-emerald-light text-white text-center py-4 rounded-full font-semibold transition-all">
                   Book a Consultation
                 </Link>
                 <a href="https://wa.me/2347084639368" target="_blank" rel="noreferrer" className="flex-1 bg-[#25D366]/10 text-[#25D366] hover:bg-[#25D366] hover:text-white border border-[#25D366]/30 text-center py-4 rounded-full font-semibold transition-all">
                   Chat on WhatsApp
                 </a>
               </div>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
}
