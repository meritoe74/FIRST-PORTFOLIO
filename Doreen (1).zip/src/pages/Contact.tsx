import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { MapPin, Phone, Mail } from 'lucide-react';

export default function Contact() {
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="Contact Us" 
        description="Get in touch with Peculiar Lifestyle Limited for premium home management services in Lagos, Nigeria." 
      />

      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            Get In Touch
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            We are here to help you reclaim your balance. Let us know how we can serve you.
          </motion.p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white p-10 rounded-2xl shadow-sm border border-gray-100 text-center"
            >
              <div className="w-16 h-16 bg-emerald/5 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald">
                <Phone className="w-8 h-8" />
              </div>
              <h3 className="font-serif font-bold text-2xl text-gray-900 mb-4">Phone</h3>
              <p className="text-gray-600 mb-6">Available Monday - Saturday<br/>8:00 AM - 6:00 PM</p>
              <a href="tel:+2347084639368" className="inline-block bg-cream text-emerald font-semibold py-3 px-6 rounded-full hover:bg-emerald hover:text-white transition-all w-full">
                +2347084639368
              </a>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white p-10 rounded-2xl shadow-sm border border-gray-100 text-center"
            >
              <div className="w-16 h-16 bg-emerald/5 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald">
                <Mail className="w-8 h-8" />
              </div>
              <h3 className="font-serif font-bold text-2xl text-gray-900 mb-4">Email</h3>
              <p className="text-gray-600 mb-6">Send us a message anytime.<br/>We usually reply within 2 hours.</p>
              <a href="mailto:peculiardee247@gmail.com" className="inline-block bg-cream text-emerald font-semibold py-3 px-6 rounded-full hover:bg-emerald hover:text-white transition-all w-full">
                Email Us
              </a>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white p-10 rounded-2xl shadow-sm border border-gray-100 text-center"
            >
              <div className="w-16 h-16 bg-emerald/5 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald">
                <MapPin className="w-8 h-8" />
              </div>
              <h3 className="font-serif font-bold text-2xl text-gray-900 mb-4">Location</h3>
              <p className="text-gray-600 mb-6">Proudly serving premium residences across Lagos and environments.</p>
              <div className="inline-block bg-cream text-gray-700 font-semibold py-3 px-6 rounded-full w-full">
                Lagos, Nigeria
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
