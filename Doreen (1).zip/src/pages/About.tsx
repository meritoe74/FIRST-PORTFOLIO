import { motion } from 'motion/react';
import { SEO } from '../components/SEO';

export default function About() {
  return (
    <div className="flex flex-col min-h-screen bg-cream">
      <SEO 
        title="About Us" 
        description="Learn more about Peculiar Lifestyle Limited and our mission to help you reclaim your time." 
      />

      {/* Header */}
      <section className="bg-emerald py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6"
          >
            About Us
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-emerald-100 max-w-2xl mx-auto font-light"
          >
            Our story, our mission, and the people behind the premium service.
          </motion.p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?q=80&w=2670&auto=format&fit=crop" 
                alt="Luxury living room" 
                className="rounded-2xl shadow-2xl object-cover h-[600px] w-full"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <h2 className="text-gold font-bold uppercase tracking-widest text-sm">Our Story</h2>
              <h3 className="text-4xl font-serif font-bold text-gray-900 leading-tight">
                Restoring Balance to <br /> Busy Lives
              </h3>
              <div className="space-y-4 text-gray-600 text-lg leading-relaxed">
                <p>
                  At Peculiar Lifestyle Limited, we understand that time is your most valuable asset. For busy professionals, families, entrepreneurs, and organizations in Lagos, managing a household alongside demanding careers and personal goals can be overwhelming.
                </p>
                <p>
                  That is where we come in. We established our luxury home management brand with a clear purpose: to take the weight of household responsibilities off your shoulders efficiently and professionally.
                </p>
                <p>
                  From premium cleaning to bespoke market runs, we don't just complete chores—we curate an environment of peace, order, and excellence. We are dedicated to ensuring that when you walk through your door, you step into a sanctuary.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CEO Spotlight */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-emerald font-semibold uppercase tracking-wider text-sm mb-3">Leadership</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Meet Our CEO</h3>
          </div>

          <div className="max-w-4xl mx-auto bg-cream rounded-3xl overflow-hidden shadow-lg border border-gray-100 flex flex-col md:flex-row">
            <div className="md:w-2/5 relative">
              <img 
                src="https://i.ibb.co/rGXtDmn4/IMG-20260619-WA0012.jpg" 
                alt="CEO Portrait" 
                className="h-full w-full object-cover min-h-[400px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-emerald/80 to-transparent"></div>
              <div className="absolute bottom-6 left-6 text-white text-left">
                <p className="font-serif font-bold text-2xl">Founder & CEO</p>
                <p className="text-emerald-100 text-sm">Peculiar Lifestyle Limited</p>
              </div>
            </div>
            <div className="md:w-3/5 p-8 md:p-12 flex flex-col justify-center">
              <div className="mb-8">
                <svg className="w-12 h-12 text-gold/40 mb-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h4v10h-10z" />
                </svg>
                <p className="text-xl md:text-2xl font-serif text-gray-800 leading-snug italic">
                  "At Peculiar Lifestyle Limited, we believe your time is valuable. Our mission is to take care of the details so you can focus on what truly matters."
                </p>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Driven by a vision of unparalleled excellence and a passion for customer satisfaction, our founder established Peculiar Lifestyle Limited to elevate the standard of professional home management in Nigeria. 
              </p>
              <div className="mt-auto">
                 {/* Signature Placeholder */}
                 <div className="font-serif text-3xl text-emerald/60 -rotate-2">
                   Founder Signature
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
