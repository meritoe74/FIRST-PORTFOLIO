import { motion } from 'motion/react';
import { ArrowRight, CheckCircle, Clock, ShieldCheck, Sparkles, Star, ThumbsUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SEO } from '../components/SEO';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <SEO 
        title="Home" 
        description="All-In-One Home Management. We master the chores. You reclaim your time." 
      />

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center bg-emerald overflow-hidden">
        {/* Background Image / Pattern overlay placeholder */}
        <div className="absolute inset-0 z-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2670&auto=format&fit=crop" 
            alt="Luxury Home" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-emerald via-emerald/90 to-emerald/40 z-0"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full pt-16 lg:pt-0">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center px-4 py-2 rounded-full bg-gold/20 text-gold-light border border-gold/30 backdrop-blur-sm mb-6 uppercase tracking-wider text-xs font-semibold"
            >
              Mastering the details of luxury living
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-tight mb-6"
            >
              All-In-One <br className="hidden md:block" />
              <span className="text-gold">Home Management</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl md:text-2xl text-emerald-100 font-light mb-10 max-w-2xl"
            >
              Your Balance, Restored. <br/>
              "We master the chores. You reclaim your time."
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Link to="/book" className="flex items-center justify-center bg-gold hover:bg-gold-light text-emerald font-semibold px-8 py-4 rounded-full transition-all text-lg shadow-lg hover:shadow-xl group">
                Book a Service
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/pricing" className="flex items-center justify-center bg-transparent border-2 border-white/30 hover:border-white text-white font-semibold px-8 py-4 rounded-full transition-all text-lg backdrop-blur-sm hover:bg-white/10">
                Get a Quote
              </Link>
              <a href="https://wa.me/2347084639368" target="_blank" rel="noreferrer" className="flex items-center justify-center bg-[#25D366]/20 border border-[#25D366] hover:bg-[#25D366] text-white font-semibold px-8 py-4 rounded-full transition-all text-lg backdrop-blur-sm">
                WhatsApp Us
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="bg-white py-10 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-8 md:gap-16 items-center opacity-70">
            <span className="font-serif text-xl md:text-2xl text-gray-400 font-bold tracking-wide uppercase">Reliable</span>
            <span className="font-serif text-xl md:text-2xl text-gray-400 font-bold tracking-wide uppercase">Professional</span>
            <span className="font-serif text-xl md:text-2xl text-gray-400 font-bold tracking-wide uppercase">Trusted</span>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-emerald font-semibold uppercase tracking-wider text-sm mb-3">The Peculiar Advantage</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Why Choose Us?</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {[
               { icon: <ShieldCheck />, title: "Reliability & Trust", desc: "Fully vetted and trustworthy professionals dedicated to securing your peace of mind." },
               { icon: <Star />, title: "Professionalism", desc: "We maintain highest standards of service delivery in every home we manage." },
               { icon: <Clock />, title: "Time Saving", desc: "Offload the time-consuming tasks so you can focus on family and career." },
               { icon: <Sparkles />, title: "Attention to Detail", desc: "Meticulous care given to every corner, surface, and custom request." },
               { icon: <CheckCircle />, title: "Trusted Service", desc: "A robust track record of satisfying premium clients across Lagos." },
               { icon: <ThumbsUp />, title: "Customer Satisfaction", desc: "Guaranteed satisfaction with responsive support and flexible scheduling." }
             ].map((feature, idx) => (
               <motion.div 
                 key={idx}
                 initial={{ opacity: 0, y: 20 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: idx * 0.1 }}
                 className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-shadow border border-gray-100 group"
               >
                 <div className="w-14 h-14 bg-emerald/5 rounded-2xl flex items-center justify-center text-gold mb-6 group-hover:scale-110 transition-transform">
                   {feature.icon}
                 </div>
                 <h4 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h4>
                 <p className="text-gray-600 leading-relaxed">
                   {feature.desc}
                 </p>
               </motion.div>
             ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-emerald text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-gold font-semibold uppercase tracking-wider text-sm mb-3">Seamless Process</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-white">How It Works</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
            {/* Connecting Line */}
            <div className="hidden md:block absolute top-12 left-[15%] right-[15%] h-0.5 bg-emerald-light z-0"></div>

            {[
              { step: "01", title: "Tell Us What You Need", desc: "Reach out via our booking form or WhatsApp with your specific requirements." },
              { step: "02", title: "We Handle Everything", desc: "Our professional team executes your requests with precision and care." },
              { step: "03", title: "Enjoy Your Time", desc: "Return to a perfectly managed home and reclaim your valuable time." }
            ].map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="relative z-10 flex flex-col items-center text-center"
              >
                <div className="w-24 h-24 bg-gold rounded-full flex items-center justify-center text-3xl font-serif font-bold text-emerald shadow-xl mb-6 ring-8 ring-emerald-light">
                  {step.step}
                </div>
                <h4 className="text-2xl font-bold mb-4 font-serif">{step.title}</h4>
                <p className="text-emerald-100 max-w-xs">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gold/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-6">Ready to Reclaim Your Time?</h3>
          <p className="text-xl text-gray-600 mb-10">
            Let Peculiar Lifestyle Limited handle the management of your home with our premium services.
          </p>
          <Link to="/book" className="inline-flex items-center justify-center bg-emerald hover:bg-emerald-light text-white font-semibold px-10 py-5 rounded-full transition-all text-xl shadow-lg hover:shadow-xl hover:-translate-y-1">
            Book Your Service Today
          </Link>
        </div>
      </section>
    </div>
  );
}
